"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DeliveryOptions, type DeliveryAddress } from "./delivery-options"
import { PaymentMethodForm } from "./payment-method-form"
import { toast } from "sonner"
import { ArrowRight, CreditCard, Truck } from "lucide-react"

interface CheckoutDialogProps {
  strain: {
    id: number
    name: string
    price: number
    quantity: string
    availableAmount: number
  }
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CheckoutDialog({ strain, open, onOpenChange }: CheckoutDialogProps) {
  const [quantity, setQuantity] = useState(1)
  const [activeTab, setActiveTab] = useState("delivery")
  const [deliveryMethod, setDeliveryMethod] = useState("standard")
  const [deliveryDate, setDeliveryDate] = useState<Date | undefined>(undefined)
  const [deliveryTime, setDeliveryTime] = useState<string | undefined>(undefined)
  const [deliveryInstructions, setDeliveryInstructions] = useState("")
  const [deliveryAddress, setDeliveryAddress] = useState<DeliveryAddress>({
    street: "",
    city: "",
    state: "",
    zipCode: "",
    businessName: "",
    licenseNumber: "",
  })
  const [isProcessing, setIsProcessing] = useState(false)

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseInt(e.target.value)
    if (!isNaN(value) && value > 0 && value <= strain.availableAmount) {
      setQuantity(value)
    }
  }

  const getDeliveryFee = () => {
    switch (deliveryMethod) {
      case "express":
        return 250
      case "same_day":
        return 350
      default:
        return 150
    }
  }

  const calculateSubtotal = () => {
    return strain.price * quantity
  }

  const calculateTotal = () => {
    return calculateSubtotal() + getDeliveryFee()
  }

  const handleCheckout = () => {
    // Validate required fields
    if (
      !deliveryDate ||
      !deliveryTime ||
      !deliveryAddress.street ||
      !deliveryAddress.city ||
      !deliveryAddress.state ||
      !deliveryAddress.zipCode
    ) {
      toast.error("Please fill in all required delivery information")
      return
    }

    setIsProcessing(true)

    // Simulate processing
    setTimeout(() => {
      setIsProcessing(false)
      onOpenChange(false)
      toast.success("Order placed successfully! Redirecting to order tracking...")

      // Store order in localStorage for demo purposes
      const order = {
        id: `ORD-${Math.floor(Math.random() * 10000)}`,
        strainId: strain.id,
        strainName: strain.name,
        quantity,
        price: strain.price,
        total: calculateTotal(),
        deliveryMethod,
        deliveryDate: deliveryDate?.toISOString(),
        deliveryTime,
        deliveryAddress,
        deliveryInstructions,
        status: "processing",
        createdAt: new Date().toISOString(),
      }

      try {
        // Get existing orders or initialize empty array
        const existingOrders = JSON.parse(localStorage.getItem("cannabisOrders") || "[]")
        localStorage.setItem("cannabisOrders", JSON.stringify([order, ...existingOrders]))

        // Redirect to order tracking page
        window.location.href = `/orders/${order.id}`
      } catch (error) {
        console.error("Error saving order:", error)
      }
    }, 2000)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Complete Your Purchase</DialogTitle>
          <DialogDescription>
            You're purchasing {strain.name} at ${strain.price.toLocaleString()} per unit.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="delivery" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="delivery" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              <span className="hidden sm:inline">Delivery</span>
            </TabsTrigger>
            <TabsTrigger value="payment" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              <span className="hidden sm:inline">Payment</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="delivery" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity (lbs)</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="quantity"
                  type="number"
                  min={1}
                  max={strain.availableAmount}
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="w-20"
                />
                <span className="text-sm text-gray-500">Available: {strain.availableAmount} lbs</span>
              </div>
            </div>

            <DeliveryOptions
              onSelectDeliveryMethod={setDeliveryMethod}
              onSelectDeliveryDate={setDeliveryDate}
              onSelectDeliveryTime={setDeliveryTime}
              onAddDeliveryInstructions={setDeliveryInstructions}
              onAddDeliveryAddress={setDeliveryAddress}
              selectedMethod={deliveryMethod}
              selectedDate={deliveryDate}
              selectedTime={deliveryTime}
              deliveryInstructions={deliveryInstructions}
              deliveryAddress={deliveryAddress}
            />

            <div className="flex justify-end">
              <Button onClick={() => setActiveTab("payment")} className="mt-4">
                Continue to Payment <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="payment" className="space-y-4 py-4">
            <PaymentMethodForm />

            <div className="rounded-lg border p-4 mt-4">
              <h3 className="font-medium mb-2">Order Summary</h3>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Product:</span>
                  <span>{strain.name}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Quantity:</span>
                  <span>{quantity} lbs</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Price per unit:</span>
                  <span>${strain.price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Subtotal:</span>
                  <span>${calculateSubtotal().toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Delivery Fee:</span>
                  <span>${getDeliveryFee().toLocaleString()}</span>
                </div>
                <div className="border-t mt-2 pt-2 flex justify-between font-medium">
                  <span>Total:</span>
                  <span>${calculateTotal().toLocaleString()}</span>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex flex-col-reverse sm:flex-row gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isProcessing}>
            Cancel
          </Button>
          {activeTab === "payment" && (
            <Button onClick={handleCheckout} disabled={isProcessing}>
              {isProcessing ? "Processing..." : "Complete Purchase"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
