"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface InventoryAlertSettingsProps {
  isOpen: boolean
  onClose: () => void
  onSave: () => void
}

export function InventoryAlertSettings({ isOpen, onClose, onSave }: InventoryAlertSettingsProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [settings, setSettings] = useState({
    lowStockThreshold: 1.0,
    lowStockEnabled: true,
    expiryThreshold: 30,
    expiryEnabled: true,
    emailNotifications: true,
    dashboardNotifications: true,
    autoAdjustStatus: true,
    dailyDigest: false,
    notifyContacts: [],
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target

    setSettings({
      ...settings,
      [name]: type === "number" ? Number.parseFloat(value) : value,
    })
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setSettings({
      ...settings,
      [name]: checked,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      onSave()
    }, 500)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Inventory Alert Settings</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <Tabs defaultValue="thresholds">
            <TabsList className="mb-4">
              <TabsTrigger value="thresholds">Alert Thresholds</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
            </TabsList>

            <TabsContent value="thresholds" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Low Stock Alerts</CardTitle>
                  <CardDescription>Configure when to trigger low stock alerts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="lowStockEnabled" className="flex-1">
                      Enable low stock alerts
                    </Label>
                    <Switch
                      id="lowStockEnabled"
                      checked={settings.lowStockEnabled}
                      onCheckedChange={(checked) => handleSwitchChange("lowStockEnabled", checked)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lowStockThreshold">Low stock threshold (lbs)</Label>
                      <Input
                        id="lowStockThreshold"
                        name="lowStockThreshold"
                        type="number"
                        step="0.1"
                        min="0"
                        value={settings.lowStockThreshold}
                        onChange={handleChange}
                        disabled={!settings.lowStockEnabled}
                      />
                      <p className="text-xs text-muted-foreground">
                        Items with quantity below this threshold will be marked as "low stock"
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Expiry Alerts</CardTitle>
                  <CardDescription>Configure when to trigger expiry alerts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="expiryEnabled" className="flex-1">
                      Enable expiry alerts
                    </Label>
                    <Switch
                      id="expiryEnabled"
                      checked={settings.expiryEnabled}
                      onCheckedChange={(checked) => handleSwitchChange("expiryEnabled", checked)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiryThreshold">Expiry threshold (days)</Label>
                      <Input
                        id="expiryThreshold"
                        name="expiryThreshold"
                        type="number"
                        min="1"
                        value={settings.expiryThreshold}
                        onChange={handleChange}
                        disabled={!settings.expiryEnabled}
                      />
                      <p className="text-xs text-muted-foreground">
                        Items expiring within this many days will be marked as "expiring soon"
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>Configure how you want to receive alerts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="emailNotifications" className="flex-1">
                      Email notifications
                    </Label>
                    <Switch
                      id="emailNotifications"
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => handleSwitchChange("emailNotifications", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="dashboardNotifications" className="flex-1">
                      Dashboard notifications
                    </Label>
                    <Switch
                      id="dashboardNotifications"
                      checked={settings.dashboardNotifications}
                      onCheckedChange={(checked) => handleSwitchChange("dashboardNotifications", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="dailyDigest" className="flex-1">
                      Daily digest summary
                    </Label>
                    <Switch
                      id="dailyDigest"
                      checked={settings.dailyDigest}
                      onCheckedChange={(checked) => handleSwitchChange("dailyDigest", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="automation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Automated Actions</CardTitle>
                  <CardDescription>Configure automated actions for inventory management</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <Label htmlFor="autoAdjustStatus" className="mb-1 block">
                        Auto-adjust item status
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        Automatically update item status based on quantity and expiry date
                      </p>
                    </div>
                    <Switch
                      id="autoAdjustStatus"
                      checked={settings.autoAdjustStatus}
                      onCheckedChange={(checked) => handleSwitchChange("autoAdjustStatus", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : "Save Settings"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
