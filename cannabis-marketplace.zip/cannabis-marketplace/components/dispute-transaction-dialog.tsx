"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "sonner"
import { AlertTriangle } from "lucide-react"

interface DisputeTransactionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  transactionId: string
}

export function DisputeTransactionDialog({ open, onOpenChange, transactionId }: DisputeTransactionDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [disputeReason, setDisputeReason] = useState("quality")
  const [disputeDetails, setDisputeDetails] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      onOpenChange(false)
      toast.success("Dispute filed successfully")

      // Reset form
      setDisputeReason("quality")
      setDisputeDetails("")
    }, 1500)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            File a Dispute
          </DialogTitle>
          <DialogDescription>
            Filing a dispute will freeze the funds in escrow until the issue is resolved.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Reason for Dispute</Label>
            <RadioGroup value={disputeReason} onValueChange={setDisputeReason}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="quality" id="quality" />
                <Label htmlFor="quality">Product quality issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="quantity" id="quantity" />
                <Label htmlFor="quantity">Incorrect quantity received</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="delivery" id="delivery" />
                <Label htmlFor="delivery">Delivery issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="other" />
                <Label htmlFor="other">Other</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="details">Dispute Details</Label>
            <Textarea
              id="details"
              placeholder="Please provide specific details about the issue..."
              value={disputeDetails}
              onChange={(e) => setDisputeDetails(e.target.value)}
              rows={5}
              required
            />
          </div>

          <div className="rounded-md bg-yellow-50 p-4 text-sm text-yellow-800">
            <div className="flex items-center">
              <AlertTriangle className="mr-2 h-4 w-4" />
              <h3 className="font-medium">Important</h3>
            </div>
            <div className="mt-2">
              <p>
                By filing a dispute, you agree to participate in the resolution process. Our team will review the case
                and may request additional information or evidence.
              </p>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="destructive" disabled={isSubmitting || !disputeDetails.trim()}>
              {isSubmitting ? "Filing Dispute..." : "File Dispute"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
