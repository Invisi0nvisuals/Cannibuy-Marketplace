"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { ChevronDown, Package, ShoppingBag, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export function MainNav() {
  const pathname = usePathname()

  const mainRoutes = [
    {
      href: "/",
      label: "Home",
      active: pathname === "/",
    },
    {
      href: "/search",
      label: "Search",
      active: pathname === "/search",
    },
  ]

  const sellerRoutes = [
    {
      href: "/my-listings",
      label: "My Listings",
      active: pathname === "/my-listings",
    },
    {
      href: "/add-listing",
      label: "Add Listing",
      active: pathname === "/add-listing",
    },
    {
      href: "/inventory",
      label: "Inventory",
      active: pathname === "/inventory",
      badge: "New",
    },
    {
      href: "/analytics",
      label: "Analytics",
      active: pathname === "/analytics",
    },
  ]

  const orderRoutes = [
    {
      href: "/orders",
      label: "My Orders",
      active: pathname.startsWith("/orders"),
    },
    {
      href: "/delivery-tracking",
      label: "Track Deliveries",
      active: pathname === "/delivery-tracking",
    },
    {
      href: "/transactions",
      label: "Transactions",
      active: pathname.startsWith("/transactions"),
    },
  ]

  const accountRoutes = [
    {
      href: "/profile",
      label: "Profile",
      active: pathname.startsWith("/profile"),
    },
    {
      href: "/messages",
      label: "Messages",
      active: pathname === "/messages",
    },
    {
      href: "/settings",
      label: "Settings",
      active: pathname === "/settings",
    },
  ]

  return (
    <nav className="hidden md:flex items-center gap-6 text-sm">
      {mainRoutes.map((route) => (
        <Link
          key={route.href}
          href={route.href}
          className={cn(
            "transition-colors hover:text-green-700",
            route.active ? "text-green-700 font-medium" : "text-muted-foreground",
          )}
        >
          {route.label}
        </Link>
      ))}

      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-1 text-sm transition-colors hover:text-green-700">
          <ShoppingBag className="h-4 w-4" />
          Seller
          <ChevronDown className="h-4 w-4" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <DropdownMenuLabel>Seller Tools</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {sellerRoutes.map((route) => (
            <DropdownMenuItem key={route.href} asChild>
              <Link
                href={route.href}
                className={cn("flex w-full items-center", route.active ? "text-green-700 font-medium" : "")}
              >
                {route.label}
                {route.badge && <Badge className="ml-2 bg-green-500 hover:bg-green-600">{route.badge}</Badge>}
              </Link>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-1 text-sm transition-colors hover:text-green-700">
          <Package className="h-4 w-4" />
          Orders
          <ChevronDown className="h-4 w-4" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <DropdownMenuLabel>Orders & Tracking</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {orderRoutes.map((route) => (
            <DropdownMenuItem key={route.href} asChild>
              <Link
                href={route.href}
                className={cn("flex w-full items-center", route.active ? "text-green-700 font-medium" : "")}
              >
                {route.label}
              </Link>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-1 text-sm transition-colors hover:text-green-700">
          <User className="h-4 w-4" />
          Account
          <ChevronDown className="h-4 w-4" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <DropdownMenuLabel>Account Settings</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {accountRoutes.map((route) => (
            <DropdownMenuItem key={route.href} asChild>
              <Link
                href={route.href}
                className={cn("flex w-full items-center", route.active ? "text-green-700 font-medium" : "")}
              >
                {route.label}
              </Link>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </nav>
  )
}
