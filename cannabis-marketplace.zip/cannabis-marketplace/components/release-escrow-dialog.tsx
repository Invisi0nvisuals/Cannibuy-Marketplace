"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "sonner"
import { Shield, CheckCircle2 } from "lucide-react"

interface ReleaseEscrowDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  transactionId: string
  amount: number
}

export function ReleaseEscrowDialog({ open, onOpenChange, transactionId, amount }: ReleaseEscrowDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [confirmReceived, setConfirmReceived] = useState(false)
  const [confirmQuality, setConfirmQuality] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      onOpenChange(false)
      toast.success("Funds released from escrow")

      // Reset form
      setConfirmReceived(false)
      setConfirmQuality(false)
    }, 1500)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-500" />
            Release Funds from Escrow
          </DialogTitle>
          <DialogDescription>
            Confirm that you've received the product and are satisfied with the quality.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="rounded-md bg-blue-50 p-4 text-sm text-blue-800">
            <p>
              You are about to release <span className="font-bold">${amount.toLocaleString()}</span> from escrow to the
              seller. This action cannot be undone.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="confirm-received"
                checked={confirmReceived}
                onCheckedChange={(checked) => setConfirmReceived(checked as boolean)}
                className="mt-1"
              />
              <div>
                <Label htmlFor="confirm-received" className="font-medium">
                  I confirm that I have received the product
                </Label>
                <p className="text-sm text-gray-500">
                  By checking this box, you confirm that the product has been delivered to you.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox
                id="confirm-quality"
                checked={confirmQuality}
                onCheckedChange={(checked) => setConfirmQuality(checked as boolean)}
                className="mt-1"
              />
              <div>
                <Label htmlFor="confirm-quality" className="font-medium">
                  I am satisfied with the product quality
                </Label>
                <p className="text-sm text-gray-500">
                  By checking this box, you confirm that the product meets your expectations and matches the
                  description.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || !confirmReceived || !confirmQuality}
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? (
                "Processing..."
              ) : (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  Release Funds
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
