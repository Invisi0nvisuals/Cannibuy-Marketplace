"use client"

import { Textarea } from "@/components/ui/textarea"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Download, FileText, Upload } from "lucide-react"

interface InventoryItem {
  id: number
  strainName: string
  batchId: string
  quantity: string
  quantityValue: number
  unit: string
  thcPercentage: number
  harvestDate: string
  expiryDate: string
  status: "in-stock" | "low-stock" | "out-of-stock" | "expiring-soon" | "expired"
  price: number
  location: string
  lastUpdated: string
}

interface BulkUploadModalProps {
  isOpen: boolean
  onClose: () => void
  onUpload: (items: InventoryItem[]) => void
}

export function BulkUploadModal({ isOpen, onClose, onUpload }: BulkUploadModalProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [uploadMethod, setUploadMethod] = useState<"file" | "paste">("file")
  const [pastedData, setPastedData] = useState("")
  const [validationErrors, setValidationErrors] = useState<string[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setValidationErrors([])
    }
  }

  const handlePastedDataChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPastedData(e.target.value)
    setValidationErrors([])
  }

  const handleUpload = () => {
    setIsUploading(true)
    setValidationErrors([])

    // Simulate validation and processing
    setTimeout(() => {
      if (uploadMethod === "file" && !file) {
        setValidationErrors(["Please select a file to upload"])
        setIsUploading(false)
        return
      }

      if (uploadMethod === "paste" && !pastedData.trim()) {
        setValidationErrors(["Please paste data to upload"])
        setIsUploading(false)
        return
      }

      // Simulate successful upload with sample data
      const newItems: InventoryItem[] = [
        {
          id: 100,
          strainName: "Pineapple Express",
          batchId: "PE-2023-11-A",
          quantity: "3.5 lbs",
          quantityValue: 3.5,
          unit: "lbs",
          thcPercentage: 22,
          harvestDate: "2023-11-01",
          expiryDate: "2024-11-01",
          status: "in-stock",
          price: 2800,
          location: "Warehouse A",
          lastUpdated: "2023-11-20",
        },
        {
          id: 101,
          strainName: "White Widow",
          batchId: "WW-2023-11-B",
          quantity: "2.8 lbs",
          quantityValue: 2.8,
          unit: "lbs",
          thcPercentage: 24,
          harvestDate: "2023-11-05",
          expiryDate: "2024-11-05",
          status: "in-stock",
          price: 3200,
          location: "Warehouse B",
          lastUpdated: "2023-11-20",
        },
      ]

      setIsUploading(false)
      onUpload(newItems)
    }, 1500)
  }

  const handleDownloadTemplate = () => {
    // In a real app, this would generate and download a CSV template
    alert("In a production app, this would download a CSV template file")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Bulk Upload Inventory</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="file" onValueChange={(value) => setUploadMethod(value as "file" | "paste")}>
          <TabsList className="mb-4">
            <TabsTrigger value="file">Upload File</TabsTrigger>
            <TabsTrigger value="paste">Paste Data</TabsTrigger>
          </TabsList>

          <TabsContent value="file" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h3 className="text-sm font-medium">Upload CSV or Excel File</h3>
                <p className="text-sm text-muted-foreground">Upload a CSV or Excel file with your inventory data</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleDownloadTemplate}>
                <Download className="mr-2 h-4 w-4" />
                Template
              </Button>
            </div>

            <div className="border rounded-md p-8 flex flex-col items-center justify-center">
              <div className="mb-4">
                <FileText className="h-10 w-10 text-muted-foreground" />
              </div>
              <div className="mb-4 text-center">
                <h4 className="text-sm font-medium">Drag and drop your file here</h4>
                <p className="text-sm text-muted-foreground">or click to browse files (CSV, XLSX)</p>
              </div>
              <Input
                id="file-upload"
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileChange}
                className="max-w-xs"
              />
              {file && (
                <p className="mt-2 text-sm">
                  Selected file: <span className="font-medium">{file.name}</span>
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="paste" className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="paste-data">Paste Inventory Data</Label>
              <p className="text-sm text-muted-foreground">
                Paste data from a spreadsheet (columns should match the template format)
              </p>
            </div>
            <Textarea
              id="paste-data"
              placeholder="Paste your data here..."
              rows={10}
              value={pastedData}
              onChange={handlePastedDataChange}
            />
          </TabsContent>
        </Tabs>

        {validationErrors.length > 0 && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <ul className="list-disc pl-5 mt-2">
                {validationErrors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleUpload} disabled={isUploading}>
            {isUploading ? (
              <>Uploading...</>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Upload
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
