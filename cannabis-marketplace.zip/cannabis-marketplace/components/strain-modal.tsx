"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart } from "lucide-react"

interface StrainModalProps {
  isOpen: boolean
  onClose: () => void
  strain: {
    id?: number
    name: string
    description: string
    price: number
    quantity: string
    testingPercentage: number
    imageUrl: string
  }
  onBuy?: () => void
}

export function StrainModal({ isOpen, onClose, strain, onBuy }: StrainModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl text-green-700">{strain.name}</DialogTitle>
          <DialogDescription>Premium quality cannabis strain</DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4 md:grid-cols-2">
          <div className="relative h-60 md:h-full rounded-md overflow-hidden">
            <img
              src={strain.imageUrl || "/placeholder.svg"}
              alt={strain.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="font-medium">Description</h3>
              <p className="text-sm text-gray-500 mt-1">{strain.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium">Price</h3>
                <p className="text-lg font-bold text-green-700">${strain.price.toLocaleString()}</p>
              </div>
              <div>
                <h3 className="font-medium">Quantity</h3>
                <p>{strain.quantity}</p>
              </div>
            </div>

            <div>
              <h3 className="font-medium">Testing</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  THC: {strain.testingPercentage}%
                </Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  CBD: 0.5%
                </Badge>
              </div>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              {onBuy && (
                <Button onClick={onBuy} className="w-full sm:w-auto">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Buy Now
                </Button>
              )}
              <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">
                Close
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
