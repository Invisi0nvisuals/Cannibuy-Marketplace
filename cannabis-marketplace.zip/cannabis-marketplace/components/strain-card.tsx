"use client"

import Image from "next/image"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { StrainModal } from "./strain-modal"
import { InquireModal } from "./inquire-modal"
import { ReserveModal } from "./reserve-modal"
import { CheckoutDialog } from "./checkout-dialog"

interface StrainCardProps {
  id: number
  name: string
  price: number
  quantity: string
  testingPercentage: number
  imageUrl: string
  description: string
  type?: string
  onInquire: () => void
  onReserve: () => void
}

export function StrainCard({
  id,
  name,
  price,
  quantity,
  testingPercentage,
  imageUrl,
  description,
  type,
  onInquire,
  onReserve,
}: StrainCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isInquireModalOpen, setIsInquireModalOpen] = useState(false)
  const [isReserveModalOpen, setIsReserveModalOpen] = useState(false)
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)
  const [imgError, setImgError] = useState(false)

  const handleInquire = () => {
    setIsInquireModalOpen(true)
  }

  const handleReserve = () => {
    setIsReserveModalOpen(true)
  }

  const handleImageError = () => {
    setImgError(true)
  }

  const handleInquireClose = () => {
    setIsInquireModalOpen(false)
    onInquire()
  }

  const handleReserveClose = () => {
    setIsReserveModalOpen(false)
    onReserve()
  }

  // Extract numeric quantity for available amount
  const getAvailableAmount = () => {
    const match = quantity.match(/\d+(\.\d+)?/)
    return match ? Number.parseFloat(match[0]) : 5 // Default to 5 if parsing fails
  }

  return (
    <>
      <Card className="overflow-hidden transition-shadow hover:shadow-lg h-full flex flex-col">
        <CardHeader className="p-0">
          <div className="aspect-square relative cursor-pointer" onClick={() => setIsModalOpen(true)}>
            <Image
              src={imgError ? "/images/cannabis_market_thumbnail.png" : imageUrl}
              alt={name}
              fill
              className="object-cover transition-transform hover:scale-105"
              onError={handleImageError}
            />
            {type && (
              <div className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-1 text-xs font-medium text-white">
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
          <CardTitle
            className="text-lg sm:text-xl font-bold text-green-700 cursor-pointer hover:underline line-clamp-1"
            onClick={() => setIsModalOpen(true)}
          >
            {name}
          </CardTitle>
          <div className="mt-2 space-y-1 text-sm">
            <p className="text-gray-600">Price: ${price.toLocaleString()}</p>
            <p className="text-gray-600">Quantity: {quantity}</p>
            <p className="text-gray-600">Testing: {testingPercentage}%</p>
          </div>
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-2 p-4">
          <Button variant="outline" onClick={handleInquire} className="text-xs sm:text-sm">
            Inquire
          </Button>
          <Button variant="outline" onClick={handleReserve} className="text-xs sm:text-sm">
            Reserve
          </Button>
        </CardFooter>
      </Card>

      <StrainModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        strain={{
          id,
          name,
          description,
          price,
          quantity,
          testingPercentage,
          imageUrl: imgError ? "/images/cannabis_market_thumbnail.png" : imageUrl,
        }}
        onBuy={() => setIsCheckoutOpen(true)}
      />

      <InquireModal
        isOpen={isInquireModalOpen}
        onClose={handleInquireClose}
        strain={{
          name,
          price,
        }}
      />

      <ReserveModal
        isOpen={isReserveModalOpen}
        onClose={handleReserveClose}
        strain={{
          name,
          price,
          quantity,
        }}
      />

      <CheckoutDialog
        strain={{
          id,
          name,
          price,
          quantity,
          availableAmount: getAvailableAmount(),
        }}
        open={isCheckoutOpen}
        onOpenChange={setIsCheckoutOpen}
      />
    </>
  )
}
