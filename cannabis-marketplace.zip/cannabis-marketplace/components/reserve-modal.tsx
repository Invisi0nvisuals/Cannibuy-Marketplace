"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ReserveModalProps {
  isOpen: boolean
  onClose: () => void
  strain: {
    name: string
    price: number
    quantity: string
  }
}

export function ReserveModal({ isOpen, onClose, strain }: ReserveModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    quantity: "1",
    notes: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formTouched, setFormTouched] = useState(false)
  const [maxQuantity, setMaxQuantity] = useState(10)

  // Extract available quantity from strain
  useEffect(() => {
    const match = strain.quantity.match(/\d+(\.\d+)?/)
    if (match) {
      setMaxQuantity(Number.parseFloat(match[0]))
    }
  }, [strain.quantity])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormTouched(true)
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Name is required"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid"
    }

    const quantityValue = Number.parseFloat(formData.quantity)
    if (isNaN(quantityValue) || quantityValue <= 0) {
      newErrors.quantity = "Quantity must be greater than 0"
    } else if (quantityValue > maxQuantity) {
      newErrors.quantity = `Maximum available quantity is ${maxQuantity}`
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Validate form when values change
  useEffect(() => {
    if (formTouched) {
      validateForm()
    }
  }, [formData, formTouched])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setFormTouched(true)

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      onClose()
    }, 1500)
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Reserve {strain.name}</DialogTitle>
          <DialogDescription>
            Reserve this strain for purchase. Current price: ${strain.price.toLocaleString()} per unit.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Your Name</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={formData.name}
              onChange={handleChange}
              className={errors.name ? "border-red-500" : ""}
            />
            {errors.name && (
              <Alert variant="destructive" className="py-2">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{errors.name}</AlertDescription>
              </Alert>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? "border-red-500" : ""}
            />
            {errors.email && (
              <Alert variant="destructive" className="py-2">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{errors.email}</AlertDescription>
              </Alert>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number (Optional)</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="Enter your phone number"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity" className="flex justify-between">
              <span>Quantity (lbs)</span>
              <span className="text-gray-500 text-sm">Available: {maxQuantity} lbs</span>
            </Label>
            <Input
              id="quantity"
              type="number"
              min="0.1"
              step="0.1"
              max={maxQuantity.toString()}
              value={formData.quantity}
              onChange={handleChange}
              className={errors.quantity ? "border-red-500" : ""}
            />
            {errors.quantity && (
              <Alert variant="destructive" className="py-2">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{errors.quantity}</AlertDescription>
              </Alert>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any special requests or questions?"
              rows={3}
              value={formData.notes}
              onChange={handleChange}
            />
          </div>

          <div className="rounded-md bg-blue-50 p-4 text-sm text-blue-800">
            <p>
              This reservation will hold the product for 48 hours. You'll need to complete the purchase within that
              time.
            </p>
          </div>

          <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0 pt-4">
            <Button variant="outline" type="button" onClick={onClose} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || Object.keys(errors).length > 0}
              className="w-full sm:w-auto"
            >
              {isSubmitting ? "Processing..." : "Reserve Now"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
