"use client"

import { useState } from "react"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "sonner"

interface PlanSelectionModalProps {
  isOpen: boolean
  onClose: () => void
  currentPlan: string
}

interface Plan {
  id: string
  name: string
  price: number
  description: string
  features: string[]
  popular?: boolean
}

const plans: Plan[] = [
  {
    id: "pro",
    name: "Pro Plan",
    price: 49.99,
    description: "Perfect for individual sellers and small businesses",
    features: [
      "Up to 50 active listings",
      "Email support",
      "Basic analytics",
      "Verified seller badge",
      "Priority in search results",
    ],
  },
  {
    id: "team",
    name: "Team Plan",
    price: 99.99,
    description: "Ideal for growing businesses with multiple team members",
    features: [
      "Up to 200 active listings",
      "5 team members",
      "Priority email & chat support",
      "Advanced analytics",
      "Bulk listing tools",
      "Custom branding",
    ],
    popular: true,
  },
  {
    id: "business",
    name: "Business Plan",
    price: 199.99,
    description: "Enterprise-grade features for large operations",
    features: [
      "Unlimited active listings",
      "Unlimited team members",
      "24/7 dedicated support",
      "Enterprise analytics",
      "API access",
      "White-label solution",
      "Custom integrations",
    ],
  },
]

export function PlanSelectionModal({ isOpen, onClose, currentPlan }: PlanSelectionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState(currentPlan)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success(`Successfully switched to ${plans.find((p) => p.id === selectedPlan)?.name}`)
      onClose()
    }, 1500)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px]">
        <DialogHeader>
          <DialogTitle>Choose a Plan</DialogTitle>
          <DialogDescription>Select the plan that best fits your business needs</DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4 md:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-lg border p-4 transition-all ${
                selectedPlan === plan.id ? "border-green-600 ring-1 ring-green-600" : "hover:border-green-200"
              } ${plan.popular ? "shadow-md" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-green-600 px-3 py-1 text-xs font-medium text-white">
                  Most Popular
                </div>
              )}

              <div className="mb-4 mt-2 text-center">
                <h3 className="text-lg font-bold">{plan.name}</h3>
                <div className="mt-1">
                  <span className="text-2xl font-bold">${plan.price}</span>
                  <span className="text-sm text-gray-500">/month</span>
                </div>
                <p className="mt-2 text-sm text-gray-500">{plan.description}</p>
              </div>

              <ul className="mb-6 flex-grow space-y-2 text-sm">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="mr-2 h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={selectedPlan === plan.id ? "default" : "outline"}
                className="w-full"
                onClick={() => setSelectedPlan(plan.id)}
              >
                {selectedPlan === plan.id && currentPlan === plan.id
                  ? "Current Plan"
                  : selectedPlan === plan.id
                    ? "Selected"
                    : "Select Plan"}
              </Button>
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || selectedPlan === currentPlan}>
            {isSubmitting
              ? "Processing..."
              : selectedPlan === currentPlan
                ? "Current Plan"
                : `Switch to ${plans.find((p) => p.id === selectedPlan)?.name}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
