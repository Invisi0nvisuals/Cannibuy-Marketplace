"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Menu, ShoppingBag, Package, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()

  const mainRoutes = [
    {
      href: "/",
      label: "Home",
      active: pathname === "/",
    },
    {
      href: "/search",
      label: "Search",
      active: pathname === "/search",
    },
  ]

  const sellerRoutes = [
    {
      href: "/my-listings",
      label: "My Listings",
      active: pathname === "/my-listings",
    },
    {
      href: "/add-listing",
      label: "Add Listing",
      active: pathname === "/add-listing",
    },
    {
      href: "/inventory",
      label: "Inventory",
      active: pathname === "/inventory",
      badge: "New",
    },
    {
      href: "/analytics",
      label: "Analytics",
      active: pathname === "/analytics",
    },
  ]

  const orderRoutes = [
    {
      href: "/orders",
      label: "My Orders",
      active: pathname.startsWith("/orders"),
    },
    {
      href: "/delivery-tracking",
      label: "Track Deliveries",
      active: pathname === "/delivery-tracking",
      badge: "New",
    },
    {
      href: "/transactions",
      label: "Transactions",
      active: pathname.startsWith("/transactions"),
    },
  ]

  const accountRoutes = [
    {
      href: "/profile",
      label: "Profile",
      active: pathname.startsWith("/profile"),
    },
    {
      href: "/messages",
      label: "Messages",
      active: pathname === "/messages",
    },
    {
      href: "/settings",
      label: "Settings",
      active: pathname === "/settings",
    },
  ]

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden"
        >
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle Menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="pr-0">
        <div className="flex flex-col gap-4 py-4">
          {mainRoutes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={`flex items-center px-2 py-1 text-lg font-medium transition-colors hover:text-green-700 ${
                route.active ? "text-green-700" : "text-muted-foreground"
              }`}
              onClick={() => setOpen(false)}
            >
              {route.label}
            </Link>
          ))}

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="seller" className="border-none">
              <AccordionTrigger className="py-1 px-2 text-lg font-medium hover:text-green-700 hover:no-underline">
                <div className="flex items-center">
                  <ShoppingBag className="h-4 w-4 mr-2" />
                  Seller
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="flex flex-col gap-2 pl-6">
                  {sellerRoutes.map((route) => (
                    <Link
                      key={route.href}
                      href={route.href}
                      className={`flex items-center py-1 text-base transition-colors hover:text-green-700 ${
                        route.active ? "text-green-700" : "text-muted-foreground"
                      }`}
                      onClick={() => setOpen(false)}
                    >
                      {route.label}
                      {route.badge && <Badge className="ml-2 bg-green-500 hover:bg-green-600">{route.badge}</Badge>}
                    </Link>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="orders" className="border-none">
              <AccordionTrigger className="py-1 px-2 text-lg font-medium hover:text-green-700 hover:no-underline">
                <div className="flex items-center">
                  <Package className="h-4 w-4 mr-2" />
                  Orders
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="flex flex-col gap-2 pl-6">
                  {orderRoutes.map((route) => (
                    <Link
                      key={route.href}
                      href={route.href}
                      className={`flex items-center py-1 text-base transition-colors hover:text-green-700 ${
                        route.active ? "text-green-700" : "text-muted-foreground"
                      }`}
                      onClick={() => setOpen(false)}
                    >
                      {route.label}
                      {route.badge && <Badge className="ml-2 bg-green-500 hover:bg-green-600">{route.badge}</Badge>}
                    </Link>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="account" className="border-none">
              <AccordionTrigger className="py-1 px-2 text-lg font-medium hover:text-green-700 hover:no-underline">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Account
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="flex flex-col gap-2 pl-6">
                  {accountRoutes.map((route) => (
                    <Link
                      key={route.href}
                      href={route.href}
                      className={`flex items-center py-1 text-base transition-colors hover:text-green-700 ${
                        route.active ? "text-green-700" : "text-muted-foreground"
                      }`}
                      onClick={() => setOpen(false)}
                    >
                      {route.label}
                    </Link>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </SheetContent>
    </Sheet>
  )
}
