"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface InventoryItem {
  id: number
  strainName: string
  batchId: string
  quantity: string
  quantityValue: number
  unit: string
  thcPercentage: number
  harvestDate: string
  expiryDate: string
  status: "in-stock" | "low-stock" | "out-of-stock" | "expiring-soon" | "expired"
  price: number
  location: string
  lastUpdated: string
}

interface InventoryBatchModalProps {
  isOpen: boolean
  onClose: () => void
  item: InventoryItem
  onUpdate: (updatedItem: InventoryItem) => void
}

export function InventoryBatchModal({ isOpen, onClose, item, onUpdate }: InventoryBatchModalProps) {
  const [formData, setFormData] = useState({
    ...item,
    harvestDate: new Date(item.harvestDate),
    expiryDate: new Date(item.expiryDate),
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target

    if (name === "quantityValue") {
      const numValue = Number.parseFloat(value)
      setFormData({
        ...formData,
        quantityValue: numValue,
        quantity: `${numValue} ${formData.unit}`,
      })
    } else {
      setFormData({
        ...formData,
        [name]: value,
      })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Convert dates back to strings for the API
    const updatedItem = {
      ...formData,
      harvestDate: format(formData.harvestDate, "yyyy-MM-dd"),
      expiryDate: format(formData.expiryDate, "yyyy-MM-dd"),
      lastUpdated: format(new Date(), "yyyy-MM-dd"),
    }

    // Simulate API call
    setTimeout(() => {
      onUpdate(updatedItem)
      setIsSubmitting(false)
    }, 500)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Update Batch: {item.batchId}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="strainName">Strain Name</Label>
              <Input id="strainName" name="strainName" value={formData.strainName} onChange={handleChange} disabled />
            </div>
            <div className="space-y-2">
              <Label htmlFor="batchId">Batch ID</Label>
              <Input id="batchId" name="batchId" value={formData.batchId} onChange={handleChange} disabled />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantityValue">Quantity</Label>
              <div className="flex">
                <Input
                  id="quantityValue"
                  name="quantityValue"
                  type="number"
                  step="0.1"
                  value={formData.quantityValue}
                  onChange={handleChange}
                  className="rounded-r-none"
                />
                <select
                  name="unit"
                  value={formData.unit}
                  onChange={handleChange}
                  className="rounded-l-none border border-input bg-background px-3 py-2"
                >
                  <option value="lbs">lbs</option>
                  <option value="kg">kg</option>
                  <option value="g">g</option>
                  <option value="oz">oz</option>
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="thcPercentage">THC Percentage</Label>
              <Input
                id="thcPercentage"
                name="thcPercentage"
                type="number"
                step="0.1"
                value={formData.thcPercentage}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Harvest Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.harvestDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.harvestDate ? format(new Date(formData.harvestDate), "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={new Date(formData.harvestDate)}
                    onSelect={(date) => {
                      if (date) {
                        setFormData({ ...formData, harvestDate: date })
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label>Expiry Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.expiryDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.expiryDate ? format(new Date(formData.expiryDate), "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={new Date(formData.expiryDate)}
                    onSelect={(date) => {
                      if (date) {
                        setFormData({ ...formData, expiryDate: date })
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Storage Location</Label>
            <Input id="location" name="location" value={formData.location} onChange={handleChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="w-full rounded-md border border-input bg-background px-3 py-2"
            >
              <option value="in-stock">In Stock</option>
              <option value="low-stock">Low Stock</option>
              <option value="out-of-stock">Out of Stock</option>
              <option value="expiring-soon">Expiring Soon</option>
              <option value="expired">Expired</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" name="notes" placeholder="Add any additional notes about this batch..." rows={3} />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Updating..." : "Update Batch"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
