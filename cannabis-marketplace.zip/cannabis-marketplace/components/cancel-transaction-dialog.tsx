"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "sonner"
import { XCircle } from "lucide-react"

interface CancelTransactionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  transactionId: string
}

export function CancelTransactionDialog({ open, onOpenChange, transactionId }: CancelTransactionDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [cancelReason, setCancelReason] = useState("changed_mind")
  const [cancelDetails, setCancelDetails] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      onOpenChange(false)
      toast.success("Transaction cancelled successfully")

      // Reset form
      setCancelReason("changed_mind")
      setCancelDetails("")
    }, 1500)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-500" />
            Cancel Transaction
          </DialogTitle>
          <DialogDescription>
            Are you sure you want to cancel this transaction? This action cannot be undone.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Reason for Cancellation</Label>
            <RadioGroup value={cancelReason} onValueChange={setCancelReason}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="changed_mind" id="changed_mind" />
                <Label htmlFor="changed_mind">Changed my mind</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="found_alternative" id="found_alternative" />
                <Label htmlFor="found_alternative">Found an alternative product</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="price_issue" id="price_issue" />
                <Label htmlFor="price_issue">Price or payment issues</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="other" />
                <Label htmlFor="other">Other</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="details">Additional Details (Optional)</Label>
            <Textarea
              id="details"
              placeholder="Please provide any additional information..."
              value={cancelDetails}
              onChange={(e) => setCancelDetails(e.target.value)}
              rows={3}
            />
          </div>

          <DialogFooter className="mt-6">
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Go Back
            </Button>
            <Button type="submit" variant="destructive" disabled={isSubmitting}>
              {isSubmitting ? "Cancelling..." : "Confirm Cancellation"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
