"use client"

import type React from "react"

import { useState } from "react"
import { Search, PlusCircle, Settings, Bell, Shield } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { MainNav } from "./main-nav"
import { MobileNav } from "./mobile-nav"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"

export function Header() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearchExpanded, setIsSearchExpanded] = useState(false)
  const [testingFilter, setTestingFilter] = useState(false)
  const [isVerified, setIsVerified] = useState(true)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
      setIsSearchExpanded(false)
    }
  }

  return (
    <header className="bg-white shadow">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between border-b">
          <div className="flex items-center gap-2 md:gap-6">
            <MobileNav />
            <Link href="/" className="text-xl md:text-2xl font-bold text-green-700">
              Cannabis Marketplace
            </Link>
            <MainNav />
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <Button variant="outline" size="sm" asChild className="hidden md:flex">
              <Link href="/add-listing">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Listing
              </Link>
            </Button>

            {isVerified && (
              <Link href="/profile/verification" className="flex items-center">
                <Badge variant="outline" className="flex items-center gap-1 border-green-500 text-green-700">
                  <Shield className="h-3 w-3" />
                  <span>Verified Seller</span>
                </Badge>
              </Link>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white">
                    3
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel className="flex items-center justify-between">
                  <span>Notifications</span>
                  <Link href="/notifications" className="text-xs text-green-600 hover:underline">
                    View all
                  </Link>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem>
                    <div className="flex flex-col space-y-1">
                      <div className="flex justify-between">
                        <span className="font-medium">New inquiry for Blue Dream</span>
                        <span className="text-xs text-gray-500">2h ago</span>
                      </div>
                      <p className="text-xs text-gray-500">John Doe has inquired about your listing</p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <div className="flex flex-col space-y-1">
                      <div className="flex justify-between">
                        <span className="font-medium">Sour Diesel has been reserved</span>
                        <span className="text-xs text-gray-500">3h ago</span>
                      </div>
                      <p className="text-xs text-gray-500">Sarah Johnson has reserved 2 lbs</p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <div className="flex flex-col space-y-1">
                      <div className="flex justify-between">
                        <span className="font-medium">New message from seller</span>
                        <span className="text-xs text-gray-500">4h ago</span>
                      </div>
                      <p className="text-xs text-gray-500">Green Farms LLC sent you a message</p>
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild className="justify-center text-green-600">
                  <Link href="/notifications">See all notifications</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/analytics">Analytics</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile/verification">Verification</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-4 py-4">
          <form onSubmit={handleSearch} className="relative flex-grow min-w-[200px]">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search strains..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>
          <div className="flex items-center gap-4 w-full md:w-auto mt-2 md:mt-0">
            <select
              className="w-full md:w-40 min-w-[150px] rounded-md border border-input bg-background px-3 py-2 text-sm"
              onChange={(e) => {
                // Handle price filter change
                toast.success(`Price filter set to: ${e.target.value}`)
              }}
            >
              <option value="all">All Prices</option>
              <option value="0-1000">$0 - $1,000</option>
              <option value="1000-5000">$1,000 - $5,000</option>
              <option value="5000+">$5,000+</option>
            </select>
            <div className="flex items-center space-x-2">
              <Switch
                id="testing"
                checked={testingFilter}
                onCheckedChange={(checked) => {
                  setTestingFilter(checked)
                  toast.success(`Testing filter ${checked ? "enabled" : "disabled"}`)
                }}
              />
              <label htmlFor="testing" className="text-sm text-gray-600 cursor-pointer">
                Testing % &gt; 20%
              </label>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
