"use client"

import type React from "react"

import { useState } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { CalendarIcon, Clock, Truck, Package, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface DeliveryOptionsProps {
  onSelectDeliveryMethod: (method: string) => void
  onSelectDeliveryDate: (date: Date | undefined) => void
  onSelectDeliveryTime: (time: string) => void
  onAddDeliveryInstructions: (instructions: string) => void
  onAddDeliveryAddress: (address: DeliveryAddress) => void
  selectedMethod?: string
  selectedDate?: Date
  selectedTime?: string
  deliveryInstructions?: string
  deliveryAddress?: DeliveryAddress
}

export interface DeliveryAddress {
  street: string
  city: string
  state: string
  zipCode: string
  businessName?: string
  licenseNumber?: string
}

const deliveryMethods = [
  {
    id: "standard",
    name: "Standard Delivery",
    description: "3-5 business days",
    icon: <Truck className="h-5 w-5 text-gray-500" />,
    price: "$150",
  },
  {
    id: "express",
    name: "Express Delivery",
    description: "1-2 business days",
    icon: <Package className="h-5 w-5 text-gray-500" />,
    price: "$250",
  },
  {
    id: "same_day",
    name: "Same Day Delivery",
    description: "Available in select areas",
    icon: <Clock className="h-5 w-5 text-gray-500" />,
    price: "$350",
  },
]

const timeSlots = ["9:00 AM - 12:00 PM", "12:00 PM - 3:00 PM", "3:00 PM - 6:00 PM", "6:00 PM - 9:00 PM"]

export function DeliveryOptions({
  onSelectDeliveryMethod,
  onSelectDeliveryDate,
  onSelectDeliveryTime,
  onAddDeliveryInstructions,
  onAddDeliveryAddress,
  selectedMethod = "standard",
  selectedDate,
  selectedTime,
  deliveryInstructions = "",
  deliveryAddress = { street: "", city: "", state: "", zipCode: "", businessName: "", licenseNumber: "" },
}: DeliveryOptionsProps) {
  const [method, setMethod] = useState(selectedMethod)
  const [date, setDate] = useState<Date | undefined>(selectedDate)
  const [time, setTime] = useState(selectedTime || timeSlots[0])
  const [instructions, setInstructions] = useState(deliveryInstructions)
  const [address, setAddress] = useState<DeliveryAddress>(deliveryAddress)
  const [addressErrors, setAddressErrors] = useState<Partial<Record<keyof DeliveryAddress, string>>>({})

  // Get the minimum allowed date (tomorrow)
  const getMinDate = () => {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    return tomorrow
  }

  // Get the maximum allowed date (30 days from now)
  const getMaxDate = () => {
    const maxDate = new Date()
    maxDate.setDate(maxDate.getDate() + 30)
    return maxDate
  }

  const handleMethodChange = (value: string) => {
    setMethod(value)
    onSelectDeliveryMethod(value)
  }

  const handleDateChange = (date: Date | undefined) => {
    setDate(date)
    onSelectDeliveryDate(date)
  }

  const handleTimeChange = (value: string) => {
    setTime(value)
    onSelectDeliveryTime(value)
  }

  const handleInstructionsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInstructions(e.target.value)
    onAddDeliveryInstructions(e.target.value)
  }

  const handleAddressChange = (field: keyof DeliveryAddress, value: string) => {
    const newAddress = { ...address, [field]: value }
    setAddress(newAddress)

    // Validate the field
    validateField(field, value)

    onAddDeliveryAddress(newAddress)
  }

  const validateField = (field: keyof DeliveryAddress, value: string) => {
    const newErrors = { ...addressErrors }

    switch (field) {
      case "street":
        if (!value.trim()) {
          newErrors.street = "Street address is required"
        } else {
          delete newErrors.street
        }
        break
      case "city":
        if (!value.trim()) {
          newErrors.city = "City is required"
        } else {
          delete newErrors.city
        }
        break
      case "state":
        if (!value.trim()) {
          newErrors.state = "State is required"
        } else {
          delete newErrors.state
        }
        break
      case "zipCode":
        if (!value.trim()) {
          newErrors.zipCode = "ZIP code is required"
        } else if (!/^\d{5}(-\d{4})?$/.test(value)) {
          newErrors.zipCode = "Enter a valid ZIP code"
        } else {
          delete newErrors.zipCode
        }
        break
      case "licenseNumber":
        if (value.trim() && !/^[A-Z0-9-]{5,15}$/i.test(value)) {
          newErrors.licenseNumber = "Enter a valid license number"
        } else {
          delete newErrors.licenseNumber
        }
        break
    }

    setAddressErrors(newErrors)
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-3">Delivery Method</h3>
        <RadioGroup value={method} onValueChange={handleMethodChange} className="space-y-3">
          {deliveryMethods.map((deliveryMethod) => (
            <div key={deliveryMethod.id}>
              <RadioGroupItem value={deliveryMethod.id} id={deliveryMethod.id} className="peer sr-only" />
              <Label
                htmlFor={deliveryMethod.id}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-green-500 [&:has([data-state=checked])]:border-green-500 cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  {deliveryMethod.icon}
                  <div>
                    <div className="font-medium">{deliveryMethod.name}</div>
                    <div className="text-sm text-muted-foreground">{deliveryMethod.description}</div>
                  </div>
                </div>
                <div className="font-medium mt-2 sm:mt-0">{deliveryMethod.price}</div>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <h3 className="text-lg font-medium mb-3">Delivery Date</h3>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Select date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={handleDateChange}
                disabled={(date) => {
                  // Disable dates before tomorrow and after 30 days from now
                  return date < getMinDate() || date > getMaxDate()
                }}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        <div>
          <h3 className="text-lg font-medium mb-3">Delivery Time</h3>
          <Select value={time} onValueChange={handleTimeChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select time slot" />
            </SelectTrigger>
            <SelectContent>
              {timeSlots.map((slot) => (
                <SelectItem key={slot} value={slot}>
                  {slot}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-3">Delivery Address</h3>
        <Card>
          <CardContent className="p-4 space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="street">Street Address</Label>
                <Input
                  id="street"
                  value={address.street}
                  onChange={(e) => handleAddressChange("street", e.target.value)}
                  placeholder="123 Main St"
                  className={addressErrors.street ? "border-red-500" : ""}
                />
                {addressErrors.street && <p className="text-sm text-red-500">{addressErrors.street}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={address.city}
                  onChange={(e) => handleAddressChange("city", e.target.value)}
                  placeholder="San Francisco"
                  className={addressErrors.city ? "border-red-500" : ""}
                />
                {addressErrors.city && <p className="text-sm text-red-500">{addressErrors.city}</p>}
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={address.state}
                  onChange={(e) => handleAddressChange("state", e.target.value)}
                  placeholder="CA"
                  className={addressErrors.state ? "border-red-500" : ""}
                />
                {addressErrors.state && <p className="text-sm text-red-500">{addressErrors.state}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input
                  id="zipCode"
                  value={address.zipCode}
                  onChange={(e) => handleAddressChange("zipCode", e.target.value)}
                  placeholder="94103"
                  className={addressErrors.zipCode ? "border-red-500" : ""}
                />
                {addressErrors.zipCode && <p className="text-sm text-red-500">{addressErrors.zipCode}</p>}
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="businessName">Business Name (Optional)</Label>
                <Input
                  id="businessName"
                  value={address.businessName}
                  onChange={(e) => handleAddressChange("businessName", e.target.value)}
                  placeholder="Green Leaf Dispensary"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="licenseNumber">License Number (Optional)</Label>
                <Input
                  id="licenseNumber"
                  value={address.licenseNumber}
                  onChange={(e) => handleAddressChange("licenseNumber", e.target.value)}
                  placeholder="C10-0000123-LIC"
                  className={addressErrors.licenseNumber ? "border-red-500" : ""}
                />
                {addressErrors.licenseNumber && <p className="text-sm text-red-500">{addressErrors.licenseNumber}</p>}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-3">Delivery Instructions</h3>
        <Textarea
          value={instructions}
          onChange={handleInstructionsChange}
          placeholder="Add any special instructions for delivery (gate code, business hours, etc.)"
          className="min-h-[100px]"
        />
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          All deliveries require ID verification and signature upon receipt. Please ensure someone 21+ is available to
          receive the delivery.
        </AlertDescription>
      </Alert>
    </div>
  )
}
