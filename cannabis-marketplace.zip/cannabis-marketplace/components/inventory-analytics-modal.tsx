"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface InventoryItem {
  id: number
  strainName: string
  batchId: string
  quantity: string
  quantityValue: number
  unit: string
  thcPercentage: number
  harvestDate: string
  expiryDate: string
  status: "in-stock" | "low-stock" | "out-of-stock" | "expiring-soon" | "expired"
  price: number
  location: string
  lastUpdated: string
}

interface InventoryAnalyticsModalProps {
  isOpen: boolean
  onClose: () => void
  inventory: InventoryItem[]
}

export function InventoryAnalyticsModal({ isOpen, onClose, inventory }: InventoryAnalyticsModalProps) {
  // Calculate inventory by status
  const inventoryByStatus = [
    { name: "In Stock", value: inventory.filter((item) => item.status === "in-stock").length },
    { name: "Low Stock", value: inventory.filter((item) => item.status === "low-stock").length },
    { name: "Out of Stock", value: inventory.filter((item) => item.status === "out-of-stock").length },
    { name: "Expiring Soon", value: inventory.filter((item) => item.status === "expiring-soon").length },
    { name: "Expired", value: inventory.filter((item) => item.status === "expired").length },
  ]

  // Calculate inventory by location
  const inventoryByLocation = inventory.reduce(
    (acc, item) => {
      const location = acc.find((loc) => loc.name === item.location)
      if (location) {
        location.value += 1
      } else {
        acc.push({ name: item.location, value: 1 })
      }
      return acc
    },
    [] as { name: string; value: number }[],
  )

  // Calculate inventory value by strain
  const inventoryValueByStrain = inventory
    .filter((item) => item.status !== "out-of-stock" && item.status !== "expired")
    .reduce(
      (acc, item) => {
        const strain = acc.find((s) => s.name === item.strainName)
        if (strain) {
          strain.value += item.price * item.quantityValue
        } else {
          acc.push({ name: item.strainName, value: item.price * item.quantityValue })
        }
        return acc
      },
      [] as { name: string; value: number }[],
    )
    .sort((a, b) => b.value - a.value)
    .slice(0, 5) // Top 5 strains by value

  // Calculate inventory quantity by strain
  const inventoryQuantityByStrain = inventory
    .filter((item) => item.status !== "out-of-stock" && item.status !== "expired")
    .reduce(
      (acc, item) => {
        const strain = acc.find((s) => s.name === item.strainName)
        if (strain) {
          strain.value += item.quantityValue
        } else {
          acc.push({ name: item.strainName, value: item.quantityValue })
        }
        return acc
      },
      [] as { name: string; value: number }[],
    )
    .sort((a, b) => b.value - a.value)
    .slice(0, 5) // Top 5 strains by quantity

  // Colors for pie charts
  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Inventory Analytics</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="value">Value Analysis</TabsTrigger>
            <TabsTrigger value="turnover">Turnover</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Inventory by Status</CardTitle>
                  <CardDescription>Distribution of inventory items by status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={inventoryByStatus}
                          cx="50%"
                          cy="50%"
                          labelLine={true}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {inventoryByStatus.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} items`, "Count"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Inventory by Location</CardTitle>
                  <CardDescription>Distribution of inventory items by storage location</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={inventoryByLocation}
                          cx="50%"
                          cy="50%"
                          labelLine={true}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {inventoryByLocation.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} items`, "Count"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Top Strains by Value</CardTitle>
                  <CardDescription>Highest value strains in inventory</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={inventoryValueByStrain}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Value"]} />
                        <Legend />
                        <Bar dataKey="value" name="Value ($)" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="value">
            <div className="grid grid-cols-1 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Value by Strain</CardTitle>
                  <CardDescription>Total value of each strain in inventory</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={inventoryValueByStrain}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis type="category" dataKey="name" />
                        <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, "Value"]} />
                        <Legend />
                        <Bar dataKey="value" name="Value ($)" fill="#00C49F" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Inventory Quantity by Strain</CardTitle>
                  <CardDescription>Total quantity of each strain in inventory</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={inventoryQuantityByStrain}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis type="category" dataKey="name" />
                        <Tooltip formatter={(value) => [`${value.toFixed(1)} lbs`, "Quantity"]} />
                        <Legend />
                        <Bar dataKey="value" name="Quantity (lbs)" fill="#0088FE" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="turnover">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Turnover Analysis</CardTitle>
                <CardDescription>This feature will be available in a future update</CardDescription>
              </CardHeader>
              <CardContent className="flex items-center justify-center h-[400px]">
                <p className="text-muted-foreground">
                  Turnover analysis requires sales data integration. This feature is coming soon.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
