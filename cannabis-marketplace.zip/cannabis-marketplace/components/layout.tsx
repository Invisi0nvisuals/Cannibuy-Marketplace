import type React from "react"
export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto px-4 py-4 md:py-8">{children}</main>
    </div>
  )
}

// We need to import the Header component
import { Header } from "./header"
