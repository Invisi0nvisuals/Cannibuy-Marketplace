"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollText } from "lucide-react"

interface MessageTemplatesProps {
  onSelectTemplate: (template: string) => void
}

const templates = [
  {
    id: 1,
    title: "Initial Inquiry",
    content:
      "Hello, I'm interested in your listing. Is it still available? I'd like to know more about the THC content and terpene profile.",
  },
  {
    id: 2,
    title: "Price Negotiation",
    content:
      "Thanks for the information. I'm interested in purchasing a larger quantity. Would you be able to offer a discount if I purchase 3 lbs or more?",
  },
  {
    id: 3,
    title: "Request Test Results",
    content:
      "Could you please share the lab test results for this strain? I'm particularly interested in the cannabinoid and terpene profiles.",
  },
  {
    id: 4,
    title: "Shipping Inquiry",
    content:
      "What shipping options are available for this order? I'm located in [YOUR LOCATION] and would like to know the estimated delivery time.",
  },
  {
    id: 5,
    title: "Follow-up",
    content:
      "Just following up on my previous message. I'm still interested in your listing and would appreciate any additional information you can provide.",
  },
  {
    id: 6,
    title: "Reservation Request",
    content:
      "I'd like to reserve this strain. Can you hold it for me until [DATE]? I'll complete the purchase by then.",
  },
]

export function MessageTemplates({ onSelectTemplate }: MessageTemplatesProps) {
  const [open, setOpen] = useState(false)

  const handleSelectTemplate = (content: string) => {
    onSelectTemplate(content)
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" title="Message Templates">
          <ScrollText className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Message Templates</DialogTitle>
          <DialogDescription>Select a template to quickly send common messages</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {templates.map((template) => (
            <div
              key={template.id}
              className="cursor-pointer rounded-lg border p-3 transition-colors hover:bg-gray-50"
              onClick={() => handleSelectTemplate(template.content)}
            >
              <h3 className="font-medium">{template.title}</h3>
              <p className="mt-1 text-sm text-gray-600 line-clamp-2">{template.content}</p>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
