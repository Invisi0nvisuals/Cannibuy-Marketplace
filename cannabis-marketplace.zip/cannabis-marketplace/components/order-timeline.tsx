"use client"

import { CheckCircle, Package, Truck, Clock, AlertTriangle } from "lucide-react"
import { format, addDays } from "date-fns"

interface Order {
  id: string
  status: "processing" | "shipped" | "in_transit" | "delivered" | "cancelled"
  createdAt: string
  trackingNumber?: string
  estimatedDelivery?: string
}

interface OrderTimelineProps {
  order: Order
}

export function OrderTimeline({ order }: OrderTimelineProps) {
  // Calculate dates based on order creation date
  const orderDate = new Date(order.createdAt)
  const shippedDate = order.status === "processing" ? null : addDays(orderDate, 1)
  const inTransitDate = order.status === "processing" || order.status === "shipped" ? null : addDays(orderDate, 2)
  const deliveredDate = order.status === "delivered" ? new Date(order.estimatedDelivery || "") : null

  const timelineSteps = [
    {
      title: "Order Placed",
      description: `${format(orderDate, "MMM d, yyyy")} at ${format(orderDate, "h:mm a")}`,
      icon: <Clock className="h-4 w-4 text-green-600" />,
      status: "completed",
    },
    {
      title: "Processing",
      description:
        order.status === "processing"
          ? "Your order is being processed"
          : `${format(addDays(orderDate, 1), "MMM d, yyyy")}`,
      icon: <Package className="h-4 w-4" />,
      status: order.status === "processing" ? "current" : order.status === "cancelled" ? "cancelled" : "completed",
    },
    {
      title: "Shipped",
      description: shippedDate ? format(shippedDate, "MMM d, yyyy") : "Pending",
      icon: <Package className="h-4 w-4" />,
      status:
        order.status === "processing"
          ? "pending"
          : order.status === "shipped"
            ? "current"
            : order.status === "cancelled"
              ? "cancelled"
              : "completed",
    },
    {
      title: "In Transit",
      description: inTransitDate ? format(inTransitDate, "MMM d, yyyy") : "Pending",
      icon: <Truck className="h-4 w-4" />,
      status:
        order.status === "processing" || order.status === "shipped"
          ? "pending"
          : order.status === "in_transit"
            ? "current"
            : order.status === "cancelled"
              ? "cancelled"
              : "completed",
    },
    {
      title: "Delivered",
      description: deliveredDate ? format(deliveredDate, "MMM d, yyyy") : "Pending",
      icon: <CheckCircle className="h-4 w-4" />,
      status: order.status === "delivered" ? "completed" : order.status === "cancelled" ? "cancelled" : "pending",
    },
  ]

  if (order.status === "cancelled") {
    timelineSteps.push({
      title: "Cancelled",
      description: `${format(addDays(orderDate, 1), "MMM d, yyyy")}`,
      icon: <AlertTriangle className="h-4 w-4 text-red-600" />,
      status: "current",
    })
  }

  return (
    <div className="space-y-4">
      {timelineSteps.map((step, index) => (
        <div key={index} className="flex items-start gap-3">
          <div
            className={`mt-0.5 h-6 w-6 rounded-full flex items-center justify-center ${
              step.status === "completed"
                ? "bg-green-100"
                : step.status === "current"
                  ? "bg-blue-100"
                  : step.status === "cancelled"
                    ? "bg-red-100"
                    : "bg-gray-100"
            }`}
          >
            <span
              className={
                step.status === "completed"
                  ? "text-green-600"
                  : step.status === "current"
                    ? "text-blue-600"
                    : step.status === "cancelled"
                      ? "text-red-600"
                      : "text-gray-400"
              }
            >
              {step.icon}
            </span>
          </div>
          <div className="flex-1">
            <p className="font-medium">{step.title}</p>
            <p className="text-sm text-gray-500">{step.description}</p>
            {step.status === "current" && order.trackingNumber && step.title !== "Cancelled" && (
              <p className="text-xs text-blue-600 mt-1">Tracking: {order.trackingNumber}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
