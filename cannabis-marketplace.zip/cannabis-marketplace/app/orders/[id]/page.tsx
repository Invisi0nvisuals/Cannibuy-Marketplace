"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { format } from "date-fns"
import {
  ArrowLeft,
  Package,
  Truck,
  CheckCircle,
  Clock,
  AlertTriangle,
  MapPin,
  Calendar,
  FileText,
  MessageSquare,
  HelpCircle,
} from "lucide-react"
import Link from "next/link"
import { toast } from "sonner"

interface Order {
  id: string
  strainId: number
  strainName: string
  quantity: number
  price: number
  total: number
  deliveryMethod: string
  deliveryDate: string
  deliveryTime: string
  deliveryAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    businessName?: string
    licenseNumber?: string
  }
  deliveryInstructions?: string
  status: "processing" | "shipped" | "in_transit" | "delivered" | "cancelled"
  createdAt: string
  trackingNumber?: string
  estimatedDelivery?: string
}

export default function OrderDetailPage() {
  const params = useParams()
  const router = useRouter()
  const id = params.id as string

  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load order from localStorage
    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      if (savedOrders) {
        const orders = JSON.parse(savedOrders)
        const foundOrder = orders.find((o: Order) => o.id === id)
        if (foundOrder) {
          setOrder(foundOrder)
        }
      }
    } catch (error) {
      console.error("Error loading order:", error)
    } finally {
      setIsLoading(false)
    }
  }, [id])

  // Helper function to get status badge
  const getStatusBadge = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="mr-1 h-3 w-3" /> Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <Package className="mr-1 h-3 w-3" /> Shipped
          </Badge>
        )
      case "in_transit":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            <Truck className="mr-1 h-3 w-3" /> In Transit
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" /> Delivered
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <AlertTriangle className="mr-1 h-3 w-3" /> Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleContactSupport = () => {
    toast.success("Support request submitted", {
      description: "A customer service representative will contact you shortly.",
    })
  }

  const handleCancelOrder = () => {
    toast.success("Cancellation request submitted", {
      description: "Your cancellation request is being processed.",
    })
  }

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        </div>
      </Layout>
    )
  }

  if (!order) {
    return (
      <Layout>
        <div className="mx-auto max-w-4xl text-center py-12">
          <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
          <p className="mb-6">The order you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/orders">Back to Orders</Link>
          </Button>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <Button variant="ghost" className="mb-4" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Orders
        </Button>

        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
              Order {order.id}
              {getStatusBadge(order.status)}
            </h1>
            <p className="text-gray-500 mt-1">Placed on {format(new Date(order.createdAt), "MMMM d, yyyy")}</p>
          </div>
          <div className="flex gap-2">
            {(order.status === "shipped" || order.status === "in_transit") && (
              <Button variant="outline" size="sm" asChild>
                <Link href={`/orders/${order.id}/track`}>
                  <Truck className="mr-2 h-4 w-4" />
                  Track Order
                </Link>
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={handleContactSupport}>
              <HelpCircle className="mr-2 h-4 w-4" />
              Support
            </Button>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Order Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Product</p>
                    <p className="font-medium">{order.strainName}</p>
                    <p className="text-sm text-gray-500">Quantity: {order.quantity} lbs</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Price</p>
                    <p className="font-medium">${order.price.toLocaleString()} per lb</p>
                    <p className="text-sm text-gray-500">Total: ${order.total.toLocaleString()}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <p className="font-medium">Delivery Address</p>
                  </div>
                  <div className="pl-6">
                    {order.deliveryAddress.businessName && (
                      <p className="font-medium">{order.deliveryAddress.businessName}</p>
                    )}
                    <p>{order.deliveryAddress.street}</p>
                    <p>
                      {order.deliveryAddress.city}, {order.deliveryAddress.state} {order.deliveryAddress.zipCode}
                    </p>
                    {order.deliveryAddress.licenseNumber && (
                      <p className="text-sm text-gray-500 mt-1">License: {order.deliveryAddress.licenseNumber}</p>
                    )}
                  </div>
                </div>

                <Separator />

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <p className="font-medium">Delivery Schedule</p>
                  </div>
                  <div className="pl-6">
                    <p>
                      <span className="capitalize">{order.deliveryMethod.replace("_", " ")}</span> Delivery
                    </p>
                    <p>
                      {format(new Date(order.deliveryDate), "MMMM d, yyyy")}, {order.deliveryTime}
                    </p>
                    {order.estimatedDelivery && (
                      <p className="text-sm text-gray-500 mt-1">
                        Estimated delivery: {format(new Date(order.estimatedDelivery), "MMMM d, yyyy")}
                      </p>
                    )}
                  </div>
                </div>

                {order.deliveryInstructions && (
                  <>
                    <Separator />
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-4 w-4 text-gray-500" />
                        <p className="font-medium">Delivery Instructions</p>
                      </div>
                      <div className="pl-6">
                        <p className="text-sm">{order.deliveryInstructions}</p>
                      </div>
                    </div>
                  </>
                )}

                {order.trackingNumber && (
                  <>
                    <Separator />
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Truck className="h-4 w-4 text-gray-500" />
                        <p className="font-medium">Tracking Information</p>
                      </div>
                      <div className="pl-6">
                        <p>Tracking Number: {order.trackingNumber}</p>
                        <Button variant="link" className="h-auto p-0 mt-1" asChild>
                          <Link href={`/orders/${order.id}/track`}>View Tracking Details</Link>
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => router.back()}>
                  Back to Orders
                </Button>
                {(order.status === "shipped" || order.status === "in_transit") && (
                  <Button asChild>
                    <Link href={`/orders/${order.id}/track`}>
                      <Truck className="mr-2 h-4 w-4" />
                      Track Delivery
                    </Link>
                  </Button>
                )}
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Order Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-6 w-6 rounded-full bg-green-500 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 text-white" />
                      </div>
                      <div className="w-0.5 h-full bg-gray-200 my-1"></div>
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                        <h4 className="font-medium">Order Placed</h4>
                        <span className="text-sm text-gray-500">
                          {format(new Date(order.createdAt), "MMM d, yyyy")}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">Your order has been received and is being processed</p>
                    </div>
                  </div>

                  {(order.status === "shipped" || order.status === "in_transit" || order.status === "delivered") && (
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="h-6 w-6 rounded-full bg-green-500 flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 text-white" />
                        </div>
                        <div className="w-0.5 h-full bg-gray-200 my-1"></div>
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                          <h4 className="font-medium">Order Shipped</h4>
                          <span className="text-sm text-gray-500">
                            {format(new Date(order.createdAt), "MMM d, yyyy")}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">Your order has been shipped and is on its way</p>
                      </div>
                    </div>
                  )}

                  {(order.status === "in_transit" || order.status === "delivered") && (
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="h-6 w-6 rounded-full bg-green-500 flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 text-white" />
                        </div>
                        <div className="w-0.5 h-full bg-gray-200 my-1"></div>
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                          <h4 className="font-medium">In Transit</h4>
                          <span className="text-sm text-gray-500">
                            {format(new Date(order.createdAt), "MMM d, yyyy")}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">Your order is on its way to you</p>
                      </div>
                    </div>
                  )}

                  {order.status === "delivered" && (
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="h-6 w-6 rounded-full bg-green-500 flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 text-white" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                          <h4 className="font-medium">Delivered</h4>
                          <span className="text-sm text-gray-500">
                            {format(new Date(order.estimatedDelivery || ""), "MMM d, yyyy")}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">Your order has been delivered</p>
                      </div>
                    </div>
                  )}

                  {order.status === "cancelled" && (
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="h-6 w-6 rounded-full bg-red-500 flex items-center justify-center">
                          <AlertTriangle className="h-4 w-4 text-white" />
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                          <h4 className="font-medium">Cancelled</h4>
                          <span className="text-sm text-gray-500">
                            {format(new Date(order.createdAt), "MMM d, yyyy")}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">Your order has been cancelled</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Subtotal</span>
                    <span>${(order.price * order.quantity).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Delivery Fee</span>
                    <span>${(order.total - order.price * order.quantity).toLocaleString()}</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${order.total.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Need Help?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/messages">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Contact Seller
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" onClick={handleContactSupport}>
                    <HelpCircle className="mr-2 h-4 w-4" />
                    Customer Support
                  </Button>
                  {order.status !== "delivered" && order.status !== "cancelled" && (
                    <Button
                      variant="outline"
                      className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                      onClick={handleCancelOrder}
                    >
                      <AlertTriangle className="mr-2 h-4 w-4" />
                      Cancel Order
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  )
}
