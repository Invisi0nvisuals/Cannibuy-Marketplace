"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { format } from "date-fns"
import { ArrowLeft, Package, Truck, CheckCircle, Clock, AlertTriangle, MapPin, MessageSquare } from "lucide-react"
import Link from "next/link"
import { OrderTimeline } from "@/components/order-timeline"

interface Order {
  id: string
  strainId: number
  strainName: string
  quantity: number
  price: number
  total: number
  deliveryMethod: string
  deliveryDate: string
  deliveryTime: string
  deliveryAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    businessName?: string
    licenseNumber?: string
  }
  deliveryInstructions?: string
  status: "processing" | "shipped" | "in_transit" | "delivered" | "cancelled"
  createdAt: string
  trackingNumber?: string
  estimatedDelivery?: string
}

// Mock tracking events for demonstration
interface TrackingEvent {
  date: string
  time: string
  location: string
  status: string
  description: string
}

export default function OrderTrackingPage() {
  const params = useParams()
  const router = useRouter()
  const id = params.id as string

  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [trackingEvents, setTrackingEvents] = useState<TrackingEvent[]>([])

  useEffect(() => {
    // Load order from localStorage
    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      if (savedOrders) {
        const orders = JSON.parse(savedOrders)
        const foundOrder = orders.find((o: Order) => o.id === id)
        if (foundOrder) {
          setOrder(foundOrder)

          // Generate mock tracking events based on order status
          const events: TrackingEvent[] = []
          const orderDate = new Date(foundOrder.createdAt)

          // Order placed
          events.push({
            date: format(orderDate, "yyyy-MM-dd"),
            time: format(orderDate, "HH:mm"),
            location: "Online",
            status: "Order Placed",
            description: "Your order has been received and is being processed",
          })

          if (foundOrder.status !== "processing" && foundOrder.status !== "cancelled") {
            // Order processed
            const processedDate = new Date(orderDate)
            processedDate.setHours(processedDate.getHours() + 4)
            events.push({
              date: format(processedDate, "yyyy-MM-dd"),
              time: format(processedDate, "HH:mm"),
              location: foundOrder.deliveryAddress.city,
              status: "Order Processed",
              description: "Your order has been processed and is ready for shipping",
            })

            // Order shipped
            const shippedDate = new Date(orderDate)
            shippedDate.setDate(shippedDate.getDate() + 1)
            events.push({
              date: format(shippedDate, "yyyy-MM-dd"),
              time: "09:30",
              location: foundOrder.deliveryAddress.city,
              status: "Order Shipped",
              description: "Your order has been shipped and is on its way",
            })
          }

          if (foundOrder.status === "in_transit" || foundOrder.status === "delivered") {
            // In transit
            const transitDate = new Date(orderDate)
            transitDate.setDate(transitDate.getDate() + 2)
            events.push({
              date: format(transitDate, "yyyy-MM-dd"),
              time: "14:15",
              location: "Distribution Center",
              status: "In Transit",
              description: "Your order is in transit to the delivery address",
            })

            // Out for delivery
            const outForDeliveryDate = new Date(orderDate)
            outForDeliveryDate.setDate(outForDeliveryDate.getDate() + 3)
            events.push({
              date: format(outForDeliveryDate, "yyyy-MM-dd"),
              time: "08:45",
              location: foundOrder.deliveryAddress.city,
              status: "Out for Delivery",
              description: "Your order is out for delivery",
            })
          }

          if (foundOrder.status === "delivered") {
            // Delivered
            const deliveredDate = new Date(foundOrder.estimatedDelivery || "")
            events.push({
              date: format(deliveredDate, "yyyy-MM-dd"),
              time: "14:30",
              location: foundOrder.deliveryAddress.city,
              status: "Delivered",
              description: "Your order has been delivered",
            })
          }

          if (foundOrder.status === "cancelled") {
            // Cancelled
            const cancelledDate = new Date(orderDate)
            cancelledDate.setDate(cancelledDate.getDate() + 1)
            events.push({
              date: format(cancelledDate, "yyyy-MM-dd"),
              time: "10:15",
              location: "System",
              status: "Cancelled",
              description: "Your order has been cancelled",
            })
          }

          // Sort events by date and time (newest first)
          events.sort((a, b) => {
            const dateA = new Date(`${a.date}T${a.time}`)
            const dateB = new Date(`${b.date}T${b.time}`)
            return dateB.getTime() - dateA.getTime()
          })

          setTrackingEvents(events)
        }
      }
    } catch (error) {
      console.error("Error loading order:", error)
    } finally {
      setIsLoading(false)
    }
  }, [id])

  // Helper function to get status badge
  const getStatusBadge = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="mr-1 h-3 w-3" /> Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <Package className="mr-1 h-3 w-3" /> Shipped
          </Badge>
        )
      case "in_transit":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            <Truck className="mr-1 h-3 w-3" /> In Transit
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" /> Delivered
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <AlertTriangle className="mr-1 h-3 w-3" /> Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Helper function to get estimated delivery text
  const getEstimatedDeliveryText = (order: Order) => {
    if (order.status === "delivered") {
      return `Delivered on ${format(new Date(order.estimatedDelivery || ""), "MMMM d, yyyy")}`
    } else if (order.status === "cancelled") {
      return "Order cancelled"
    } else {
      return `Estimated delivery: ${format(new Date(order.estimatedDelivery || ""), "MMMM d, yyyy")}`
    }
  }

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        </div>
      </Layout>
    )
  }

  if (!order) {
    return (
      <Layout>
        <div className="mx-auto max-w-4xl text-center py-12">
          <h2 className="text-2xl font-bold mb-4">Order Not Found</h2>
          <p className="mb-6">The order you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/orders">Back to Orders</Link>
          </Button>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <Button variant="ghost" className="mb-4" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Order Details
        </Button>

        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            Track Order {order.id}
            {getStatusBadge(order.status)}
          </h1>
          <p className="text-gray-500 mt-1">{order.trackingNumber && `Tracking Number: ${order.trackingNumber}`}</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Delivery Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-lg">{order.strainName}</h3>
                    <p className="text-gray-500">Qty: {order.quantity} lbs</p>
                  </div>
                  <div className="bg-gray-100 rounded-full h-2 mb-2">
                    <div
                      className={`h-2 rounded-full ${
                        order.status === "processing"
                          ? "w-1/5 bg-yellow-500"
                          : order.status === "shipped"
                            ? "w-2/5 bg-blue-500"
                            : order.status === "in_transit"
                              ? "w-3/5 bg-purple-500"
                              : order.status === "delivered"
                                ? "w-full bg-green-500"
                                : "w-1/5 bg-red-500"
                      }`}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600">{getEstimatedDeliveryText(order)}</p>
                </div>

                <OrderTimeline order={order} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tracking History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {trackingEvents.map((event, index) => (
                    <div key={index} className="flex gap-4 pb-4 border-b last:border-0">
                      <div className="w-24 flex-shrink-0">
                        <p className="font-medium">{format(new Date(event.date), "MMM d")}</p>
                        <p className="text-sm text-gray-500">{event.time}</p>
                      </div>
                      <div>
                        <p className="font-medium">{event.status}</p>
                        <p className="text-sm text-gray-500">{event.description}</p>
                        <p className="text-xs text-gray-400 mt-1">{event.location}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Delivery Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <p className="font-medium">Delivery Address</p>
                  </div>
                  <div className="pl-6">
                    {order.deliveryAddress.businessName && (
                      <p className="font-medium">{order.deliveryAddress.businessName}</p>
                    )}
                    <p>{order.deliveryAddress.street}</p>
                    <p>
                      {order.deliveryAddress.city}, {order.deliveryAddress.state} {order.deliveryAddress.zipCode}
                    </p>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="font-medium mb-1">Delivery Method</p>
                  <p className="capitalize">{order.deliveryMethod.replace("_", " ")} Delivery</p>
                </div>

                {order.deliveryInstructions && (
                  <>
                    <Separator />
                    <div>
                      <p className="font-medium mb-1">Delivery Instructions</p>
                      <p className="text-sm">{order.deliveryInstructions}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Need Help?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/messages">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Contact Seller
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Truck className="mr-2 h-4 w-4" />
                    Contact Delivery Service
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href={`/orders/${order.id}`}>
                      <Package className="mr-2 h-4 w-4" />
                      View Order Details
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  )
}
