"use client"

import { useState, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, Package, Truck, CheckCircle, Clock, AlertTriangle, ChevronRight } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

interface Order {
  id: string
  strainName: string
  quantity: number
  price: number
  total: number
  status: "processing" | "shipped" | "in_transit" | "delivered" | "cancelled"
  createdAt: string
  estimatedDelivery?: string
  deliveryMethod: string
  deliveryDate: string
  deliveryTime: string
  deliveryAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    businessName?: string
    licenseNumber?: string
  }
  deliveryInstructions?: string
  trackingNumber?: string
}

// Sample orders data
const sampleOrders: Order[] = [
  {
    id: "ORD-12345",
    strainName: "Blue Dream",
    quantity: 5,
    price: 1200,
    total: 6000,
    status: "delivered",
    createdAt: "2023-05-15T10:30:00Z",
    estimatedDelivery: "2023-05-18T14:00:00Z",
    deliveryMethod: "standard",
    deliveryDate: "2023-05-18T14:00:00Z",
    deliveryTime: "2:00 PM - 5:00 PM",
    deliveryAddress: {
      street: "123 Main St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94103",
      businessName: "Green Leaf Dispensary",
    },
    trackingNumber: "TRK-12345",
  },
  {
    id: "ORD-12346",
    strainName: "Sour Diesel",
    quantity: 3,
    price: 1500,
    total: 4500,
    status: "in_transit",
    createdAt: "2023-06-01T09:15:00Z",
    estimatedDelivery: "2023-06-04T12:00:00Z",
    deliveryMethod: "express",
    deliveryDate: "2023-06-04T12:00:00Z",
    deliveryTime: "12:00 PM - 3:00 PM",
    deliveryAddress: {
      street: "456 Market St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94105",
    },
    trackingNumber: "TRK-12346",
  },
  {
    id: "ORD-12347",
    strainName: "Girl Scout Cookies",
    quantity: 2,
    price: 1800,
    total: 3600,
    status: "shipped",
    createdAt: "2023-06-05T14:45:00Z",
    estimatedDelivery: "2023-06-08T10:00:00Z",
    deliveryMethod: "standard",
    deliveryDate: "2023-06-08T10:00:00Z",
    deliveryTime: "10:00 AM - 1:00 PM",
    deliveryAddress: {
      street: "789 Howard St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94103",
    },
    trackingNumber: "TRK-12347",
  },
  {
    id: "ORD-12348",
    strainName: "OG Kush",
    quantity: 4,
    price: 1300,
    total: 5200,
    status: "processing",
    createdAt: "2023-06-07T11:20:00Z",
    estimatedDelivery: "2023-06-10T15:00:00Z",
    deliveryMethod: "standard",
    deliveryDate: "2023-06-10T15:00:00Z",
    deliveryTime: "3:00 PM - 6:00 PM",
    deliveryAddress: {
      street: "101 California St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94111",
    },
  },
  {
    id: "ORD-12349",
    strainName: "Northern Lights",
    quantity: 1,
    price: 1600,
    total: 1600,
    status: "cancelled",
    createdAt: "2023-05-20T08:30:00Z",
    deliveryMethod: "express",
    deliveryDate: "2023-05-23T12:00:00Z",
    deliveryTime: "12:00 PM - 3:00 PM",
    deliveryAddress: {
      street: "555 Mission St",
      city: "San Francisco",
      state: "CA",
      zipCode: "94105",
    },
  },
]

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    // Check if orders exist in localStorage
    const savedOrders = localStorage.getItem("cannabisOrders")
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders))
    } else {
      // Save sample orders to localStorage
      localStorage.setItem("cannabisOrders", JSON.stringify(sampleOrders))
      setOrders(sampleOrders)
    }
  }, [])

  // Filter orders based on search query and active tab
  const filteredOrders = orders.filter((order) => {
    // Search filter
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.strainName.toLowerCase().includes(searchQuery.toLowerCase())

    // Tab filter
    if (activeTab === "all") return matchesSearch
    return matchesSearch && order.status === activeTab
  })

  // Helper function to get status badge
  const getStatusBadge = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="mr-1 h-3 w-3" /> Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <Package className="mr-1 h-3 w-3" /> Shipped
          </Badge>
        )
      case "in_transit":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            <Truck className="mr-1 h-3 w-3" /> In Transit
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" /> Delivered
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <AlertTriangle className="mr-1 h-3 w-3" /> Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <Layout>
      <div className="container mx-auto py-6">
        <h1 className="text-2xl md:text-3xl font-bold mb-6">My Orders</h1>

        <Card>
          <CardHeader>
            <CardTitle>Order History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search orders..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
                <TabsTrigger value="all" className="flex-1">
                  All
                </TabsTrigger>
                <TabsTrigger value="processing" className="flex-1">
                  Processing
                </TabsTrigger>
                <TabsTrigger value="shipped" className="flex-1">
                  Shipped
                </TabsTrigger>
                <TabsTrigger value="in_transit" className="flex-1">
                  In Transit
                </TabsTrigger>
                <TabsTrigger value="delivered" className="flex-1">
                  Delivered
                </TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-0">
                <div className="space-y-4">
                  {filteredOrders.length > 0 ? (
                    filteredOrders.map((order) => (
                      <div
                        key={order.id}
                        className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="mb-4 md:mb-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{order.strainName}</p>
                            {getStatusBadge(order.status)}
                          </div>
                          <p className="text-sm text-gray-500">Order #{order.id}</p>
                          <p className="text-sm text-gray-500">
                            Placed on {format(new Date(order.createdAt), "MMMM d, yyyy")}
                          </p>
                        </div>
                        <div className="flex flex-col md:flex-row gap-2 md:items-center">
                          <div className="text-right md:mr-4">
                            <p className="font-medium">${order.total.toLocaleString()}</p>
                            <p className="text-sm text-gray-500">{order.quantity} lbs</p>
                          </div>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/orders/${order.id}`}>
                              View <ChevronRight className="ml-1 h-4 w-4" />
                            </Link>
                          </Button>
                          {(order.status === "shipped" || order.status === "in_transit") && (
                            <Button size="sm" asChild>
                              <Link href={`/orders/${order.id}/track`}>
                                <Truck className="mr-1 h-4 w-4" /> Track
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <Package className="mx-auto h-12 w-12 text-gray-300" />
                      <p className="mt-2 font-medium">No orders found</p>
                      <p className="text-sm text-gray-500">
                        {searchQuery
                          ? "Try adjusting your search"
                          : activeTab !== "all"
                            ? `You don't have any ${activeTab.replace("_", " ")} orders`
                            : "You haven't placed any orders yet"}
                      </p>
                      {!searchQuery && activeTab === "all" && (
                        <Button className="mt-4" asChild>
                          <Link href="/">Browse Products</Link>
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}
