"use client"

import { useState, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { Search, Package, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

interface Order {
  id: string
  strainId: number
  strainName: string
  quantity: number
  price: number
  total: number
  deliveryMethod: string
  deliveryDate: string
  deliveryTime: string
  deliveryAddress: {
    street: string
    city: string
    state: string
    zipCode: string
    businessName?: string
    licenseNumber?: string
  }
  deliveryInstructions?: string
  status: "processing" | "shipped" | "in_transit" | "delivered" | "cancelled"
  createdAt: string
  trackingNumber?: string
  estimatedDelivery?: string
}

export default function DeliveryTrackingPage() {
  const router = useRouter()
  const [trackingNumber, setTrackingNumber] = useState("")
  const [orderId, setOrderId] = useState("")
  const [recentOrders, setRecentOrders] = useState<Order[]>([])

  useEffect(() => {
    // Load orders from localStorage
    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      if (savedOrders) {
        const orders = JSON.parse(savedOrders)
        // Get the 3 most recent orders that have tracking
        const recent = orders
          .filter((o: Order) => o.status !== "processing" && o.status !== "cancelled")
          .sort((a: Order, b: Order) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 3)
        setRecentOrders(recent)
      }
    } catch (error) {
      console.error("Error loading orders:", error)
    }
  }, [])

  const handleTrackByNumber = () => {
    if (!trackingNumber.trim()) {
      toast.error("Please enter a tracking number")
      return
    }

    // In a real app, we would look up the order by tracking number
    // For now, we'll check if any order has this tracking number
    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      if (savedOrders) {
        const orders = JSON.parse(savedOrders)
        const order = orders.find((o: Order) => o.trackingNumber === trackingNumber)
        if (order) {
          router.push(`/orders/${order.id}/track`)
          return
        }
      }
    } catch (error) {
      console.error("Error checking tracking number:", error)
    }

    // If we don't find a match, create a sample order with this tracking number
    const sampleOrder = {
      id: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
      strainId: 1,
      strainName: "Sample Strain",
      quantity: 2,
      price: 1500,
      total: 3150,
      deliveryMethod: "standard",
      deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      deliveryTime: "12:00 PM - 3:00 PM",
      deliveryAddress: {
        street: "123 Main St",
        city: "San Francisco",
        state: "CA",
        zipCode: "94103",
        businessName: "Green Leaf Dispensary",
      },
      status: "in_transit",
      createdAt: new Date().toISOString(),
      trackingNumber: trackingNumber,
      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    }

    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      let orders = []
      if (savedOrders) {
        orders = JSON.parse(savedOrders)
      }
      orders.push(sampleOrder)
      localStorage.setItem("cannabisOrders", JSON.stringify(orders))
      router.push(`/orders/${sampleOrder.id}/track`)
    } catch (error) {
      console.error("Error creating sample order:", error)
      toast.error("Tracking number not found", {
        description: "Please check the number and try again",
      })
    }
  }

  const handleTrackByOrderId = () => {
    if (!orderId.trim()) {
      toast.error("Please enter an order ID")
      return
    }

    // Check if the order exists in localStorage
    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      if (savedOrders) {
        const orders = JSON.parse(savedOrders)
        const order = orders.find((o: Order) => o.id === orderId)
        if (order) {
          router.push(`/orders/${orderId}/track`)
          return
        }
      }
    } catch (error) {
      console.error("Error checking order:", error)
    }

    // If we don't find a match, create a sample order with this ID
    const sampleOrder = {
      id: orderId,
      strainId: 1,
      strainName: "Sample Strain",
      quantity: 2,
      price: 1500,
      total: 3150,
      deliveryMethod: "standard",
      deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      deliveryTime: "12:00 PM - 3:00 PM",
      deliveryAddress: {
        street: "123 Main St",
        city: "San Francisco",
        state: "CA",
        zipCode: "94103",
        businessName: "Green Leaf Dispensary",
      },
      status: "in_transit",
      createdAt: new Date().toISOString(),
      trackingNumber: `TRK-${Math.floor(10000 + Math.random() * 90000)}`,
      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    }

    try {
      const savedOrders = localStorage.getItem("cannabisOrders")
      let orders = []
      if (savedOrders) {
        orders = JSON.parse(savedOrders)
      }
      orders.push(sampleOrder)
      localStorage.setItem("cannabisOrders", JSON.stringify(orders))
      router.push(`/orders/${sampleOrder.id}/track`)
    } catch (error) {
      console.error("Error creating sample order:", error)
      toast.error("Order not found", {
        description: "Please check the order ID and try again",
      })
    }
  }

  return (
    <Layout>
      <div className="container mx-auto py-6">
        <h1 className="text-2xl md:text-3xl font-bold mb-6">Delivery Tracking</h1>

        <div className="grid gap-6 md:grid-cols-2 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Track by Tracking Number</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Enter tracking number..."
                    className="pl-8"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                  />
                </div>
                <Button onClick={handleTrackByNumber}>Track</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Track by Order ID</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Enter order ID..."
                    className="pl-8"
                    value={orderId}
                    onChange={(e) => setOrderId(e.target.value)}
                  />
                </div>
                <Button onClick={handleTrackByOrderId}>Track</Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
          </CardHeader>
          <CardContent>
            {recentOrders.length > 0 ? (
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        <p className="font-medium">{order.strainName}</p>
                      </div>
                      <p className="text-sm text-gray-500">Order #{order.id}</p>
                      <p className="text-sm text-gray-500">Status: {order.status.replace("_", " ")}</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/orders/${order.id}/track`}>
                        Track <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Package className="mx-auto h-12 w-12 text-gray-300" />
                <p className="mt-2 font-medium">No recent orders found</p>
                <p className="text-sm text-gray-500">Your recent orders with tracking will appear here</p>
                <Button className="mt-4" asChild>
                  <Link href="/orders">View All Orders</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}
