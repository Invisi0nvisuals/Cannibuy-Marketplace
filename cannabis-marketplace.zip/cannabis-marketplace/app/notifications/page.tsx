"use client"

import { useState } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import { Bell, Check, CheckCheck, Clock, MessageCircle, Package, ShoppingCart, Trash2 } from "lucide-react"

// Define notification types
type NotificationType = "inquiry" | "message" | "reservation" | "system" | "update"

interface Notification {
  id: number
  type: NotificationType
  title: string
  description: string
  timestamp: string
  timeAgo: string
  isRead: boolean
  actionUrl?: string
  actionLabel?: string
}

// Sample notification data grouped by time periods
const notificationData: Record<string, Notification[]> = {
  today: [
    {
      id: 1,
      type: "inquiry",
      title: "New Inquiry",
      description: "John Doe has inquired about your Blue Dream listing",
      timestamp: "2023-06-01T10:30:00",
      timeAgo: "2 hours ago",
      isRead: false,
      actionUrl: "/messages",
      actionLabel: "View Message",
    },
    {
      id: 2,
      type: "reservation",
      title: "New Reservation",
      description: "Sarah Johnson has reserved 2 lbs of Sour Diesel",
      timestamp: "2023-06-01T09:15:00",
      timeAgo: "3 hours ago",
      isRead: false,
      actionUrl: "/my-listings",
      actionLabel: "View Listing",
    },
    {
      id: 3,
      type: "message",
      title: "New Message",
      description: "You have a new message from Green Farms LLC",
      timestamp: "2023-06-01T08:45:00",
      timeAgo: "4 hours ago",
      isRead: true,
      actionUrl: "/messages",
      actionLabel: "Reply",
    },
  ],
  yesterday: [
    {
      id: 4,
      type: "system",
      title: "Account Verified",
      description: "Your account has been successfully verified",
      timestamp: "2023-05-31T14:20:00",
      timeAgo: "Yesterday at 2:20 PM",
      isRead: true,
    },
    {
      id: 5,
      type: "update",
      title: "Listing Updated",
      description: "Your Girl Scout Cookies listing has been updated",
      timestamp: "2023-05-31T11:10:00",
      timeAgo: "Yesterday at 11:10 AM",
      isRead: true,
      actionUrl: "/my-listings",
      actionLabel: "View Listing",
    },
  ],
  thisWeek: [
    {
      id: 6,
      type: "inquiry",
      title: "New Inquiry",
      description: "Michael Brown has inquired about your Northern Lights listing",
      timestamp: "2023-05-29T16:45:00",
      timeAgo: "3 days ago",
      isRead: true,
      actionUrl: "/messages",
      actionLabel: "View Message",
    },
    {
      id: 7,
      type: "message",
      title: "New Message",
      description: "You have a new message from High Quality Farms",
      timestamp: "2023-05-28T09:30:00",
      timeAgo: "4 days ago",
      isRead: true,
      actionUrl: "/messages",
      actionLabel: "Reply",
    },
  ],
  earlier: [
    {
      id: 8,
      type: "system",
      title: "Welcome to Cannabis Marketplace",
      description: "Thank you for joining our platform. Start by creating your first listing.",
      timestamp: "2023-05-15T10:00:00",
      timeAgo: "2 weeks ago",
      isRead: true,
      actionUrl: "/add-listing",
      actionLabel: "Add Listing",
    },
  ],
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState(notificationData)
  const [activeTab, setActiveTab] = useState("all")

  // Count unread notifications
  const unreadCount = Object.values(notifications)
    .flat()
    .filter((notification) => !notification.isRead).length

  // Mark all as read
  const markAllAsRead = () => {
    const updatedNotifications = { ...notifications }

    Object.keys(updatedNotifications).forEach((timeframe) => {
      updatedNotifications[timeframe] = updatedNotifications[timeframe].map((notification) => ({
        ...notification,
        isRead: true,
      }))
    })

    setNotifications(updatedNotifications)
    toast.success("All notifications marked as read")
  }

  // Mark single notification as read
  const markAsRead = (id: number) => {
    const updatedNotifications = { ...notifications }

    Object.keys(updatedNotifications).forEach((timeframe) => {
      updatedNotifications[timeframe] = updatedNotifications[timeframe].map((notification) =>
        notification.id === id ? { ...notification, isRead: true } : notification,
      )
    })

    setNotifications(updatedNotifications)
  }

  // Delete notification
  const deleteNotification = (id: number) => {
    const updatedNotifications = { ...notifications }

    Object.keys(updatedNotifications).forEach((timeframe) => {
      updatedNotifications[timeframe] = updatedNotifications[timeframe].filter((notification) => notification.id !== id)
    })

    setNotifications(updatedNotifications)
    toast.success("Notification deleted")
  }

  // Get icon based on notification type
  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case "inquiry":
        return <MessageCircle className="h-5 w-5 text-blue-500" />
      case "message":
        return <MessageCircle className="h-5 w-5 text-green-500" />
      case "reservation":
        return <ShoppingCart className="h-5 w-5 text-purple-500" />
      case "system":
        return <Bell className="h-5 w-5 text-orange-500" />
      case "update":
        return <Package className="h-5 w-5 text-yellow-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  // Filter notifications based on active tab
  const getFilteredNotifications = () => {
    if (activeTab === "all") {
      return notifications
    }

    const filtered: Record<string, Notification[]> = {}

    Object.keys(notifications).forEach((timeframe) => {
      filtered[timeframe] = notifications[timeframe].filter((notification) =>
        activeTab === "unread" ? !notification.isRead : notification.type === activeTab,
      )
    })

    return filtered
  }

  const filteredNotifications = getFilteredNotifications()

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl md:text-3xl font-bold">Notifications</h1>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="h-6 px-2">
                {unreadCount} unread
              </Badge>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={markAllAsRead} disabled={unreadCount === 0}>
              <CheckCheck className="mr-2 h-4 w-4" />
              Mark all as read
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
            <TabsTrigger value="all" className="flex-1">
              All
            </TabsTrigger>
            <TabsTrigger value="unread" className="flex-1">
              Unread
            </TabsTrigger>
            <TabsTrigger value="inquiry" className="flex-1">
              Inquiries
            </TabsTrigger>
            <TabsTrigger value="message" className="flex-1">
              Messages
            </TabsTrigger>
            <TabsTrigger value="reservation" className="flex-1">
              Reservations
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-0">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Recent Notifications</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {Object.keys(filteredNotifications).map((timeframe) =>
                  filteredNotifications[timeframe].length > 0 ? (
                    <div key={timeframe} className="border-b last:border-b-0">
                      <div className="bg-gray-50 px-6 py-2">
                        <h3 className="text-sm font-medium text-gray-500 capitalize">
                          {timeframe === "thisWeek" ? "This Week" : timeframe}
                        </h3>
                      </div>
                      <div>
                        {filteredNotifications[timeframe].map((notification) => (
                          <div
                            key={notification.id}
                            className={`flex items-start gap-4 px-6 py-4 border-b last:border-b-0 transition-colors ${
                              !notification.isRead ? "bg-green-50" : ""
                            }`}
                          >
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gray-100">
                              {getNotificationIcon(notification.type)}
                            </div>
                            <div className="flex-grow min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <h4 className="font-medium">{notification.title}</h4>
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <Clock className="h-3 w-3" />
                                  <span>{notification.timeAgo}</span>
                                </div>
                              </div>
                              <p className="mt-1 text-sm text-gray-600">{notification.description}</p>
                              {notification.actionUrl && (
                                <Button variant="link" asChild className="mt-2 h-auto p-0 text-sm text-green-600">
                                  <a href={notification.actionUrl}>{notification.actionLabel}</a>
                                </Button>
                              )}
                            </div>
                            <div className="flex shrink-0 gap-1">
                              {!notification.isRead && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => markAsRead(notification.id)}
                                  title="Mark as read"
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-red-500"
                                onClick={() => deleteNotification(notification.id)}
                                title="Delete notification"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null,
                )}

                {Object.values(filteredNotifications).flat().length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gray-100">
                      <Bell className="h-6 w-6 text-gray-400" />
                    </div>
                    <h3 className="mt-4 text-lg font-medium">No notifications</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {activeTab === "all"
                        ? "You don't have any notifications yet"
                        : `You don't have any ${activeTab === "unread" ? "unread" : activeTab} notifications`}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}
