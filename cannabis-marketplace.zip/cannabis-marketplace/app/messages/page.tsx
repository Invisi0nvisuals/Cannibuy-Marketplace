"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "sonner"
import {
  ImageIcon,
  Paperclip,
  Mic,
  Send,
  Archive,
  X,
  Film,
  ArrowLeft,
  Check,
  CheckCheck,
  Clock,
  MessageSquare,
  Plus,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"

interface Message {
  id: number
  sender: string
  content: string
  timestamp: string
  isRead: boolean
  readAt?: string
  avatar: string
  attachmentType?: "image" | "video" | "audio"
  attachmentUrl?: string
  isTemplate?: boolean
}

interface Conversation {
  id: number
  name: string
  lastMessage: string
  timestamp: string
  unread: number
  avatar: string
  messages: Message[]
  isArchived?: boolean
  isVerified?: boolean
  isTyping?: boolean
  responseRate?: number
  responseTime?: string
}

// Message templates
const messageTemplates = [
  {
    id: 1,
    title: "Inquiry Response",
    content:
      "Thank you for your inquiry about my listing. Yes, it's still available. When would you like to arrange a viewing?",
  },
  {
    id: 2,
    title: "Price Negotiation",
    content:
      "I appreciate your interest. While my listed price is firm, I could offer a 5% discount for a purchase of 3 lbs or more.",
  },
  {
    id: 3,
    title: "Quality Information",
    content:
      "This strain has been lab tested at 24% THC and 0.5% CBD. I can provide the full test results if you're interested.",
  },
  {
    id: 4,
    title: "Shipping Information",
    content:
      "I offer secure shipping options with tracking. Delivery typically takes 2-3 business days depending on your location.",
  },
  {
    id: 5,
    title: "Request Test Results",
    content:
      "Could you please provide the lab test results for this strain? I'm particularly interested in the terpene profile.",
  },
]

const initialConversations: Conversation[] = [
  {
    id: 1,
    name: "John Smith",
    lastMessage: "I'm interested in your Blue Dream listing",
    timestamp: "10:30 AM",
    unread: 2,
    avatar: "/placeholder.svg?height=40&width=40",
    isVerified: true,
    responseRate: 98,
    responseTime: "< 1 hour",
    messages: [
      {
        id: 1,
        sender: "John Smith",
        content: "Hi there, I'm interested in your Blue Dream listing.",
        timestamp: "10:25 AM",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 2,
        sender: "John Smith",
        content: "Is it still available? What's the lowest you can go on price?",
        timestamp: "10:27 AM",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 3,
        sender: "John Smith",
        content: "Also, do you have test results available?",
        timestamp: "10:30 AM",
        isRead: false,
        avatar: "/placeholder.svg?height=40&width=40",
      },
    ],
  },
  {
    id: 2,
    name: "Sarah Johnson",
    lastMessage: "I'd like to reserve the Sour Diesel",
    timestamp: "Yesterday",
    unread: 0,
    avatar: "/placeholder.svg?height=40&width=40",
    isVerified: true,
    responseRate: 95,
    responseTime: "~2 hours",
    messages: [
      {
        id: 1,
        sender: "Sarah Johnson",
        content: "Hello, I'd like to reserve the Sour Diesel listing.",
        timestamp: "Yesterday",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 2,
        sender: "You",
        content: "Hi Sarah, it's still available. Would you like to place a reservation?",
        timestamp: "Yesterday",
        isRead: true,
        readAt: "Yesterday at 2:45 PM",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 3,
        sender: "Sarah Johnson",
        content: "Yes, I'd like to reserve 2 lbs.",
        timestamp: "Yesterday",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 4,
        sender: "Sarah Johnson",
        content: "Here's a photo of my current inventory:",
        timestamp: "Yesterday",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
        attachmentType: "image",
        attachmentUrl: "/images/cannabis_market_thumbnail.png",
      },
    ],
  },
  {
    id: 3,
    name: "Michael Brown",
    lastMessage: "Thanks for the information",
    timestamp: "2 days ago",
    unread: 0,
    avatar: "/placeholder.svg?height=40&width=40",
    isTyping: true,
    responseRate: 90,
    responseTime: "Same day",
    messages: [
      {
        id: 1,
        sender: "Michael Brown",
        content: "Hi, I'm interested in your Northern Lights listing. Do you have any bulk pricing?",
        timestamp: "2 days ago",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 2,
        sender: "You",
        content: "Hello Michael, yes I do offer bulk pricing. For orders over 5 lbs, I can offer a 10% discount.",
        timestamp: "2 days ago",
        isRead: true,
        readAt: "2 days ago at 3:20 PM",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 3,
        sender: "Michael Brown",
        content: "That sounds great. Do you have recent test results for this strain?",
        timestamp: "2 days ago",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 4,
        sender: "You",
        content: "Yes, I have the latest lab results showing 22% THC and 0.3% CBD. I can send them over if you'd like.",
        timestamp: "2 days ago",
        isRead: true,
        readAt: "2 days ago at 4:15 PM",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: 5,
        sender: "Michael Brown",
        content: "Thanks for the information. I'll get back to you soon with my decision.",
        timestamp: "2 days ago",
        isRead: true,
        avatar: "/placeholder.svg?height=40&width=40",
      },
    ],
  },
]

export default function MessagesPage() {
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations)
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(conversations[0])
  const [newMessage, setNewMessage] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [recordingInterval, setRecordingInterval] = useState<NodeJS.Timeout | null>(null)
  const [isMobileView, setIsMobileView] = useState(false)
  const [showConversationList, setShowConversationList] = useState(true)
  const [isTemplateMenuOpen, setIsTemplateMenuOpen] = useState(false)
  const [showReadReceipts, setShowReadReceipts] = useState(true)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [activeTab, setActiveTab] = useState("inbox")
  const [imgError, setImgError] = useState<Record<string, boolean>>({})

  // Check if we're in mobile view
  useEffect(() => {
    const checkMobileView = () => {
      setIsMobileView(window.innerWidth < 768)
    }

    checkMobileView()
    window.addEventListener("resize", checkMobileView)

    return () => window.removeEventListener("resize", checkMobileView)
  }, [])

  // When a conversation is selected on mobile, hide the conversation list
  useEffect(() => {
    if (isMobileView && activeConversation) {
      setShowConversationList(false)
    }
  }, [activeConversation, isMobileView])

  // Scroll to bottom of messages when new message is added
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [activeConversation?.messages])

  // Simulate typing indicator
  useEffect(() => {
    if (activeConversation?.isTyping) {
      const typingTimeout = setTimeout(() => {
        // Add a new message from the typing user
        const updatedConversations = conversations.map((convo) => {
          if (convo.id === activeConversation.id) {
            const newMessageObj: Message = {
              id: Date.now(),
              sender: activeConversation.name,
              content:
                "I'm looking at a few options right now. Your Northern Lights looks great. What's your availability for a viewing?",
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              isRead: false,
              avatar: activeConversation.avatar,
            }

            return {
              ...convo,
              isTyping: false,
              messages: [...convo.messages, newMessageObj],
              lastMessage: newMessageObj.content,
              timestamp: "Just now",
              unread: convo.unread + 1,
            }
          }
          return convo
        })

        setConversations(updatedConversations)
        setActiveConversation(updatedConversations.find((convo) => convo.id === activeConversation.id) || null)

        toast.success(`New message from ${activeConversation.name}`)
      }, 8000) // Simulate typing for 8 seconds

      return () => clearTimeout(typingTimeout)
    }
  }, [
    activeConversation?.isTyping,
    activeConversation?.id,
    activeConversation?.name,
    conversations,
    activeConversation,
  ])

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if ((!newMessage.trim() && !isRecording) || !activeConversation) return

    const content = isRecording ? "Voice message" : newMessage.trim()

    const newMessageObj: Message = {
      id: Date.now(),
      sender: "You",
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isRead: false,
      avatar: "/placeholder.svg?height=40&width=40",
      ...(isRecording && {
        attachmentType: "audio",
        attachmentUrl: "/placeholder.svg?height=50&width=200",
      }),
      isTemplate: isTemplateMenuOpen,
    }

    const updatedConversations = conversations.map((convo) => {
      if (convo.id === activeConversation.id) {
        return {
          ...convo,
          messages: [...convo.messages, newMessageObj],
          lastMessage: content,
          timestamp: "Just now",
        }
      }
      return convo
    })

    setConversations(updatedConversations)
    setActiveConversation(updatedConversations.find((convo) => convo.id === activeConversation.id) || null)
    setNewMessage("")
    setIsTemplateMenuOpen(false)

    if (isRecording) {
      stopRecording()
    }

    // Simulate message being read after a delay
    setTimeout(() => {
      const readUpdatedConversations = conversations.map((convo) => {
        if (convo.id === activeConversation.id) {
          return {
            ...convo,
            messages: convo.messages.map((msg) => {
              if (msg.id === newMessageObj.id) {
                return {
                  ...msg,
                  isRead: true,
                  readAt: new Date().toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: true,
                  }),
                }
              }
              return msg
            }),
          }
        }
        return convo
      })

      setConversations(readUpdatedConversations)
      setActiveConversation(readUpdatedConversations.find((convo) => convo.id === activeConversation.id) || null)
    }, 5000) // Simulate message being read after 5 seconds

    toast.success("Message sent")
  }

  const handleAttachImage = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleAttachVideo = () => {
    if (videoInputRef.current) {
      videoInputRef.current.click()
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "image" | "video") => {
    const file = e.target.files?.[0]
    if (file && activeConversation) {
      // Create a URL for the selected file
      const fileUrl = URL.createObjectURL(file)

      const newMessageObj: Message = {
        id: Date.now(),
        sender: "You",
        content: type === "image" ? "Image attachment" : "Video attachment",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isRead: false,
        avatar: "/placeholder.svg?height=40&width=40",
        attachmentType: type,
        attachmentUrl: fileUrl,
      }

      const updatedConversations = conversations.map((convo) => {
        if (convo.id === activeConversation.id) {
          return {
            ...convo,
            messages: [...convo.messages, newMessageObj],
            lastMessage: type === "image" ? "Image attachment" : "Video attachment",
            timestamp: "Just now",
          }
        }
        return convo
      })

      setConversations(updatedConversations)
      setActiveConversation(updatedConversations.find((convo) => convo.id === activeConversation.id) || null)
      toast.success(`${type === "image" ? "Image" : "Video"} sent`)

      // Reset the file input
      e.target.value = ""

      // Simulate message being read after a delay
      setTimeout(() => {
        const readUpdatedConversations = conversations.map((convo) => {
          if (convo.id === activeConversation.id) {
            return {
              ...convo,
              messages: convo.messages.map((msg) => {
                if (msg.id === newMessageObj.id) {
                  return {
                    ...msg,
                    isRead: true,
                    readAt: new Date().toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                      hour12: true,
                    }),
                  }
                }
                return msg
              }),
            }
          }
          return convo
        })

        setConversations(readUpdatedConversations)
        setActiveConversation(readUpdatedConversations.find((convo) => convo.id === activeConversation.id) || null)
      }, 5000) // Simulate message being read after 5 seconds
    }
  }

  const startRecording = () => {
    setIsRecording(true)
    setRecordingTime(0)
    const interval = setInterval(() => {
      setRecordingTime((prev) => prev + 1)
    }, 1000)
    setRecordingInterval(interval)
    toast.info("Recording started... Click the X button to cancel or Send to finish recording")
  }

  const stopRecording = () => {
    if (recordingInterval) {
      clearInterval(recordingInterval)
    }
    setIsRecording(false)
    setRecordingTime(0)
  }

  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const archiveConversation = (id: number) => {
    const updatedConversations = conversations.map((convo) => {
      if (convo.id === id) {
        return { ...convo, isArchived: true }
      }
      return convo
    })
    setConversations(updatedConversations)

    if (activeConversation?.id === id && activeTab !== "archived") {
      const nextActiveConvo = updatedConversations.find((convo) => !convo.isArchived && convo.id !== id)
      setActiveConversation(nextActiveConvo || null)
    }

    toast.success("Conversation archived")
  }

  const unarchiveConversation = (id: number) => {
    const updatedConversations = conversations.map((convo) => {
      if (convo.id === id) {
        return { ...convo, isArchived: false }
      }
      return convo
    })
    setConversations(updatedConversations)
    toast.success("Conversation unarchived")
  }

  const getFilteredConversations = (tab: string) => {
    if (tab === "archived") {
      return conversations.filter((convo) => convo.isArchived)
    }
    return conversations.filter((convo) => !convo.isArchived)
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    // Reset active conversation when switching tabs
    if (value === "archived") {
      const archivedConvo = conversations.find((convo) => convo.isArchived)
      setActiveConversation(archivedConvo || null)
    } else if (value === "inbox") {
      const inboxConvo = conversations.find((convo) => !convo.isArchived)
      setActiveConversation(inboxConvo || null)
    } else {
      setActiveConversation(null)
    }

    // On mobile, show the conversation list when changing tabs
    if (isMobileView) {
      setShowConversationList(true)
    }
  }

  const handleImageError = (key: string) => {
    setImgError((prev) => ({ ...prev, [key]: true }))
  }

  const applyTemplate = (template: (typeof messageTemplates)[0]) => {
    setNewMessage(template.content)
    setIsTemplateMenuOpen(false)
  }

  const markConversationAsRead = (conversationId: number) => {
    const updatedConversations = conversations.map((convo) => {
      if (convo.id === conversationId) {
        return {
          ...convo,
          unread: 0,
          messages: convo.messages.map((msg) => ({
            ...msg,
            isRead: true,
          })),
        }
      }
      return convo
    })

    setConversations(updatedConversations)
    setActiveConversation(updatedConversations.find((convo) => convo.id === conversationId) || null)
  }

  return (
    <Layout>
      <div className="mx-auto max-w-6xl">
        <div className="mb-4 md:mb-6 flex items-center justify-between">
          <h1 className="text-2xl md:text-3xl font-bold">Messages</h1>
          {isMobileView && !showConversationList && (
            <Button variant="outline" size="sm" onClick={() => setShowConversationList(true)}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to conversations
            </Button>
          )}
        </div>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
            <TabsTrigger value="inbox" className="flex-1">
              Inbox
            </TabsTrigger>
            <TabsTrigger value="sent" className="flex-1">
              Sent
            </TabsTrigger>
            <TabsTrigger value="archived" className="flex-1">
              Archived
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inbox" className="mt-0">
            <div className="grid grid-cols-1 gap-4 md:gap-6 md:grid-cols-3">
              {/* Conversation List - Show on desktop or when showConversationList is true on mobile */}
              {(!isMobileView || showConversationList) && (
                <div className="md:col-span-1">
                  <Card>
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        {getFilteredConversations("inbox").map((convo) => (
                          <div
                            key={convo.id}
                            className={`flex cursor-pointer items-center gap-3 rounded-lg p-3 transition-colors ${
                              activeConversation?.id === convo.id ? "bg-green-50" : "hover:bg-gray-50"
                            }`}
                            onClick={() => {
                              setActiveConversation(convo)
                              if (convo.unread > 0) {
                                markConversationAsRead(convo.id)
                              }
                              if (isMobileView) {
                                setShowConversationList(false)
                              }
                            }}
                          >
                            <div className="relative h-10 w-10 overflow-hidden rounded-full">
                              <img
                                src={convo.avatar || "/placeholder.svg"}
                                alt={convo.name}
                                className="h-full w-full object-cover"
                              />
                              {convo.isVerified && (
                                <div className="absolute -right-1 -bottom-1 rounded-full bg-green-500 p-1 text-white">
                                  <Check className="h-3 w-3" />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <h3 className="font-medium flex items-center">
                                  {convo.name}
                                  {convo.isVerified && (
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Badge variant="outline" className="ml-1 px-1 py-0 h-4">
                                            <Check className="h-2 w-2 text-green-500" />
                                          </Badge>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          <p>Verified User</p>
                                        </TooltipContent>
                                      </Tooltip>
                                    </TooltipProvider>
                                  )}
                                </h3>
                                <span className="text-xs text-gray-500">{convo.timestamp}</span>
                              </div>
                              <div className="flex items-center">
                                <p className="truncate text-sm text-gray-600 mr-1">
                                  {convo.isTyping ? (
                                    <span className="italic text-green-600">typing...</span>
                                  ) : (
                                    convo.lastMessage
                                  )}
                                </p>
                                {convo.unread > 0 && (
                                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-600 text-xs text-white shrink-0">
                                    {convo.unread}
                                  </div>
                                )}
                              </div>
                              <div className="flex items-center mt-1">
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <div className="flex items-center text-xs text-gray-500">
                                        <Clock className="h-3 w-3 mr-1" />
                                        <span>{convo.responseTime}</span>
                                      </div>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>{convo.responseRate}% response rate</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="ml-auto h-8 w-8 opacity-0 transition-opacity hover:opacity-100 group-hover:opacity-100"
                              onClick={(e) => {
                                e.stopPropagation()
                                archiveConversation(convo.id)
                              }}
                            >
                              <Archive className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Conversation Detail - Show on desktop or when showConversationList is false on mobile */}
              {(!isMobileView || !showConversationList) && (
                <div className="md:col-span-2">
                  <Card className="h-full">
                    <CardContent className="flex h-[500px] md:h-[600px] flex-col p-0">
                      {activeConversation ? (
                        <>
                          <div className="flex items-center justify-between gap-3 border-b p-4">
                            <div className="flex items-center gap-3">
                              <div className="relative h-10 w-10 overflow-hidden rounded-full">
                                <img
                                  src={activeConversation.avatar || "/placeholder.svg"}
                                  alt={activeConversation.name}
                                  className="h-full w-full object-cover"
                                />
                                {activeConversation.isVerified && (
                                  <div className="absolute -right-1 -bottom-1 rounded-full bg-green-500 p-1 text-white">
                                    <Check className="h-3 w-3" />
                                  </div>
                                )}
                              </div>
                              <div>
                                <h3 className="font-medium flex items-center">
                                  {activeConversation.name}
                                  {activeConversation.isVerified && (
                                    <Badge variant="outline" className="ml-1 px-1 py-0 h-4">
                                      <Check className="h-2 w-2 text-green-500" />
                                    </Badge>
                                  )}
                                </h3>
                                <div className="flex items-center text-xs text-gray-500">
                                  <Clock className="h-3 w-3 mr-1" />
                                  <span>
                                    {activeConversation.responseTime} response time • {activeConversation.responseRate}%
                                    response rate
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => setShowReadReceipts(!showReadReceipts)}
                                    >
                                      {showReadReceipts ? (
                                        <CheckCheck className="h-4 w-4" />
                                      ) : (
                                        <Check className="h-4 w-4" />
                                      )}
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>{showReadReceipts ? "Hide read receipts" : "Show read receipts"}</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => archiveConversation(activeConversation.id)}
                              >
                                <Archive className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {activeConversation.messages.map((message) => (
                              <div
                                key={message.id}
                                className={`flex gap-3 ${message.sender === "You" ? "justify-end" : ""}`}
                              >
                                {message.sender !== "You" && (
                                  <div className="h-8 w-8 overflow-hidden rounded-full">
                                    <img
                                      src={message.avatar || "/placeholder.svg"}
                                      alt={message.sender}
                                      className="h-full w-full object-cover"
                                    />
                                  </div>
                                )}
                                <div
                                  className={`max-w-[85%] sm:max-w-[70%] rounded-lg p-3 ${
                                    message.sender !== "You"
                                      ? "bg-gray-100"
                                      : message.isTemplate
                                        ? "bg-blue-100"
                                        : "bg-green-100"
                                  }`}
                                >
                                  <p className="text-sm">{message.content}</p>
                                  {message.attachmentType === "image" && (
                                    <div className="mt-2 overflow-hidden rounded-md">
                                      <img
                                        src={
                                          imgError[`img-${message.id || "/placeholder.svg"}`]
                                            ? "/images/cannabis_market_thumbnail.png"
                                            : message.attachmentUrl || "/images/cannabis_market_thumbnail.png"
                                        }
                                        alt="Attachment"
                                        className="h-auto w-full max-w-xs object-cover"
                                        onError={() => handleImageError(`img-${message.id}`)}
                                      />
                                    </div>
                                  )}
                                  {message.attachmentType === "video" && (
                                    <div className="mt-2 overflow-hidden rounded-md bg-black">
                                      <div className="relative">
                                        <img
                                          src={
                                            imgError[`vid-${message.id || "/placeholder.svg"}`]
                                              ? "/images/cannabis_market_thumbnail.png"
                                              : message.attachmentUrl || "/images/cannabis_market_thumbnail.png"
                                          }
                                          alt="Video thumbnail"
                                          className="h-auto w-full max-w-xs object-cover"
                                          onError={() => handleImageError(`vid-${message.id}`)}
                                        />
                                        <div className="absolute inset-0 flex items-center justify-center">
                                          <div className="rounded-full bg-black/50 p-3">
                                            <Film className="h-6 w-6 text-white" />
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  {message.attachmentType === "audio" && (
                                    <div className="mt-2 flex items-center gap-2 rounded-full bg-gray-200 px-3 py-1">
                                      <div className="h-8 w-8 rounded-full bg-green-600 p-2">
                                        <Mic className="h-4 w-4 text-white" />
                                      </div>
                                      <div className="flex-1">
                                        <div className="h-2 w-full rounded-full bg-gray-300">
                                          <div className="h-2 w-1/3 rounded-full bg-green-600"></div>
                                        </div>
                                      </div>
                                      <span className="text-xs text-gray-500">0:12</span>
                                    </div>
                                  )}
                                  <div className="mt-1 flex items-center justify-end gap-1 text-xs text-gray-500">
                                    <span>{message.timestamp}</span>
                                    {message.sender === "You" && showReadReceipts && (
                                      <>
                                        {message.isRead ? (
                                          <TooltipProvider>
                                            <Tooltip>
                                              <TooltipTrigger asChild>
                                                <span>
                                                  <CheckCheck className="h-3 w-3 text-green-600" />
                                                </span>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                <p>Read {message.readAt}</p>
                                              </TooltipContent>
                                            </Tooltip>
                                          </TooltipProvider>
                                        ) : (
                                          <Check className="h-3 w-3" />
                                        )}
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                            {activeConversation.isTyping && (
                              <div className="flex gap-3">
                                <div className="h-8 w-8 overflow-hidden rounded-full">
                                  <img
                                    src={activeConversation.avatar || "/placeholder.svg"}
                                    alt={activeConversation.name}
                                    className="h-full w-full object-cover"
                                  />
                                </div>
                                <div className="max-w-[85%] sm:max-w-[70%] rounded-lg p-3 bg-gray-100">
                                  <div className="flex space-x-1">
                                    <div className="h-2 w-2 animate-bounce rounded-full bg-gray-400"></div>
                                    <div
                                      className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                                      style={{ animationDelay: "0.2s" }}
                                    ></div>
                                    <div
                                      className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                                      style={{ animationDelay: "0.4s" }}
                                    ></div>
                                  </div>
                                </div>
                              </div>
                            )}
                            <div ref={messagesEndRef} />
                          </div>

                          <form onSubmit={sendMessage} className="border-t p-4">
                            <div className="flex gap-2">
                              <div className="relative flex-grow">
                                <Input
                                  placeholder={isRecording ? "Recording..." : "Type your message..."}
                                  value={newMessage}
                                  onChange={(e) => setNewMessage(e.target.value)}
                                  disabled={isRecording || activeConversation.isArchived}
                                  className={isRecording ? "bg-red-50 pr-16" : ""}
                                />
                                {isRecording && (
                                  <div className="absolute right-3 top-1/2 flex -translate-y-1/2 items-center gap-2">
                                    <span className="animate-pulse text-red-500">●</span>
                                    <span className="text-sm">{formatRecordingTime(recordingTime)}</span>
                                  </div>
                                )}
                              </div>

                              {/* Template Button */}
                              <DropdownMenu open={isTemplateMenuOpen} onOpenChange={setIsTemplateMenuOpen}>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    type="button"
                                    disabled={activeConversation.isArchived}
                                    className="relative"
                                  >
                                    <MessageSquare className="h-4 w-4" />
                                    <span className="sr-only">Message templates</span>
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-80">
                                  <div className="flex items-center justify-between px-2 py-1.5">
                                    <span className="text-sm font-medium">Message Templates</span>
                                    <Button variant="ghost" size="sm" className="h-8 px-2 text-xs">
                                      <Plus className="mr-1 h-3 w-3" />
                                      Create New
                                    </Button>
                                  </div>
                                  <DropdownMenuSeparator />
                                  {messageTemplates.map((template) => (
                                    <DropdownMenuItem
                                      key={template.id}
                                      onClick={() => applyTemplate(template)}
                                      className="flex flex-col items-start p-2 cursor-pointer"
                                    >
                                      <span className="font-medium text-sm">{template.title}</span>
                                      <span className="text-xs text-gray-500 mt-1 line-clamp-2">
                                        {template.content}
                                      </span>
                                    </DropdownMenuItem>
                                  ))}
                                </DropdownMenuContent>
                              </DropdownMenu>

                              {/* Attachment Button */}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    type="button"
                                    disabled={activeConversation.isArchived}
                                  >
                                    <Paperclip className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={handleAttachImage}>
                                    <ImageIcon className="mr-2 h-4 w-4" />
                                    <span>Image</span>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={handleAttachVideo}>
                                    <Film className="mr-2 h-4 w-4" />
                                    <span>Video</span>
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                              <input
                                type="file"
                                ref={fileInputRef}
                                className="hidden"
                                accept="image/*"
                                onChange={(e) => handleFileChange(e, "image")}
                              />
                              <input
                                type="file"
                                ref={videoInputRef}
                                className="hidden"
                                accept="video/*"
                                onChange={(e) => handleFileChange(e, "video")}
                              />
                              {isRecording ? (
                                <Button type="button" variant="destructive" size="icon" onClick={stopRecording}>
                                  <X className="h-4 w-4" />
                                </Button>
                              ) : (
                                <Button
                                  type="button"
                                  variant={recordingTime > 0 ? "destructive" : "outline"}
                                  size="icon"
                                  onClick={startRecording}
                                  disabled={activeConversation.isArchived}
                                >
                                  <Mic className="h-4 w-4" />
                                </Button>
                              )}
                              <Button type="submit" disabled={activeConversation.isArchived}>
                                <Send className="h-4 w-4" />
                              </Button>
                            </div>
                          </form>
                        </>
                      ) : (
                        <div className="flex h-full items-center justify-center">
                          <p className="text-gray-500">Select a conversation to start messaging</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="sent">
            <div className="flex h-40 items-center justify-center rounded-lg border border-dashed">
              <p className="text-gray-500">No sent messages</p>
            </div>
          </TabsContent>

          <TabsContent value="archived" className="mt-0">
            {getFilteredConversations("archived").length > 0 ? (
              <div className="grid grid-cols-1 gap-4 md:gap-6 md:grid-cols-3">
                {/* Archived Conversation List - Show on desktop or when showConversationList is true on mobile */}
                {(!isMobileView || showConversationList) && (
                  <div className="md:col-span-1">
                    <Card>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          {getFilteredConversations("archived").map((convo) => (
                            <div
                              key={convo.id}
                              className={`flex cursor-pointer items-center gap-3 rounded-lg p-3 transition-colors ${
                                activeConversation?.id === convo.id ? "bg-green-50" : "hover:bg-gray-50"
                              }`}
                              onClick={() => {
                                setActiveConversation(convo)
                                if (isMobileView) {
                                  setShowConversationList(false)
                                }
                              }}
                            >
                              <div className="relative h-10 w-10 overflow-hidden rounded-full">
                                <img
                                  src={convo.avatar || "/placeholder.svg"}
                                  alt={convo.name}
                                  className="h-full w-full object-cover"
                                />
                                {convo.isVerified && (
                                  <div className="absolute -right-1 -bottom-1 rounded-full bg-green-500 p-1 text-white">
                                    <Check className="h-3 w-3" />
                                  </div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between">
                                  <h3 className="font-medium flex items-center">
                                    {convo.name}
                                    {convo.isVerified && (
                                      <Badge variant="outline" className="ml-1 px-1 py-0 h-4">
                                        <Check className="h-2 w-2 text-green-500" />
                                      </Badge>
                                    )}
                                  </h3>
                                  <span className="text-xs text-gray-500">{convo.timestamp}</span>
                                </div>
                                <p className="truncate text-sm text-gray-600">{convo.lastMessage}</p>
                              </div>
                              <Button variant="ghost" size="sm" onClick={() => unarchiveConversation(convo.id)}>
                                Unarchive
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Archived Conversation Detail - Show on desktop or when showConversationList is false on mobile */}
                {(!isMobileView || !showConversationList) && (
                  <div className="md:col-span-2">
                    <Card className="h-full">
                      <CardContent className="flex h-[500px] md:h-[600px] flex-col p-0">
                        {activeConversation ? (
                          <>
                            <div className="flex items-center justify-between gap-3 border-b p-4">
                              <div className="flex items-center gap-3">
                                <div className="relative h-10 w-10 overflow-hidden rounded-full">
                                  <img
                                    src={activeConversation.avatar || "/placeholder.svg"}
                                    alt={activeConversation.name}
                                    className="h-full w-full object-cover"
                                  />
                                  {activeConversation.isVerified && (
                                    <div className="absolute -right-1 -bottom-1 rounded-full bg-green-500 p-1 text-white">
                                      <Check className="h-3 w-3" />
                                    </div>
                                  )}
                                </div>
                                <div>
                                  <h3 className="font-medium flex items-center">
                                    {activeConversation.name}
                                    {activeConversation.isVerified && (
                                      <Badge variant="outline" className="ml-1 px-1 py-0 h-4">
                                        <Check className="h-2 w-2 text-green-500" />
                                      </Badge>
                                    )}
                                  </h3>
                                  <div className="flex items-center text-xs text-gray-500">
                                    <Clock className="h-3 w-3 mr-1" />
                                    <span>
                                      {activeConversation.responseTime} response time •{" "}
                                      {activeConversation.responseRate}% response rate
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => unarchiveConversation(activeConversation.id)}
                              >
                                Unarchive
                              </Button>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                              {activeConversation.messages.map((message) => (
                                <div
                                  key={message.id}
                                  className={`flex gap-3 ${message.sender === "You" ? "justify-end" : ""}`}
                                >
                                  {message.sender !== "You" && (
                                    <div className="h-8 w-8 overflow-hidden rounded-full">
                                      <img
                                        src={message.avatar || "/placeholder.svg"}
                                        alt={message.sender}
                                        className="h-full w-full object-cover"
                                      />
                                    </div>
                                  )}
                                  <div
                                    className={`max-w-[85%] sm:max-w-[70%] rounded-lg p-3 ${
                                      message.sender !== "You"
                                        ? "bg-gray-100"
                                        : message.isTemplate
                                          ? "bg-blue-100"
                                          : "bg-green-100"
                                    }`}
                                  >
                                    <p className="text-sm">{message.content}</p>
                                    {message.attachmentType === "image" && (
                                      <div className="mt-2 overflow-hidden rounded-md">
                                        <img
                                          src={
                                            imgError[`img-${message.id || "/placeholder.svg"}`]
                                              ? "/images/cannabis_market_thumbnail.png"
                                              : message.attachmentUrl || "/images/cannabis_market_thumbnail.png"
                                          }
                                          alt="Attachment"
                                          className="h-auto w-full max-w-xs object-cover"
                                          onError={() => handleImageError(`img-${message.id}`)}
                                        />
                                      </div>
                                    )}
                                    {message.attachmentType === "video" && (
                                      <div className="mt-2 overflow-hidden rounded-md bg-black">
                                        <div className="relative">
                                          <img
                                            src={
                                              imgError[`vid-${message.id || "/placeholder.svg"}`]
                                                ? "/images/cannabis_market_thumbnail.png"
                                                : message.attachmentUrl || "/images/cannabis_market_thumbnail.png"
                                            }
                                            alt="Video thumbnail"
                                            className="h-auto w-full max-w-xs object-cover"
                                            onError={() => handleImageError(`vid-${message.id}`)}
                                          />
                                          <div className="absolute inset-0 flex items-center justify-center">
                                            <div className="rounded-full bg-black/50 p-3">
                                              <Film className="h-6 w-6 text-white" />
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                    {message.attachmentType === "audio" && (
                                      <div className="mt-2 flex items-center gap-2 rounded-full bg-gray-200 px-3 py-1">
                                        <div className="h-8 w-8 rounded-full bg-green-600 p-2">
                                          <Mic className="h-4 w-4 text-white" />
                                        </div>
                                        <div className="flex-1">
                                          <div className="h-2 w-full rounded-full bg-gray-300">
                                            <div className="h-2 w-1/3 rounded-full bg-green-600"></div>
                                          </div>
                                        </div>
                                        <span className="text-xs text-gray-500">0:12</span>
                                      </div>
                                    )}
                                    <div className="mt-1 flex items-center justify-end gap-1 text-xs text-gray-500">
                                      <span>{message.timestamp}</span>
                                      {message.sender === "You" && showReadReceipts && (
                                        <>
                                          {message.isRead ? (
                                            <TooltipProvider>
                                              <Tooltip>
                                                <TooltipTrigger asChild>
                                                  <span>
                                                    <CheckCheck className="h-3 w-3 text-green-600" />
                                                  </span>
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                  <p>Read {message.readAt}</p>
                                                </TooltipContent>
                                              </Tooltip>
                                            </TooltipProvider>
                                          ) : (
                                            <Check className="h-3 w-3" />
                                          )}
                                        </>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ))}
                              <div ref={messagesEndRef} />
                            </div>

                            <div className="border-t p-4">
                              <p className="text-center text-sm text-gray-500">
                                This conversation is archived. Unarchive to continue messaging.
                              </p>
                            </div>
                          </>
                        ) : (
                          <div className="flex h-full items-center justify-center">
                            <p className="text-gray-500">No archived messages</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center rounded-lg border border-dashed">
                <p className="text-gray-500">No archived messages</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}
