"use client"

import { useState } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DollarSign, Users, ShoppingBag, TrendingUp, Calendar, Download, Share2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"

// Sample analytics data
const analyticsData = {
  overview: {
    totalSales: 42500,
    totalOrders: 18,
    totalCustomers: 12,
    conversionRate: 68,
    averageOrderValue: 2361,
  },
  salesByStrain: [
    { name: "Blue Dream", sales: 12500, percentage: 29.4 },
    { name: "Sour Diesel", sales: 9000, percentage: 21.2 },
    { name: "Girl Scout Cookies", sales: 7000, percentage: 16.5 },
    { name: "OG Kush", sales: 6400, percentage: 15.1 },
    { name: "Northern Lights", sales: 5400, percentage: 12.7 },
    { name: "Other", sales: 2200, percentage: 5.1 },
  ],
  salesByMonth: [
    { month: "Jan", sales: 3200 },
    { month: "Feb", sales: 3800 },
    { month: "Mar", sales: 4200 },
    { month: "Apr", sales: 4800 },
    { month: "May", sales: 5100 },
    { month: "Jun", sales: 4900 },
  ],
  inquiriesByStrain: [
    { name: "Blue Dream", count: 24 },
    { name: "Sour Diesel", count: 18 },
    { name: "Girl Scout Cookies", count: 15 },
    { name: "OG Kush", count: 12 },
    { name: "Northern Lights", count: 10 },
    { name: "Other", count: 8 },
  ],
  customersByLocation: [
    { location: "California", percentage: 35 },
    { location: "Colorado", percentage: 25 },
    { location: "Washington", percentage: 15 },
    { location: "Oregon", percentage: 12 },
    { location: "Michigan", percentage: 8 },
    { location: "Other", percentage: 5 },
  ],
  listingPerformance: [
    {
      strain: "Blue Dream",
      views: 245,
      inquiries: 24,
      conversions: 8,
      conversionRate: "33.3%",
      revenue: 12500,
    },
    {
      strain: "Sour Diesel",
      views: 198,
      inquiries: 18,
      conversions: 6,
      conversionRate: "33.3%",
      revenue: 9000,
    },
    {
      strain: "Girl Scout Cookies",
      views: 176,
      inquiries: 15,
      conversions: 4,
      conversionRate: "26.7%",
      revenue: 7000,
    },
    {
      strain: "OG Kush",
      views: 154,
      inquiries: 12,
      conversions: 4,
      conversionRate: "33.3%",
      revenue: 6400,
    },
    {
      strain: "Northern Lights",
      views: 132,
      inquiries: 10,
      conversions: 4,
      conversionRate: "40.0%",
      revenue: 5400,
    },
  ],
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("6m")

  const downloadReport = () => {
    toast.success("Analytics report downloaded")
  }

  const shareReport = () => {
    toast.success("Share link copied to clipboard")
  }

  return (
    <Layout>
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Seller Analytics</h1>
            <p className="mt-1 text-gray-600">Track your sales performance and customer insights</p>
          </div>

          <div className="flex items-center gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="1m">Last month</SelectItem>
                <SelectItem value="3m">Last 3 months</SelectItem>
                <SelectItem value="6m">Last 6 months</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon" onClick={downloadReport}>
              <Download className="h-4 w-4" />
            </Button>

            <Button variant="outline" size="icon" onClick={shareReport}>
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${analyticsData.overview.totalSales.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+18% from last period</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Orders</CardTitle>
              <ShoppingBag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.overview.totalOrders}</div>
              <p className="text-xs text-muted-foreground">+12% from last period</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Customers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.overview.totalCustomers}</div>
              <p className="text-xs text-muted-foreground">+25% from last period</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.overview.conversionRate}%</div>
              <p className="text-xs text-muted-foreground">+5% from last period</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="sales" className="mt-6">
          <TabsList>
            <TabsTrigger value="sales">Sales</TabsTrigger>
            <TabsTrigger value="inquiries">Inquiries</TabsTrigger>
            <TabsTrigger value="customers">Customers</TabsTrigger>
            <TabsTrigger value="listings">Listings</TabsTrigger>
          </TabsList>

          <TabsContent value="sales" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle>Sales Over Time</CardTitle>
                  <CardDescription>Your sales performance for the last 6 months</CardDescription>
                </CardHeader>
                <CardContent className="px-2">
                  <div className="h-[300px] w-full">
                    {/* This would be a real chart in production */}
                    <div className="flex h-full items-end gap-2">
                      {analyticsData.salesByMonth.map((month) => (
                        <div key={month.month} className="relative flex h-full flex-1 flex-col justify-end">
                          <div
                            className="bg-green-600 w-full rounded-t"
                            style={{ height: `${(month.sales / 5100) * 100}%` }}
                          ></div>
                          <span className="mt-1 text-center text-xs">{month.month}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sales by Strain</CardTitle>
                  <CardDescription>Your top selling products</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.salesByStrain.map((strain) => (
                      <div key={strain.name} className="flex items-center">
                        <div className="w-1/2">
                          <p className="text-sm font-medium">{strain.name}</p>
                        </div>
                        <div className="w-1/2">
                          <div className="flex items-center gap-2">
                            <div className="h-2 flex-1 rounded-full bg-gray-100">
                              <div
                                className="h-full rounded-full bg-green-600"
                                style={{ width: `${strain.percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-500">{strain.percentage}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Sales Breakdown</CardTitle>
                <CardDescription>Detailed analysis of your sales performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Average Order Value</p>
                      <p className="text-2xl font-bold">${analyticsData.overview.averageOrderValue}</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Repeat Purchase Rate</p>
                      <p className="text-2xl font-bold">42%</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Highest Value Order</p>
                      <p className="text-2xl font-bold">$4,800</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Best Selling Day</p>
                      <p className="text-2xl font-bold">Friday</p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="mb-4 font-medium">Sales Recommendations</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <TrendingUp className="h-5 w-5 text-green-600" />
                        <span>Consider increasing inventory of Blue Dream as it's your top seller</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Calendar className="h-5 w-5 text-green-600" />
                        <span>Sales peak on Fridays - consider running promotions on slower days</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Users className="h-5 w-5 text-green-600" />
                        <span>42% of customers make repeat purchases - implement a loyalty program</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inquiries" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Inquiries by Strain</CardTitle>
                  <CardDescription>Products with the most customer interest</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.inquiriesByStrain.map((strain) => (
                      <div key={strain.name} className="flex items-center">
                        <div className="w-1/2">
                          <p className="text-sm font-medium">{strain.name}</p>
                        </div>
                        <div className="w-1/2">
                          <div className="flex items-center gap-2">
                            <div className="h-2 flex-1 rounded-full bg-gray-100">
                              <div
                                className="h-full rounded-full bg-blue-600"
                                style={{ width: `${(strain.count / 24) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-500">{strain.count}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Inquiry Conversion</CardTitle>
                  <CardDescription>How many inquiries convert to sales</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex h-[200px] items-center justify-center">
                    {/* This would be a real chart in production */}
                    <div className="relative h-40 w-40 rounded-full">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-2xl font-bold">68%</span>
                      </div>
                      <svg viewBox="0 0 100 100" className="h-full w-full">
                        <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" strokeWidth="10" />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="10"
                          strokeDasharray="251.2"
                          strokeDashoffset="80.4"
                          transform="rotate(-90 50 50)"
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-sm text-gray-500">Total Inquiries</p>
                      <p className="text-xl font-bold">87</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Converted to Sale</p>
                      <p className="text-xl font-bold">59</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Response Performance</CardTitle>
                <CardDescription>How quickly you respond to customer inquiries</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Average Response Time</p>
                      <p className="text-2xl font-bold">1.2 hours</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Response Rate</p>
                      <p className="text-2xl font-bold">98%</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Customer Satisfaction</p>
                      <p className="text-2xl font-bold">4.8/5</p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="mb-4 font-medium">Inquiry Insights</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <TrendingUp className="h-5 w-5 text-green-600" />
                        <span>Faster response times (under 1 hour) increase conversion by 15%</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Calendar className="h-5 w-5 text-green-600" />
                        <span>Most inquiries come in between 2pm-6pm - ensure availability during these hours</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Users className="h-5 w-5 text-green-600" />
                        <span>
                          Common questions are about THC content and growing methods - add these details to listings
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="customers" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Customer Demographics</CardTitle>
                  <CardDescription>Where your customers are located</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.customersByLocation.map((location) => (
                      <div key={location.location} className="flex items-center">
                        <div className="w-1/2">
                          <p className="text-sm font-medium">{location.location}</p>
                        </div>
                        <div className="w-1/2">
                          <div className="flex items-center gap-2">
                            <div className="h-2 flex-1 rounded-full bg-gray-100">
                              <div
                                className="h-full rounded-full bg-purple-600"
                                style={{ width: `${location.percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-500">{location.percentage}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Customer Retention</CardTitle>
                  <CardDescription>How many customers return to make additional purchases</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex h-[200px] items-center justify-center">
                      {/* This would be a real chart in production */}
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="relative mx-auto h-24 w-24 rounded-full">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className="text-xl font-bold">42%</span>
                            </div>
                            <svg viewBox="0 0 100 100" className="h-full w-full">
                              <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" strokeWidth="10" />
                              <circle
                                cx="50"
                                cy="50"
                                r="40"
                                fill="none"
                                stroke="#8b5cf6"
                                strokeWidth="10"
                                strokeDasharray="251.2"
                                strokeDashoffset="145.7"
                                transform="rotate(-90 50 50)"
                              />
                            </svg>
                          </div>
                          <p className="mt-2 text-sm text-gray-500">Repeat Customers</p>
                        </div>
                        <div>
                          <div className="relative mx-auto h-24 w-24 rounded-full">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className="text-xl font-bold">58%</span>
                            </div>
                            <svg viewBox="0 0 100 100" className="h-full w-full">
                              <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" strokeWidth="10" />
                              <circle
                                cx="50"
                                cy="50"
                                r="40"
                                fill="none"
                                stroke="#6b7280"
                                strokeWidth="10"
                                strokeDasharray="251.2"
                                strokeDashoffset="105.5"
                                transform="rotate(-90 50 50)"
                              />
                            </svg>
                          </div>
                          <p className="mt-2 text-sm text-gray-500">One-time Customers</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Customer Insights</CardTitle>
                <CardDescription>Understanding your customer behavior</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Average Customer Value</p>
                      <p className="text-2xl font-bold">$3,542</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Customer Acquisition Cost</p>
                      <p className="text-2xl font-bold">$85</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Customer Lifetime</p>
                      <p className="text-2xl font-bold">8.4 months</p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="mb-4 font-medium">Customer Recommendations</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <TrendingUp className="h-5 w-5 text-green-600" />
                        <span>Implement a loyalty program to increase repeat purchase rate</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Calendar className="h-5 w-5 text-green-600" />
                        <span>Send follow-up messages 30 days after purchase to encourage reorders</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Users className="h-5 w-5 text-green-600" />
                        <span>Focus marketing efforts on California and Colorado for highest ROI</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="listings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Listing Performance</CardTitle>
                <CardDescription>How your listings are performing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="px-4 py-2 text-left font-medium">Strain</th>
                          <th className="px-4 py-2 text-left font-medium">Views</th>
                          <th className="px-4 py-2 text-left font-medium">Inquiries</th>
                          <th className="px-4 py-2 text-left font-medium">Conversions</th>
                          <th className="px-4 py-2 text-left font-medium">Conv. Rate</th>
                          <th className="px-4 py-2 text-left font-medium">Revenue</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analyticsData.listingPerformance.map((listing) => (
                          <tr key={listing.strain} className="border-b">
                            <td className="px-4 py-2 font-medium">{listing.strain}</td>
                            <td className="px-4 py-2">{listing.views}</td>
                            <td className="px-4 py-2">{listing.inquiries}</td>
                            <td className="px-4 py-2">{listing.conversions}</td>
                            <td className="px-4 py-2">{listing.conversionRate}</td>
                            <td className="px-4 py-2">${listing.revenue.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-lg border p-4">
                      <h3 className="mb-4 font-medium">Listing Optimization Tips</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <TrendingUp className="h-5 w-5 text-green-600" />
                          <span>Add more high-quality images to increase engagement</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Calendar className="h-5 w-5 text-green-600" />
                          <span>Update listings weekly to maintain visibility in search results</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <Users className="h-5 w-5 text-green-600" />
                          <span>Include detailed THC/CBD content and growing information</span>
                        </li>
                      </ul>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="mb-4 font-medium">Top Performing Attributes</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs font-bold text-green-600">
                            1
                          </div>
                          <span>High-quality strain photos (+45% engagement)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs font-bold text-green-600">
                            2
                          </div>
                          <span>Detailed testing information (+32% conversion)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs font-bold text-green-600">
                            3
                          </div>
                          <span>Competitive pricing (+28% inquiries)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs font-bold text-green-600">
                            4
                          </div>
                          <span>Detailed strain effects description (+25% engagement)</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Listing Visibility</CardTitle>
                <CardDescription>How your listings appear in search results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Search Impressions</p>
                      <p className="text-2xl font-bold">1,245</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Click-through Rate</p>
                      <p className="text-2xl font-bold">8.2%</p>
                    </div>

                    <div className="rounded-lg border p-3">
                      <p className="text-sm text-gray-500">Avg. Search Position</p>
                      <p className="text-2xl font-bold">3.4</p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="mb-4 font-medium">Top Search Terms</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Blue Dream</span>
                        <span className="text-sm text-gray-500">245 impressions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Hybrid strains</span>
                        <span className="text-sm text-gray-500">198 impressions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">High THC</span>
                        <span className="text-sm text-gray-500">176 impressions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Bulk cannabis</span>
                        <span className="text-sm text-gray-500">154 impressions</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Premium flower</span>
                        <span className="text-sm text-gray-500">132 impressions</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}
