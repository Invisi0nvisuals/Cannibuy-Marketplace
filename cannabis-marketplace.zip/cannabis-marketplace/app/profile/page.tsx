"use client"

import { Switch } from "@/components/ui/switch"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "sonner"
import { Camera } from "lucide-react"

// Default profile data
const defaultProfile = {
  firstName: "John",
  lastName: "Smith",
  email: "john.smith@example.com",
  phone: "(555) 123-4567",
  company: "Green Farms LLC",
  bio: "Cannabis broker with 5+ years of experience in the industry. Specializing in premium strains and bulk quantities.",
  profileImage: "/placeholder.svg?height=128&width=128",
  notifications: {
    inquiry: { email: true, push: true },
    reservation: { email: true, push: true },
    message: { email: true, push: true },
    marketing: { email: false, push: false },
  },
}

export default function ProfilePage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [profileData, setProfileData] = useState(defaultProfile)
  const [profileImage, setProfileImage] = useState(defaultProfile.profileImage)
  const [imgError, setImgError] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load saved profile data from localStorage on component mount
  useEffect(() => {
    try {
      const savedProfile = localStorage.getItem("cannabisProfileData")
      if (savedProfile) {
        const parsedProfile = JSON.parse(savedProfile)
        setProfileData(parsedProfile)
        setProfileImage(parsedProfile.profileImage || defaultProfile.profileImage)
      }
    } catch (error) {
      console.error("Error loading profile data:", error)
    }
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setProfileData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleNotificationChange = (type: string, channel: string, checked: boolean) => {
    setProfileData((prev) => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [type]: {
          ...prev.notifications[type as keyof typeof prev.notifications],
          [channel]: checked,
        },
      },
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Save profile data to localStorage
    try {
      const updatedProfile = {
        ...profileData,
        profileImage,
      }
      localStorage.setItem("cannabisProfileData", JSON.stringify(updatedProfile))
    } catch (error) {
      console.error("Error saving profile data:", error)
    }

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success("Profile updated successfully!")
    }, 1500)
  }

  const handleProfileImageClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Create a URL for the selected image
      const imageUrl = URL.createObjectURL(file)
      setProfileImage(imageUrl)
      toast.success("Profile picture updated")
    }
  }

  const handleImageError = () => {
    setImgError(true)
  }

  const handleSaveNotifications = () => {
    // Save notification preferences to localStorage
    try {
      const updatedProfile = {
        ...profileData,
      }
      localStorage.setItem("cannabisProfileData", JSON.stringify(updatedProfile))
      toast.success("Notification preferences saved")
    } catch (error) {
      console.error("Error saving notification preferences:", error)
    }
  }

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-4 md:mb-6 text-2xl md:text-3xl font-bold">My Profile</h1>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
            <TabsTrigger value="profile" className="flex-1">
              Profile Information
            </TabsTrigger>
            <TabsTrigger value="security" className="flex-1">
              Security
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex-1">
              Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-0">
            <div className="grid gap-4 md:gap-6 md:grid-cols-3">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle>Profile Picture</CardTitle>
                  <CardDescription>Update your profile photo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center">
                    <div className="relative mb-4">
                      <div className="h-32 w-32 overflow-hidden rounded-full bg-gray-100">
                        <img
                          src={imgError ? "/placeholder.svg?height=128&width=128" : profileImage}
                          alt="Profile"
                          className="h-full w-full object-cover"
                          onError={handleImageError}
                        />
                      </div>
                      <Button
                        size="icon"
                        className="absolute bottom-0 right-0 h-8 w-8 rounded-full"
                        variant="secondary"
                        onClick={handleProfileImageClick}
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleFileChange}
                      />
                    </div>
                    <p className="text-sm text-gray-500">
                      {profileData.firstName} {profileData.lastName}
                    </p>
                    <p className="text-xs text-gray-400">Member since May 2023</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" value={profileData.firstName} onChange={handleInputChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" value={profileData.lastName} onChange={handleInputChange} />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" value={profileData.email} onChange={handleInputChange} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" type="tel" value={profileData.phone} onChange={handleInputChange} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="company">Company Name (Optional)</Label>
                      <Input id="company" value={profileData.company} onChange={handleInputChange} />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea id="bio" value={profileData.bio} onChange={handleInputChange} rows={4} />
                    </div>

                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? "Saving Changes..." : "Save Changes"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="security" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
                <CardDescription>Manage your account security</CardDescription>
              </CardHeader>
              <CardContent>
                <form
                  className="space-y-4"
                  onSubmit={(e) => {
                    e.preventDefault()
                    toast.success("Password updated successfully")
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input id="current-password" type="password" />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button type="submit">Update Password</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>Manage how you receive notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="font-medium">New Inquiries</h3>
                      <p className="text-sm text-gray-500">Get notified when someone inquires about your listing</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="inquiry-email"
                          checked={profileData.notifications.inquiry.email}
                          onCheckedChange={(checked) => handleNotificationChange("inquiry", "email", checked)}
                        />
                        <Label htmlFor="inquiry-email">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="inquiry-push"
                          checked={profileData.notifications.inquiry.push}
                          onCheckedChange={(checked) => handleNotificationChange("inquiry", "push", checked)}
                        />
                        <Label htmlFor="inquiry-push">Push</Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="font-medium">Reservations</h3>
                      <p className="text-sm text-gray-500">Get notified when someone reserves your listing</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="reservation-email"
                          checked={profileData.notifications.reservation.email}
                          onCheckedChange={(checked) => handleNotificationChange("reservation", "email", checked)}
                        />
                        <Label htmlFor="reservation-email">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="reservation-push"
                          checked={profileData.notifications.reservation.push}
                          onCheckedChange={(checked) => handleNotificationChange("reservation", "push", checked)}
                        />
                        <Label htmlFor="reservation-push">Push</Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="font-medium">Messages</h3>
                      <p className="text-sm text-gray-500">Get notified when you receive a new message</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="message-email"
                          checked={profileData.notifications.message.email}
                          onCheckedChange={(checked) => handleNotificationChange("message", "email", checked)}
                        />
                        <Label htmlFor="message-email">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="message-push"
                          checked={profileData.notifications.message.push}
                          onCheckedChange={(checked) => handleNotificationChange("message", "push", checked)}
                        />
                        <Label htmlFor="message-push">Push</Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="font-medium">Marketing</h3>
                      <p className="text-sm text-gray-500">Receive updates about new features and promotions</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="marketing-email"
                          checked={profileData.notifications.marketing.email}
                          onCheckedChange={(checked) => handleNotificationChange("marketing", "email", checked)}
                        />
                        <Label htmlFor="marketing-email">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="marketing-push"
                          checked={profileData.notifications.marketing.push}
                          onCheckedChange={(checked) => handleNotificationChange("marketing", "push", checked)}
                        />
                        <Label htmlFor="marketing-push">Push</Label>
                      </div>
                    </div>
                  </div>

                  <Button className="mt-4" onClick={handleSaveNotifications}>
                    Save Preferences
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  )
}
