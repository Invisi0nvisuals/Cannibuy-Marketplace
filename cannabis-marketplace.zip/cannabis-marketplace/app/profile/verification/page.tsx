"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Check, Clock, Upload, Shield, AlertCircle, X, FileText } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

type FileUpload = {
  file: File
  preview: string
  uploading: boolean
  error: string | null
}

export default function VerificationPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [verificationStatus, setVerificationStatus] = useState<"none" | "pending" | "verified">("none")

  const [businessLicenseUpload, setBusinessLicenseUpload] = useState<FileUpload | null>(null)
  const [governmentIdUpload, setGovernmentIdUpload] = useState<FileUpload | null>(null)

  const businessLicenseInputRef = useRef<HTMLInputElement>(null)
  const governmentIdInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setFileUpload: React.Dispatch<React.SetStateAction<FileUpload | null>>,
  ) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "application/pdf"]
    if (!validTypes.includes(file.type)) {
      toast.error("Invalid file type. Please upload a PDF, JPG, or PNG file.")
      return
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File is too large. Maximum size is 5MB.")
      return
    }

    // Create preview URL
    const preview = file.type.startsWith("image/") ? URL.createObjectURL(file) : "" // No preview for PDFs

    setFileUpload({
      file,
      preview,
      uploading: true,
      error: null,
    })

    // Simulate upload
    setTimeout(() => {
      setFileUpload((prev) => {
        if (!prev) return null
        return {
          ...prev,
          uploading: false,
        }
      })
      toast.success(`${file.name} uploaded successfully`)
    }, 1500)
  }

  const removeFile = (setFileUpload: React.Dispatch<React.SetStateAction<FileUpload | null>>) => {
    setFileUpload(null)
  }

  const triggerFileInput = (inputRef: React.RefObject<HTMLInputElement>) => {
    inputRef.current?.click()
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!businessLicenseUpload || !governmentIdUpload) {
      toast.error("Please upload all required documents")
      return
    }

    setIsSubmitting(true)

    // Simulate verification submission
    setTimeout(() => {
      setIsSubmitting(false)
      setVerificationStatus("pending")
      toast.success("Verification request submitted successfully!")
    }, 1500)
  }

  const simulateVerification = () => {
    setVerificationStatus("verified")
    toast.success("Your account has been verified!")
  }

  const renderFilePreview = (fileUpload: FileUpload | null) => {
    if (!fileUpload) return null

    const fileName = fileUpload.file.name
    const fileType = fileUpload.file.type
    const fileSize = (fileUpload.file.size / 1024 / 1024).toFixed(2) // in MB

    return (
      <div className="mt-2 rounded-lg border p-3 relative">
        <div className="flex items-start gap-3">
          {fileType.startsWith("image/") && fileUpload.preview ? (
            <div className="relative h-16 w-16 rounded-md overflow-hidden border bg-gray-50">
              <Image src={fileUpload.preview || "/placeholder.svg"} alt={fileName} fill className="object-cover" />
            </div>
          ) : (
            <div className="flex h-16 w-16 items-center justify-center rounded-md border bg-gray-50">
              <FileText className="h-8 w-8 text-gray-400" />
            </div>
          )}

          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{fileName}</p>
            <p className="text-sm text-gray-500">
              {fileSize} MB • {fileType.split("/")[1].toUpperCase()}
            </p>
            {fileUpload.uploading ? (
              <div className="mt-1">
                <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full animate-progress" style={{ width: "75%" }}></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Uploading...</p>
              </div>
            ) : (
              <p className="text-sm text-green-600 flex items-center gap-1 mt-1">
                <Check className="h-3.5 w-3.5" /> Uploaded successfully
              </p>
            )}
          </div>

          <button
            type="button"
            onClick={() => removeFile(fileType.includes("license") ? setBusinessLicenseUpload : setGovernmentIdUpload)}
            className="text-gray-400 hover:text-gray-500"
            disabled={fileUpload.uploading}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
    )
  }

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4">
        <h1 className="mb-6 text-2xl md:text-3xl font-bold">Account Verification</h1>

        <div className="mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Verification Status</CardTitle>
              <CardDescription>Verified sellers receive a badge and gain more trust from buyers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {verificationStatus === "none" && (
                    <>
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100">
                        <AlertCircle className="h-5 w-5 text-gray-500" />
                      </div>
                      <div>
                        <p className="font-medium">Not Verified</p>
                        <p className="text-sm text-gray-500">Complete verification to gain seller benefits</p>
                      </div>
                    </>
                  )}

                  {verificationStatus === "pending" && (
                    <>
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-100">
                        <Clock className="h-5 w-5 text-yellow-500" />
                      </div>
                      <div>
                        <p className="font-medium">Verification Pending</p>
                        <p className="text-sm text-gray-500">Your verification is being reviewed</p>
                      </div>
                    </>
                  )}

                  {verificationStatus === "verified" && (
                    <>
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                        <Check className="h-5 w-5 text-green-500" />
                      </div>
                      <div>
                        <p className="font-medium">Verified Seller</p>
                        <p className="text-sm text-gray-500">Your account is verified</p>
                      </div>
                    </>
                  )}
                </div>

                {verificationStatus === "pending" && (
                  <Button variant="outline" onClick={simulateVerification}>
                    Simulate Approval
                  </Button>
                )}
              </div>

              {verificationStatus === "verified" && (
                <div className="mt-4 rounded-lg bg-green-50 p-4">
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Verification Benefits</p>
                      <ul className="mt-2 space-y-1 text-sm text-gray-600">
                        <li>• Verified badge on your profile and listings</li>
                        <li>• Higher placement in search results</li>
                        <li>• Access to premium seller tools</li>
                        <li>• Increased buyer trust and conversion rates</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {verificationStatus === "none" && (
          <Card>
            <CardHeader>
              <CardTitle>Submit Verification</CardTitle>
              <CardDescription>Please provide the required information to verify your account</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName">Business Name</Label>
                  <Input id="businessName" placeholder="Your business name" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessLicense">Business License Number</Label>
                  <Input id="businessLicense" placeholder="e.g., ABC-12345-XYZ" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="licenseDocument">Upload Business License</Label>
                  <input
                    type="file"
                    id="licenseDocument"
                    ref={businessLicenseInputRef}
                    onChange={(e) => handleFileChange(e, setBusinessLicenseUpload)}
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png"
                  />

                  {!businessLicenseUpload ? (
                    <div className="mt-1">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => triggerFileInput(businessLicenseInputRef)}
                        className="w-full"
                      >
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Document
                      </Button>
                      <p className="text-xs text-gray-500 mt-1">Accepted formats: PDF, JPG, PNG (max 5MB)</p>
                    </div>
                  ) : (
                    renderFilePreview(businessLicenseUpload)
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="idDocument">Upload Government ID</Label>
                  <input
                    type="file"
                    id="idDocument"
                    ref={governmentIdInputRef}
                    onChange={(e) => handleFileChange(e, setGovernmentIdUpload)}
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png"
                  />

                  {!governmentIdUpload ? (
                    <div className="mt-1">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => triggerFileInput(governmentIdInputRef)}
                        className="w-full"
                      >
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Document
                      </Button>
                      <p className="text-xs text-gray-500 mt-1">Accepted formats: PDF, JPG, PNG (max 5MB)</p>
                    </div>
                  ) : (
                    renderFilePreview(governmentIdUpload)
                  )}
                </div>

                <div className="rounded-lg bg-gray-50 p-4">
                  <p className="text-sm text-gray-600">
                    Your verification documents will be reviewed by our team within 1-2 business days. We'll notify you
                    once your verification is complete.
                  </p>
                </div>

                <Button
                  type="submit"
                  className="w-full mt-6"
                  disabled={
                    isSubmitting ||
                    !businessLicenseUpload ||
                    !governmentIdUpload ||
                    businessLicenseUpload?.uploading ||
                    governmentIdUpload?.uploading
                  }
                >
                  {isSubmitting ? "Submitting..." : "Submit Verification"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {verificationStatus === "pending" && (
          <Card>
            <CardHeader>
              <CardTitle>Verification in Progress</CardTitle>
              <CardDescription>Your verification is currently being reviewed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 flex items-center justify-center rounded-full bg-yellow-100">
                    <Clock className="h-5 w-5 text-yellow-500" />
                  </div>
                  <div>
                    <p className="font-medium">Submitted on May 15, 2023</p>
                    <p className="text-sm text-gray-500">Estimated completion: May 17, 2023</p>
                  </div>
                </div>

                <div className="rounded-lg bg-yellow-50 p-4">
                  <p className="text-sm text-gray-600">
                    Our team is reviewing your verification documents. This process typically takes 1-2 business days.
                    You'll receive a notification once your verification is complete.
                  </p>
                </div>

                <div className="rounded-lg border p-4">
                  <p className="font-medium">Need help?</p>
                  <p className="mt-1 text-sm text-gray-600">
                    If you have any questions about the verification process, please contact our support team.
                  </p>
                  <Button variant="link" asChild className="mt-2 h-auto p-0">
                    <Link href="/support">Contact Support</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  )
}
