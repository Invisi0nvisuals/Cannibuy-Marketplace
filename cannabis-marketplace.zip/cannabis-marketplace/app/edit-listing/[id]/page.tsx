"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "sonner"

// Sample data - same as in my-listings page
const myListings = [
  {
    id: 1,
    name: "Blue Dream",
    price: 2500,
    quantity: "5 lbs",
    testingPercentage: 24,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "active",
    inquiries: 3,
    views: 45,
    description:
      "A balanced hybrid strain with a sweet berry aroma. Blue Dream delivers swift symptom relief without heavy sedative effects, making it a popular daytime medicine.",
    type: "hybrid",
  },
  {
    id: 2,
    name: "Sour Diesel",
    price: 3000,
    quantity: "3 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "pending",
    inquiries: 1,
    views: 27,
    description:
      "An energizing sativa strain with a pungent diesel aroma. Sour Diesel helps users combat stress, pain, and depression with its high-energy cerebral effects.",
    type: "sativa",
  },
  {
    id: 3,
    name: "Girl Scout Cookies",
    price: 3500,
    quantity: "2 lbs",
    testingPercentage: 25,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "sold",
    inquiries: 5,
    views: 62,
    description:
      "A popular hybrid strain with sweet and earthy flavors. Girl Scout Cookies provides a euphoric high with full-body relaxation, making it ideal for pain relief.",
    type: "hybrid",
  },
]

export default function EditListingPage() {
  const params = useParams()
  const router = useRouter()
  const id = Number(params.id)

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [listing, setListing] = useState<any>(null)
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const [imgError, setImgError] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    type: "",
    price: "",
    quantity: "",
    thc: "",
    cbd: "",
    description: "",
    status: "",
  })

  useEffect(() => {
    // Find the listing with the matching ID
    const foundListing = myListings.find((item) => item.id === id)

    if (foundListing) {
      setListing(foundListing)
      setPreviewImage(foundListing.imageUrl)
      setFormData({
        name: foundListing.name,
        type: foundListing.type || "",
        price: foundListing.price.toString(),
        quantity: foundListing.quantity,
        thc: foundListing.testingPercentage.toString(),
        cbd: "0.5", // Default value
        description: foundListing.description,
        status: foundListing.status,
      })
    } else {
      // If no listing is found, redirect to my listings page
      toast.error("Listing not found")
      router.push("/my-listings")
    }
  }, [id, router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Create a URL for the selected image
      const imageUrl = URL.createObjectURL(file)
      setPreviewImage(imageUrl)
    }
  }

  const handleImageError = () => {
    setImgError(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success("Listing updated successfully!")
      router.push("/my-listings")
    }, 1500)
  }

  if (!listing) {
    return (
      <Layout>
        <div className="flex h-[60vh] items-center justify-center">
          <p>Loading listing...</p>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-4 md:mb-6 text-2xl md:text-3xl font-bold">Edit Listing: {listing.name}</h1>
        <Card>
          <CardHeader>
            <CardTitle>Strain Details</CardTitle>
            <CardDescription>Update the details of your strain listing.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Strain Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g., Blue Dream"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Strain Type</Label>
                  <select
                    id="type"
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    value={formData.type}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Type</option>
                    <option value="indica">Indica</option>
                    <option value="sativa">Sativa</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="price">Price (USD)</Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={handleChange}
                    placeholder="e.g., 2500"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    value={formData.quantity}
                    onChange={handleChange}
                    placeholder="e.g., 5 lbs"
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="thc">THC Percentage</Label>
                  <Input
                    id="thc"
                    type="number"
                    value={formData.thc}
                    onChange={handleChange}
                    placeholder="e.g., 24"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cbd">CBD Percentage (optional)</Label>
                  <Input id="cbd" type="number" value={formData.cbd} onChange={handleChange} placeholder="e.g., 0.5" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <select
                  id="status"
                  className="w-full rounded-md border border-input bg-background px-3 py-2"
                  value={formData.status}
                  onChange={handleChange}
                  required
                >
                  <option value="active">Active</option>
                  <option value="pending">Pending</option>
                  <option value="sold">Sold</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Describe the strain, effects, aroma, etc."
                  rows={4}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="images">Update Images</Label>
                <Input id="images" type="file" multiple accept="image/*" onChange={handleImageChange} />
                <p className="text-xs text-muted-foreground">
                  Upload up to 5 images. First image will be used as the main image.
                </p>
                {previewImage && (
                  <div className="mt-2">
                    <p className="mb-1 text-sm">Current Image:</p>
                    <img
                      src={imgError ? "/images/cannabis_market_thumbnail.png" : previewImage}
                      alt="Current"
                      className="h-40 w-auto rounded-md object-cover"
                      onError={handleImageError}
                    />
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button type="button" variant="outline" className="w-full" onClick={() => router.push("/my-listings")}>
                  Cancel
                </Button>
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? "Updating Listing..." : "Update Listing"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}
