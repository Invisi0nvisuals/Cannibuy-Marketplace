"use client"

import { useState, useEffect } from "react"
import { Layout } from "@/components/layout"
import { StrainCard } from "@/components/strain-card"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"

// Sample data
const defaultStrains = [
  {
    id: 1,
    name: "Blue Dream",
    price: 2500,
    quantity: "5 lbs",
    testingPercentage: 24,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A balanced hybrid strain with a sweet berry aroma. Blue Dream delivers swift symptom relief without heavy sedative effects, making it a popular daytime medicine.",
    type: "hybrid",
  },
  {
    id: 2,
    name: "Sour Diesel",
    price: 3000,
    quantity: "3 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "An energizing sativa strain with a pungent diesel aroma. Sour Diesel helps users combat stress, pain, and depression with its high-energy cerebral effects.",
    type: "sativa",
  },
  {
    id: 3,
    name: "Girl Scout Cookies",
    price: 3500,
    quantity: "2 lbs",
    testingPercentage: 25,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A popular hybrid strain with sweet and earthy flavors. Girl Scout Cookies provides a euphoric high with full-body relaxation, making it ideal for pain relief.",
    type: "hybrid",
  },
  {
    id: 4,
    name: "Purple Kush",
    price: 2800,
    quantity: "4 lbs",
    testingPercentage: 21,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A pure indica strain with relaxing effects. Purple Kush delivers a blissful, long-lasting euphoria with strong sedative effects, making it perfect for nighttime use.",
    type: "indica",
  },
  {
    id: 5,
    name: "OG Kush",
    price: 3200,
    quantity: "3 lbs",
    testingPercentage: 23,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A legendary strain with a complex aroma of fuel, skunk, and spice. OG Kush delivers a stress-crushing euphoria that quickly settles into the body.",
    type: "hybrid",
  },
  {
    id: 6,
    name: "Northern Lights",
    price: 2700,
    quantity: "5 lbs",
    testingPercentage: 20,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A classic indica strain with resinous buds and a sweet, spicy aroma. Northern Lights relaxes the muscles and pacifies the mind in dreamy euphoria.",
    type: "indica",
  },
  {
    id: 7,
    name: "Jack Herer",
    price: 3100,
    quantity: "2 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A sativa-dominant strain that creates a clear-headed, creative buzz. Jack Herer is perfect for daytime use with its blissful, cerebral effects.",
    type: "sativa",
  },
  {
    id: 8,
    name: "Granddaddy Purple",
    price: 2900,
    quantity: "3 lbs",
    testingPercentage: 21,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A famous indica strain with deep purple buds and a grape-like aroma. Granddaddy Purple delivers a powerful combination of cerebral euphoria and physical relaxation.",
    type: "indica",
  },
]

export default function DashboardPage() {
  const [strains, setStrains] = useState(defaultStrains)
  const [filterByTHC, setFilterByTHC] = useState(false)
  const [filteredStrains, setFilteredStrains] = useState(strains)

  // Load any user-added listings from localStorage
  useEffect(() => {
    try {
      const savedListings = JSON.parse(localStorage.getItem("cannabisListings") || "[]")
      if (savedListings.length > 0) {
        // Add the image URL to any user-added listings that don't have one
        const updatedSavedListings = savedListings.map((listing: any) => ({
          ...listing,
          imageUrl: listing.imageUrl || "/images/cannabis_market_thumbnail.png",
        }))
        // Combine user-added listings with default strains
        setStrains([...updatedSavedListings, ...defaultStrains])
      }

      // Check if a listing was just added
      const justAdded = sessionStorage.getItem("justAddedListing")
      if (justAdded === "true") {
        toast.success("Your new listing has been added to the dashboard!")
        sessionStorage.removeItem("justAddedListing")
      }
    } catch (error) {
      console.error("Error loading saved listings:", error)
    }
  }, [])

  // Apply filters when strains or filter settings change
  useEffect(() => {
    let result = strains

    if (filterByTHC) {
      result = result.filter((strain) => strain.testingPercentage > 20)
    }

    setFilteredStrains(result)
  }, [strains, filterByTHC])

  const simulateMessage = (message: string) => {
    toast(message)
  }

  const simulateStaggeredMessages = () => {
    toast("Buyer A inquired about Blue Dream")

    setTimeout(() => {
      toast("Buyer B reserved Sour Diesel")
    }, 3000)

    setTimeout(() => {
      toast("Buyer C requested video for Girl Scout Cookies")
    }, 6000)
  }

  return (
    <Layout>
      <div className="mb-4 md:mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl md:text-3xl font-bold">Available Strains</h1>
        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={simulateStaggeredMessages}
            title="This button simulates incoming notifications for demonstration purposes"
            className="text-xs sm:text-sm"
          >
            Demo Notifications
          </Button>
          <div
            className="flex items-center space-x-2"
            title="Filter strains with THC testing percentage greater than 20%"
          >
            <Switch id="testing" checked={filterByTHC} onCheckedChange={setFilterByTHC} />
            <label htmlFor="testing" className="text-sm text-gray-600">
              Testing % &gt; 20%
            </label>
          </div>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
          <TabsTrigger value="all" className="flex-1">
            All Strains
          </TabsTrigger>
          <TabsTrigger value="indica" className="flex-1">
            Indica
          </TabsTrigger>
          <TabsTrigger value="sativa" className="flex-1">
            Sativa
          </TabsTrigger>
          <TabsTrigger value="hybrid" className="flex-1">
            Hybrid
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredStrains.map((strain) => (
              <StrainCard
                key={strain.id}
                {...strain}
                onInquire={() => {
                  simulateMessage(`Inquiry sent for ${strain.name}`)
                }}
                onReserve={() => {
                  simulateMessage(`Reserved ${strain.name}`)
                }}
              />
            ))}
          </div>
        </TabsContent>

        {["indica", "sativa", "hybrid"].map((type) => (
          <TabsContent key={type} value={type} className="mt-4">
            <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredStrains
                .filter((strain) => strain.type === type)
                .map((strain) => (
                  <StrainCard
                    key={strain.id}
                    {...strain}
                    onInquire={() => {
                      simulateMessage(`Inquiry sent for ${strain.name}`)
                    }}
                    onReserve={() => {
                      simulateMessage(`Reserved ${strain.name}`)
                    }}
                  />
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </Layout>
  )
}
