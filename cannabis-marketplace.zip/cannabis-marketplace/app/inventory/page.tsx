"use client"

import { useState, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertCircle,
  ArrowUpDown,
  BarChart3,
  Calendar,
  Download,
  FileText,
  Package,
  Plus,
  RefreshCw,
  Search,
  Upload,
} from "lucide-react"
import { toast } from "sonner"
import { InventoryBatchModal } from "@/components/inventory-batch-modal"
import { InventoryAnalyticsModal } from "@/components/inventory-analytics-modal"
import { BulkUploadModal } from "@/components/bulk-upload-modal"
import { InventoryAlertSettings } from "@/components/inventory-alert-settings"

// Define inventory item type
interface InventoryItem {
  id: number
  strainName: string
  batchId: string
  quantity: string
  quantityValue: number
  unit: string
  thcPercentage: number
  harvestDate: string
  expiryDate: string
  status: "in-stock" | "low-stock" | "out-of-stock" | "expiring-soon" | "expired"
  price: number
  location: string
  lastUpdated: string
}

// Sample inventory data
const sampleInventory: InventoryItem[] = [
  {
    id: 1,
    strainName: "Blue Dream",
    batchId: "BD-2023-05-A",
    quantity: "4.2 lbs",
    quantityValue: 4.2,
    unit: "lbs",
    thcPercentage: 24,
    harvestDate: "2023-05-15",
    expiryDate: "2024-05-15",
    status: "in-stock",
    price: 2500,
    location: "Warehouse A",
    lastUpdated: "2023-11-10",
  },
  {
    id: 2,
    strainName: "Sour Diesel",
    batchId: "SD-2023-06-B",
    quantity: "0.8 lbs",
    quantityValue: 0.8,
    unit: "lbs",
    thcPercentage: 22,
    harvestDate: "2023-06-20",
    expiryDate: "2024-06-20",
    status: "low-stock",
    price: 3000,
    location: "Warehouse A",
    lastUpdated: "2023-11-12",
  },
  {
    id: 3,
    strainName: "Girl Scout Cookies",
    batchId: "GSC-2023-04-C",
    quantity: "0 lbs",
    quantityValue: 0,
    unit: "lbs",
    thcPercentage: 25,
    harvestDate: "2023-04-10",
    expiryDate: "2024-04-10",
    status: "out-of-stock",
    price: 3500,
    location: "Warehouse B",
    lastUpdated: "2023-11-05",
  },
  {
    id: 4,
    strainName: "OG Kush",
    batchId: "OGK-2023-03-A",
    quantity: "2.5 lbs",
    quantityValue: 2.5,
    unit: "lbs",
    thcPercentage: 26,
    harvestDate: "2023-03-15",
    expiryDate: "2023-12-15",
    status: "expiring-soon",
    price: 2800,
    location: "Warehouse A",
    lastUpdated: "2023-11-08",
  },
  {
    id: 5,
    strainName: "Purple Haze",
    batchId: "PH-2023-02-B",
    quantity: "1.2 lbs",
    quantityValue: 1.2,
    unit: "lbs",
    thcPercentage: 20,
    harvestDate: "2023-02-10",
    expiryDate: "2023-11-10",
    status: "expired",
    price: 2200,
    location: "Warehouse B",
    lastUpdated: "2023-11-01",
  },
  {
    id: 6,
    strainName: "Northern Lights",
    batchId: "NL-2023-07-A",
    quantity: "3.7 lbs",
    quantityValue: 3.7,
    unit: "lbs",
    thcPercentage: 23,
    harvestDate: "2023-07-05",
    expiryDate: "2024-07-05",
    status: "in-stock",
    price: 2700,
    location: "Warehouse C",
    lastUpdated: "2023-11-15",
  },
  {
    id: 7,
    strainName: "Granddaddy Purple",
    batchId: "GDP-2023-08-C",
    quantity: "0.5 lbs",
    quantityValue: 0.5,
    unit: "lbs",
    thcPercentage: 21,
    harvestDate: "2023-08-20",
    expiryDate: "2024-08-20",
    status: "low-stock",
    price: 2900,
    location: "Warehouse A",
    lastUpdated: "2023-11-18",
  },
]

export default function InventoryPage() {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [filteredInventory, setFilteredInventory] = useState<InventoryItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [sortField, setSortField] = useState<keyof InventoryItem | null>(null)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)
  const [showBatchModal, setShowBatchModal] = useState(false)
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false)
  const [showBulkUploadModal, setShowBulkUploadModal] = useState(false)
  const [showAlertSettings, setShowAlertSettings] = useState(false)
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null)

  // Load inventory data
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setInventory(sampleInventory)
      setFilteredInventory(sampleInventory)
      setIsLoading(false)
    }, 1000)
  }, [])

  // Filter inventory based on search query and status filter
  useEffect(() => {
    let filtered = [...inventory]

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (item) =>
          item.strainName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.batchId.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((item) => item.status === statusFilter)
    }

    // Apply sorting
    if (sortField) {
      filtered = [...filtered].sort((a, b) => {
        if (a[sortField] < b[sortField]) return sortDirection === "asc" ? -1 : 1
        if (a[sortField] > b[sortField]) return sortDirection === "asc" ? 1 : -1
        return 0
      })
    }

    setFilteredInventory(filtered)
  }, [inventory, searchQuery, statusFilter, sortField, sortDirection])

  // Handle sort
  const handleSort = (field: keyof InventoryItem) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  // Handle batch update
  const handleBatchUpdate = (item: InventoryItem) => {
    setSelectedItem(item)
    setShowBatchModal(true)
  }

  // Handle refresh inventory
  const handleRefreshInventory = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      toast.success("Inventory refreshed successfully")
      setIsLoading(false)
    }, 1000)
  }

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in-stock":
        return <Badge className="bg-green-500">In Stock</Badge>
      case "low-stock":
        return <Badge className="bg-yellow-500">Low Stock</Badge>
      case "out-of-stock":
        return <Badge className="bg-red-500">Out of Stock</Badge>
      case "expiring-soon":
        return <Badge className="bg-orange-500">Expiring Soon</Badge>
      case "expired":
        return <Badge className="bg-gray-500">Expired</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <Layout>
      <div className="container mx-auto py-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Inventory Management</h1>
            <p className="text-muted-foreground">Manage your product inventory, batches, and stock levels</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setShowBulkUploadModal(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Bulk Upload
            </Button>
            <Button variant="outline" onClick={() => setShowAlertSettings(true)}>
              <AlertCircle className="mr-2 h-4 w-4" />
              Alert Settings
            </Button>
            <Button variant="outline" onClick={() => setShowAnalyticsModal(true)}>
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Inventory</CardTitle>
              <CardDescription>Current stock value</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading
                  ? "Loading..."
                  : `$${inventory
                      .filter((item) => item.status !== "out-of-stock" && item.status !== "expired")
                      .reduce((sum, item) => sum + item.price * item.quantityValue, 0)
                      .toLocaleString()}`}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Low Stock Items</CardTitle>
              <CardDescription>Items that need attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : inventory.filter((item) => item.status === "low-stock").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Expiring Soon</CardTitle>
              <CardDescription>Items expiring within 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? "Loading..." : inventory.filter((item) => item.status === "expiring-soon").length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Inventory Items</CardTitle>
            <CardDescription>Manage your product inventory and batches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by strain name or batch ID..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <div className="w-40">
                  <select
                    className="w-full h-10 rounded-md border border-input bg-background px-3 py-2"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="all">All Status</option>
                    <option value="in-stock">In Stock</option>
                    <option value="low-stock">Low Stock</option>
                    <option value="out-of-stock">Out of Stock</option>
                    <option value="expiring-soon">Expiring Soon</option>
                    <option value="expired">Expired</option>
                  </select>
                </div>
                <Button variant="outline" onClick={handleRefreshInventory} disabled={isLoading}>
                  <RefreshCw className="h-4 w-4" />
                </Button>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("strainName")}>
                        Strain Name
                        {sortField === "strainName" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("batchId")}>
                        Batch ID
                        {sortField === "batchId" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("quantityValue")}>
                        Quantity
                        {sortField === "quantityValue" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("thcPercentage")}>
                        THC %{sortField === "thcPercentage" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("harvestDate")}>
                        Harvest Date
                        {sortField === "harvestDate" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("expiryDate")}>
                        Expiry Date
                        {sortField === "expiryDate" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>
                      <div className="flex items-center cursor-pointer" onClick={() => handleSort("status")}>
                        Status
                        {sortField === "status" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                      </div>
                    </TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8">
                        Loading inventory data...
                      </TableCell>
                    </TableRow>
                  ) : filteredInventory.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8">
                        No inventory items found. Try adjusting your filters or add new items.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredInventory.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.strainName}</TableCell>
                        <TableCell>{item.batchId}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>{item.thcPercentage}%</TableCell>
                        <TableCell>{new Date(item.harvestDate).toLocaleDateString()}</TableCell>
                        <TableCell>{new Date(item.expiryDate).toLocaleDateString()}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleBatchUpdate(item)}>
                              <Package className="h-4 w-4 mr-1" />
                              Update
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Batch Management Section */}
        <Card>
          <CardHeader>
            <CardTitle>Batch Management</CardTitle>
            <CardDescription>
              Track and manage different batches with unique harvest dates and test results
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active">
              <TabsList className="mb-4">
                <TabsTrigger value="active">Active Batches</TabsTrigger>
                <TabsTrigger value="archived">Archived Batches</TabsTrigger>
                <TabsTrigger value="upcoming">Upcoming Harvests</TabsTrigger>
              </TabsList>

              <TabsContent value="active">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Batch ID</TableHead>
                        <TableHead>Strain</TableHead>
                        <TableHead>Harvest Date</TableHead>
                        <TableHead>Test Results</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8">
                            Loading batch data...
                          </TableCell>
                        </TableRow>
                      ) : (
                        inventory
                          .filter((item) => item.status !== "expired" && item.status !== "out-of-stock")
                          .map((item) => (
                            <TableRow key={`batch-${item.id}`}>
                              <TableCell className="font-medium">{item.batchId}</TableCell>
                              <TableCell>{item.strainName}</TableCell>
                              <TableCell>{new Date(item.harvestDate).toLocaleDateString()}</TableCell>
                              <TableCell>
                                <Button variant="link" size="sm" className="h-auto p-0">
                                  <FileText className="h-4 w-4 mr-1" />
                                  View Results
                                </Button>
                              </TableCell>
                              <TableCell>{item.quantity}</TableCell>
                              <TableCell>{getStatusBadge(item.status)}</TableCell>
                              <TableCell>
                                <div className="flex gap-2">
                                  <Button variant="outline" size="sm">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    Schedule
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="archived">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Batch ID</TableHead>
                        <TableHead>Strain</TableHead>
                        <TableHead>Harvest Date</TableHead>
                        <TableHead>Archive Date</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          No archived batches found.
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              <TabsContent value="upcoming">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Strain</TableHead>
                        <TableHead>Expected Harvest</TableHead>
                        <TableHead>Expected Yield</TableHead>
                        <TableHead>Growing Location</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          No upcoming harvests scheduled.
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Modals */}
        {showBatchModal && selectedItem && (
          <InventoryBatchModal
            isOpen={showBatchModal}
            onClose={() => setShowBatchModal(false)}
            item={selectedItem}
            onUpdate={(updatedItem) => {
              // Update the inventory with the updated item
              setInventory(inventory.map((item) => (item.id === updatedItem.id ? updatedItem : item)))
              setShowBatchModal(false)
              toast.success("Batch updated successfully")
            }}
          />
        )}

        {showAnalyticsModal && (
          <InventoryAnalyticsModal
            isOpen={showAnalyticsModal}
            onClose={() => setShowAnalyticsModal(false)}
            inventory={inventory}
          />
        )}

        {showBulkUploadModal && (
          <BulkUploadModal
            isOpen={showBulkUploadModal}
            onClose={() => setShowBulkUploadModal(false)}
            onUpload={(items) => {
              // Add the uploaded items to the inventory
              setInventory([...items, ...inventory])
              setShowBulkUploadModal(false)
              toast.success(`${items.length} items uploaded successfully`)
            }}
          />
        )}

        {showAlertSettings && (
          <InventoryAlertSettings
            isOpen={showAlertSettings}
            onClose={() => setShowAlertSettings(false)}
            onSave={() => {
              setShowAlertSettings(false)
              toast.success("Alert settings updated successfully")
            }}
          />
        )}
      </div>
    </Layout>
  )
}
