"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "sonner"

export default function AddListingPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [previewImage, setPreviewImage] = useState<string | null>("/images/cannabis_market_thumbnail.png")
  const [imgError, setImgError] = useState(false)

  const [formData, setFormData] = useState({
    name: "",
    type: "",
    price: "",
    quantity: "",
    thc: "",
    cbd: "",
    description: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const imageUrl = URL.createObjectURL(file)
      setPreviewImage(imageUrl)
    }
  }

  const handleImageError = () => {
    setImgError(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Validate form
    if (
      !formData.name ||
      !formData.type ||
      !formData.price ||
      !formData.quantity ||
      !formData.thc ||
      !formData.description
    ) {
      toast.error("Please fill in all required fields")
      setIsSubmitting(false)
      return
    }

    // Create new listing object
    const newListing = {
      id: Date.now(),
      name: formData.name,
      type: formData.type,
      price: Number(formData.price),
      quantity: formData.quantity,
      testingPercentage: Number(formData.thc),
      imageUrl: previewImage || "/images/cannabis_market_thumbnail.png",
      description: formData.description,
      status: "active",
      inquiries: 0,
      views: 0,
    }

    // Save to localStorage
    try {
      const existingListings = JSON.parse(localStorage.getItem("cannabisListings") || "[]")
      localStorage.setItem("cannabisListings", JSON.stringify([newListing, ...existingListings]))

      // Also add to sessionStorage for immediate display without page refresh
      sessionStorage.setItem("justAddedListing", "true")
    } catch (error) {
      console.error("Error saving listing:", error)
    }

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success("Listing added successfully!")
      // Redirect to my listings page
      router.push("/my-listings")
    }, 1500)
  }

  return (
    <Layout>
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-4 md:mb-6 text-2xl md:text-3xl font-bold">Add New Strain Listing</h1>
        <Card>
          <CardHeader>
            <CardTitle>Strain Details</CardTitle>
            <CardDescription>Enter the details of the strain you want to list for sale.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Strain Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Blue Dream"
                    required
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Strain Type</Label>
                  <select
                    id="type"
                    className="w-full rounded-md border border-input bg-background px-3 py-2"
                    required
                    value={formData.type}
                    onChange={handleChange}
                  >
                    <option value="">Select Type</option>
                    <option value="indica">Indica</option>
                    <option value="sativa">Sativa</option>
                    <option value="hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="price">Price (USD)</Label>
                  <Input
                    id="price"
                    type="number"
                    placeholder="e.g., 2500"
                    required
                    value={formData.price}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    placeholder="e.g., 5 lbs"
                    required
                    value={formData.quantity}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="thc">THC Percentage</Label>
                  <Input
                    id="thc"
                    type="number"
                    placeholder="e.g., 24"
                    required
                    value={formData.thc}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cbd">CBD Percentage (optional)</Label>
                  <Input id="cbd" type="number" placeholder="e.g., 0.5" value={formData.cbd} onChange={handleChange} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the strain, effects, aroma, etc."
                  rows={4}
                  required
                  value={formData.description}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="images">Upload Images</Label>
                <Input id="images" type="file" accept="image/*" onChange={handleImageChange} />
                <p className="text-xs text-muted-foreground">
                  Upload an image for your listing or use the default cannabis leaf image.
                </p>
                {previewImage && (
                  <div className="mt-2">
                    <p className="mb-1 text-sm">Preview:</p>
                    <img
                      src={previewImage || "/placeholder.svg"}
                      alt="Preview"
                      className="h-40 w-auto rounded-md object-cover"
                      onError={handleImageError}
                    />
                  </div>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Adding Listing..." : "Add Listing"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}
