"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "sonner"
import { Edit, Trash2, Eye, MoreHorizontal } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { StrainModal } from "@/components/strain-modal"
import Image from "next/image"

interface Listing {
  id: number
  name: string
  price: number
  quantity: string
  testingPercentage: number
  imageUrl: string
  status: "active" | "pending" | "sold"
  inquiries: number
  views: number
  description: string
  type?: string
}

// Default listings
const defaultListings: Listing[] = [
  {
    id: 1,
    name: "Blue Dream",
    price: 2500,
    quantity: "5 lbs",
    testingPercentage: 24,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "active",
    inquiries: 3,
    views: 45,
    description:
      "A balanced hybrid strain with a sweet berry aroma. Blue Dream delivers swift symptom relief without heavy sedative effects, making it a popular daytime medicine.",
    type: "hybrid",
  },
  {
    id: 2,
    name: "Sour Diesel",
    price: 3000,
    quantity: "3 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "pending",
    inquiries: 1,
    views: 27,
    description:
      "An energizing sativa strain with a pungent diesel aroma. Sour Diesel helps users combat stress, pain, and depression with its high-energy cerebral effects.",
    type: "sativa",
  },
  {
    id: 3,
    name: "Girl Scout Cookies",
    price: 3500,
    quantity: "2 lbs",
    testingPercentage: 25,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    status: "sold",
    inquiries: 5,
    views: 62,
    description:
      "A popular hybrid strain with sweet and earthy flavors. Girl Scout Cookies provides a euphoric high with full-body relaxation, making it ideal for pain relief.",
    type: "hybrid",
  },
]

export default function MyListingsPage() {
  const [listings, setListings] = useState<Listing[]>(defaultListings)
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null)
  const [editingListing, setEditingListing] = useState<Listing | null>(null)
  const [imgError, setImgError] = useState<Record<number, boolean>>({})

  // Load user-added listings from localStorage
  useEffect(() => {
    try {
      const savedListings = JSON.parse(localStorage.getItem("cannabisListings") || "[]")
      if (savedListings.length > 0) {
        // Convert user-added listings to the correct format
        const formattedUserListings = savedListings.map((listing: any) => ({
          ...listing,
          status: listing.status || "active",
          inquiries: listing.inquiries || 0,
          views: listing.views || 0,
          imageUrl: listing.imageUrl || "/images/cannabis_market_thumbnail.png",
        }))

        // Combine with default listings
        setListings([...formattedUserListings, ...defaultListings])
      }

      // Check if a listing was just added
      const justAdded = sessionStorage.getItem("justAddedListing")
      if (justAdded === "true") {
        toast.success("Your new listing has been added to My Listings!")
        sessionStorage.removeItem("justAddedListing")
      }
    } catch (error) {
      console.error("Error loading saved listings:", error)
    }
  }, [])

  const deleteListing = (id: number) => {
    // Remove from state
    setListings(listings.filter((listing) => listing.id !== id))

    // Also remove from localStorage if it's a user-added listing
    try {
      const savedListings = JSON.parse(localStorage.getItem("cannabisListings") || "[]")
      const updatedSavedListings = savedListings.filter((listing: any) => listing.id !== id)
      localStorage.setItem("cannabisListings", JSON.stringify(updatedSavedListings))
    } catch (error) {
      console.error("Error deleting listing from localStorage:", error)
    }

    toast.success("Listing deleted successfully")
  }

  const handleViewListing = (listing: Listing) => {
    setSelectedListing(listing)
  }

  const handleEditListing = (listing: Listing) => {
    // Redirect to edit page with the listing ID
    window.location.href = `/edit-listing/${listing.id}`
  }

  const handleImageError = (id: number) => {
    setImgError((prev) => ({ ...prev, [id]: true }))
  }

  return (
    <Layout>
      <div className="mx-auto max-w-6xl">
        <div className="mb-4 md:mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h1 className="text-2xl md:text-3xl font-bold">My Listings</h1>
          <Button asChild>
            <Link href="/add-listing">Add New Listing</Link>
          </Button>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
            <TabsTrigger value="all" className="flex-1">
              All Listings
            </TabsTrigger>
            <TabsTrigger value="active" className="flex-1">
              Active
            </TabsTrigger>
            <TabsTrigger value="pending" className="flex-1">
              Pending
            </TabsTrigger>
            <TabsTrigger value="sold" className="flex-1">
              Sold
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            <div className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
              {listings.length > 0 ? (
                listings.map((listing) => (
                  <Card key={listing.id} className="h-full flex flex-col">
                    <CardHeader className="p-0">
                      <div className="relative">
                        <div
                          className="h-48 w-full cursor-pointer overflow-hidden"
                          onClick={() => handleViewListing(listing)}
                        >
                          <Image
                            src={imgError[listing.id] ? "/images/cannabis_market_thumbnail.png" : listing.imageUrl}
                            alt={listing.name}
                            width={400}
                            height={200}
                            className="h-full w-full object-cover transition-transform hover:scale-105"
                            onError={() => handleImageError(listing.id)}
                          />
                        </div>
                        <div
                          className={`absolute right-2 top-2 rounded-full px-2 py-1 text-xs font-medium text-white ${
                            listing.status === "active"
                              ? "bg-green-500"
                              : listing.status === "pending"
                                ? "bg-yellow-500"
                                : "bg-gray-500"
                          }`}
                        >
                          {listing.status.charAt(0).toUpperCase() + listing.status.slice(1)}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 flex-grow">
                      <h3
                        className="text-lg sm:text-xl font-bold text-green-700 cursor-pointer hover:underline line-clamp-1"
                        onClick={() => handleViewListing(listing)}
                      >
                        {listing.name}
                      </h3>
                      <div className="mt-2 space-y-1">
                        <p className="text-gray-600">Price: ${listing.price.toLocaleString()}</p>
                        <p className="text-gray-600">Quantity: {listing.quantity}</p>
                        <p className="text-gray-600">Testing: {listing.testingPercentage}%</p>
                      </div>
                      <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
                        <span>{listing.views} views</span>
                        <span>{listing.inquiries} inquiries</span>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between p-4 flex-wrap gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleViewListing(listing)}>
                        <Eye className="mr-1 h-4 w-4" />
                        View
                      </Button>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditListing(listing)}>
                          <Edit className="mr-1 h-4 w-4" />
                          Edit
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => deleteListing(listing.id)}>
                              <Trash2 className="mr-2 h-4 w-4 text-red-500" />
                              <span className="text-red-500">Delete</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 flex h-40 items-center justify-center rounded-lg border border-dashed">
                  <p className="text-gray-500">No listings found. Add your first listing!</p>
                </div>
              )}
            </div>
          </TabsContent>

          {["active", "pending", "sold"].map((status) => (
            <TabsContent key={status} value={status} className="mt-0">
              <div className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
                {listings.filter((listing) => listing.status === status).length > 0 ? (
                  listings
                    .filter((listing) => listing.status === status)
                    .map((listing) => (
                      <Card key={listing.id} className="h-full flex flex-col">
                        <CardHeader className="p-0">
                          <div className="relative">
                            <div
                              className="h-48 w-full cursor-pointer overflow-hidden"
                              onClick={() => handleViewListing(listing)}
                            >
                              <Image
                                src={imgError[listing.id] ? "/images/cannabis_market_thumbnail.png" : listing.imageUrl}
                                alt={listing.name}
                                width={400}
                                height={200}
                                className="h-full w-full object-cover transition-transform hover:scale-105"
                                onError={() => handleImageError(listing.id)}
                              />
                            </div>
                            <div
                              className={`absolute right-2 top-2 rounded-full px-2 py-1 text-xs font-medium text-white ${
                                listing.status === "active"
                                  ? "bg-green-500"
                                  : listing.status === "pending"
                                    ? "bg-yellow-500"
                                    : "bg-gray-500"
                              }`}
                            >
                              {listing.status.charAt(0).toUpperCase() + listing.status.slice(1)}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-4 flex-grow">
                          <h3
                            className="text-lg sm:text-xl font-bold text-green-700 cursor-pointer hover:underline line-clamp-1"
                            onClick={() => handleViewListing(listing)}
                          >
                            {listing.name}
                          </h3>
                          <div className="mt-2 space-y-1">
                            <p className="text-gray-600">Price: ${listing.price.toLocaleString()}</p>
                            <p className="text-gray-600">Quantity: {listing.quantity}</p>
                            <p className="text-gray-600">Testing: {listing.testingPercentage}%</p>
                          </div>
                          <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
                            <span>{listing.views} views</span>
                            <span>{listing.inquiries} inquiries</span>
                          </div>
                        </CardContent>
                        <CardFooter className="flex justify-between p-4 flex-wrap gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleViewListing(listing)}>
                            <Eye className="mr-1 h-4 w-4" />
                            View
                          </Button>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleEditListing(listing)}>
                              <Edit className="mr-1 h-4 w-4" />
                              Edit
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => deleteListing(listing.id)}>
                                  <Trash2 className="mr-2 h-4 w-4 text-red-500" />
                                  <span className="text-red-500">Delete</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </CardFooter>
                      </Card>
                    ))
                ) : (
                  <div className="col-span-3 flex h-40 items-center justify-center rounded-lg border border-dashed">
                    <p className="text-gray-500">No {status} listings found</p>
                  </div>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {selectedListing && (
          <StrainModal
            isOpen={!!selectedListing}
            onClose={() => setSelectedListing(null)}
            strain={{
              name: selectedListing.name,
              description: selectedListing.description,
              price: selectedListing.price,
              quantity: selectedListing.quantity,
              testingPercentage: selectedListing.testingPercentage,
              imageUrl: imgError[selectedListing.id]
                ? "/images/cannabis_market_thumbnail.png"
                : selectedListing.imageUrl,
            }}
          />
        )}
      </div>
    </Layout>
  )
}
