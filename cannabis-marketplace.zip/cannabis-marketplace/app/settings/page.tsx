"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { toast } from "sonner"

// Add these imports at the top with the other imports
import { PlanSelectionModal } from "@/components/plan-selection-modal"
import { PaymentMethodForm } from "@/components/payment-method-form"

// Default settings
const defaultSettings = {
  username: "johnsmith",
  timezone: "America/Los_Angeles",
  language: "en",
  appearance: {
    theme: "light", // light, dark, system
    accentColor: "green", // green, blue, purple, orange, red
    fontSize: 50, // 0-100
  },
}

export default function SettingsPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [settings, setSettings] = useState(defaultSettings)

  // Add these state variables inside the SettingsPage component, after the existing state variables
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false)
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false)

  // Load saved settings from localStorage on component mount
  useEffect(() => {
    try {
      const savedSettings = localStorage.getItem("cannabisSettings")
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings))
      }
    } catch (error) {
      console.error("Error loading settings:", error)
    }

    // Apply saved appearance settings
    applyAppearanceSettings()
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target
    setSettings((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleThemeChange = (theme: string) => {
    setSettings((prev) => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        theme,
      },
    }))
  }

  const handleAccentColorChange = (color: string) => {
    setSettings((prev) => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        accentColor: color,
      },
    }))
  }

  const handleFontSizeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSettings((prev) => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        fontSize: Number.parseInt(e.target.value),
      },
    }))
  }

  const applyAppearanceSettings = () => {
    try {
      const savedSettings = JSON.parse(localStorage.getItem("cannabisSettings") || JSON.stringify(defaultSettings))
      const { theme, accentColor, fontSize } = savedSettings.appearance

      // Apply theme
      document.documentElement.classList.remove("light", "dark")
      if (theme === "system") {
        const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
        document.documentElement.classList.add(systemTheme)
      } else {
        document.documentElement.classList.add(theme)
      }

      // Apply accent color
      document.documentElement.style.setProperty("--accent-color", accentColor)

      // Apply font size
      const baseFontSize = 16 + (fontSize - 50) * 0.08 // Scale font size between ~12px and ~20px
      document.documentElement.style.setProperty("--base-font-size", `${baseFontSize}px`)

      // Add CSS variables for the accent color
      const colorMap: Record<string, string> = {
        green: "#10b981",
        blue: "#3b82f6",
        purple: "#8b5cf6",
        orange: "#f97316",
        red: "#ef4444",
      }

      document.documentElement.style.setProperty("--accent", colorMap[accentColor])
    } catch (error) {
      console.error("Error applying appearance settings:", error)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Save settings to localStorage
    try {
      localStorage.setItem("cannabisSettings", JSON.stringify(settings))
    } catch (error) {
      console.error("Error saving settings:", error)
    }

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast.success("Settings updated successfully!")
    }, 1500)
  }

  const handleSaveAppearance = () => {
    // Save appearance settings to localStorage
    try {
      localStorage.setItem("cannabisSettings", JSON.stringify(settings))

      // Apply the new appearance settings
      applyAppearanceSettings()

      toast.success("Appearance preferences saved")
    } catch (error) {
      console.error("Error saving appearance settings:", error)
    }
  }

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <h1 className="mb-6 text-3xl font-bold">Settings</h1>

        <Tabs defaultValue="account" className="w-full">
          <TabsList className="mb-4 flex flex-wrap">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="api">API Keys</TabsTrigger>
          </TabsList>

          <TabsContent value="account" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input id="username" value={settings.username} onChange={handleInputChange} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <select
                      id="timezone"
                      className="w-full rounded-md border border-input bg-background px-3 py-2"
                      value={settings.timezone}
                      onChange={handleInputChange}
                    >
                      <option value="America/Los_Angeles">Pacific Time (US & Canada)</option>
                      <option value="America/Denver">Mountain Time (US & Canada)</option>
                      <option value="America/Chicago">Central Time (US & Canada)</option>
                      <option value="America/New_York">Eastern Time (US & Canada)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <select
                      id="language"
                      className="w-full rounded-md border border-input bg-background px-3 py-2"
                      value={settings.language}
                      onChange={handleInputChange}
                    >
                      <option value="en">English</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div>
                      <h3 className="font-medium">Two-Factor Authentication</h3>
                      <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => {
                        toast.success("Two-Factor Authentication setup initiated")
                      }}
                    >
                      Enable
                    </Button>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div>
                      <h3 className="font-medium">Delete Account</h3>
                      <p className="text-sm text-gray-500">Permanently delete your account and all associated data</p>
                    </div>
                    <Button
                      variant="destructive"
                      onClick={() => {
                        if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
                          toast.success("Account deletion process initiated")
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>

                  <Button type="submit" className="mt-4" disabled={isSubmitting}>
                    {isSubmitting ? "Saving Changes..." : "Save Changes"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="billing" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Billing Information</CardTitle>
                <CardDescription>Manage your billing details and subscription</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium">Current Plan</h3>
                    <div className="mt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-2xl font-bold">Pro Plan</p>
                        <p className="text-sm text-gray-500">$49.99/month</p>
                      </div>
                      <Button variant="outline" onClick={() => setIsPlanModalOpen(true)}>
                        Change Plan
                      </Button>
                    </div>
                    <div className="mt-4 text-sm text-gray-500">
                      <p>Next billing date: June 15, 2023</p>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium">Payment Method</h3>
                    <div className="mt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-16 rounded-md bg-gray-100 p-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-full w-full"
                          >
                            <rect width="20" height="14" x="2" y="5" rx="2" />
                            <line x1="2" x2="22" y1="10" y2="10" />
                          </svg>
                        </div>
                        <div>
                          <p className="font-medium">Visa ending in 4242</p>
                          <p className="text-sm text-gray-500">Expires 12/2025</p>
                        </div>
                      </div>
                      <Button variant="outline" onClick={() => setIsPaymentModalOpen(true)} className="mt-2 sm:mt-0">
                        Update
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium">Billing History</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center justify-between border-b pb-2">
                        <div>
                          <p className="font-medium">May 15, 2023</p>
                          <p className="text-sm text-gray-500">Pro Plan - Monthly</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">$49.99</p>
                          <p className="text-sm text-green-600">Paid</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between border-b pb-2">
                        <div>
                          <p className="font-medium">Apr 15, 2023</p>
                          <p className="text-sm text-gray-500">Pro Plan - Monthly</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">$49.99</p>
                          <p className="text-sm text-green-600">Paid</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Mar 15, 2023</p>
                          <p className="text-sm text-gray-500">Pro Plan - Monthly</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">$49.99</p>
                          <p className="text-sm text-green-600">Paid</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <CardDescription>Customize how the application looks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Theme</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="flex flex-col items-center gap-2">
                        <div
                          className={`flex h-20 w-full cursor-pointer items-center justify-center rounded-md border ${
                            settings.appearance.theme === "light" ? "border-green-500 ring-2 ring-green-500" : ""
                          } bg-white`}
                          onClick={() => handleThemeChange("light")}
                        >
                          <span className="text-sm font-medium">Light</span>
                        </div>
                        <Switch
                          id="theme-light"
                          checked={settings.appearance.theme === "light"}
                          onCheckedChange={() => handleThemeChange("light")}
                        />
                      </div>
                      <div className="flex flex-col items-center gap-2">
                        <div
                          className={`flex h-20 w-full cursor-pointer items-center justify-center rounded-md border ${
                            settings.appearance.theme === "dark" ? "border-green-500 ring-2 ring-green-500" : ""
                          } bg-gray-900 text-white`}
                          onClick={() => handleThemeChange("dark")}
                        >
                          <span className="text-sm font-medium">Dark</span>
                        </div>
                        <Switch
                          id="theme-dark"
                          checked={settings.appearance.theme === "dark"}
                          onCheckedChange={() => handleThemeChange("dark")}
                        />
                      </div>
                      <div className="flex flex-col items-center gap-2">
                        <div
                          className={`flex h-20 w-full cursor-pointer items-center justify-center rounded-md border ${
                            settings.appearance.theme === "system" ? "border-green-500 ring-2 ring-green-500" : ""
                          } bg-gradient-to-r from-white to-gray-900`}
                          onClick={() => handleThemeChange("system")}
                        >
                          <span className="text-sm font-medium">System</span>
                        </div>
                        <Switch
                          id="theme-system"
                          checked={settings.appearance.theme === "system"}
                          onCheckedChange={() => handleThemeChange("system")}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Accent Color</Label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-4">
                      {["green", "blue", "purple", "orange", "red"].map((color) => (
                        <div key={color} className="flex flex-col items-center gap-2">
                          <div
                            className={`h-10 w-10 cursor-pointer rounded-full ${
                              settings.appearance.accentColor === color ? "ring-2 ring-offset-2 ring-gray-400" : ""
                            } ${
                              color === "green"
                                ? "bg-green-600"
                                : color === "blue"
                                  ? "bg-blue-600"
                                  : color === "purple"
                                    ? "bg-purple-600"
                                    : color === "orange"
                                      ? "bg-orange-600"
                                      : "bg-red-600"
                            }`}
                            onClick={() => handleAccentColorChange(color)}
                          />
                          <Switch
                            id={`color-${color}`}
                            checked={settings.appearance.accentColor === color}
                            onCheckedChange={() => handleAccentColorChange(color)}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Font Size</Label>
                    <div className="flex items-center gap-4">
                      <span className="text-sm">A</span>
                      <Input
                        type="range"
                        className="w-full"
                        min="0"
                        max="100"
                        value={settings.appearance.fontSize}
                        onChange={handleFontSizeChange}
                      />
                      <span className="text-lg">A</span>
                    </div>
                  </div>

                  <Button className="mt-4" onClick={handleSaveAppearance}>
                    Save Preferences
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>API Keys</CardTitle>
                <CardDescription>Manage your API keys for external integrations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <h3 className="font-medium">Production API Key</h3>
                        <p className="text-sm text-gray-500">Use this key for your production environment</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => {
                          toast.success("New production API key generated")
                        }}
                        className="mt-2 sm:mt-0"
                      >
                        Generate
                      </Button>
                    </div>
                    <div className="mt-2">
                      <Input readOnly value="••••••••••••••••••••••••••••••" className="font-mono" type="password" />
                      <div className="mt-2 flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            toast.success("API key copied to clipboard")
                          }}
                        >
                          Copy
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            toast.success("API key revealed")
                          }}
                        >
                          Reveal
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <h3 className="font-medium">Development API Key</h3>
                        <p className="text-sm text-gray-500">Use this key for testing and development</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => {
                          toast.success("New development API key generated")
                        }}
                        className="mt-2 sm:mt-0"
                      >
                        Generate
                      </Button>
                    </div>
                    <div className="mt-2">
                      <Input readOnly value="sk_test_example_development_key" className="font-mono" type="password" />
                      <div className="mt-2 flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            toast.success("API key copied to clipboard")
                          }}
                        >
                          Copy
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            toast.success("API key revealed")
                          }}
                        >
                          Reveal
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      <PlanSelectionModal isOpen={isPlanModalOpen} onClose={() => setIsPlanModalOpen(false)} currentPlan="pro" />

      <PaymentMethodForm isOpen={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} />
    </Layout>
  )
}
