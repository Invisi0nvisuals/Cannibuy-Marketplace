"use client"

import { useState } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import {
  ArrowUpDown,
  ChevronRight,
  Clock,
  Download,
  Filter,
  Search,
  Shield,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"

// Define transaction types and statuses
type TransactionStatus = "pending" | "in_escrow" | "completed" | "disputed" | "refunded" | "cancelled"

interface Transaction {
  id: string
  date: string
  seller: string
  buyer: string
  amount: number
  description: string
  status: TransactionStatus
  escrowReleaseDate?: string
  paymentMethod: string
  transactionFee: number
  disputeReason?: string
  strainName?: string
  quantity?: string
}

// Sample transaction data
const sampleTransactions: Transaction[] = [
  {
    id: "TRX-12345",
    date: "2023-06-01",
    seller: "Green Farms LLC",
    buyer: "Mountain High Dispensary",
    amount: 12500,
    description: "Blue Dream - 5 lbs",
    status: "completed",
    escrowReleaseDate: "2023-06-08",
    paymentMethod: "Bank Transfer",
    transactionFee: 375,
    strainName: "Blue Dream",
    quantity: "5 lbs",
  },
  {
    id: "TRX-12346",
    date: "2023-06-03",
    seller: "Emerald Valley Growers",
    buyer: "Mountain High Dispensary",
    amount: 8750,
    description: "Sour Diesel - 3.5 lbs",
    status: "in_escrow",
    escrowReleaseDate: "2023-06-10",
    paymentMethod: "Crypto (USDC)",
    transactionFee: 262.5,
    strainName: "Sour Diesel",
    quantity: "3.5 lbs",
  },
  {
    id: "TRX-12347",
    date: "2023-06-05",
    seller: "Green Farms LLC",
    buyer: "Mountain High Dispensary",
    amount: 4200,
    description: "Girl Scout Cookies - 1.5 lbs",
    status: "pending",
    paymentMethod: "Bank Transfer",
    transactionFee: 126,
    strainName: "Girl Scout Cookies",
    quantity: "1.5 lbs",
  },
  {
    id: "TRX-12348",
    date: "2023-05-28",
    seller: "Cascade Cannabis Co.",
    buyer: "Mountain High Dispensary",
    amount: 9800,
    description: "Northern Lights - 4 lbs",
    status: "disputed",
    escrowReleaseDate: "2023-06-04",
    paymentMethod: "Bank Transfer",
    transactionFee: 294,
    disputeReason: "Product quality does not match description",
    strainName: "Northern Lights",
    quantity: "4 lbs",
  },
  {
    id: "TRX-12349",
    date: "2023-05-25",
    seller: "Pacific Northwest Growers",
    buyer: "Mountain High Dispensary",
    amount: 6300,
    description: "OG Kush - 2.5 lbs",
    status: "refunded",
    paymentMethod: "Crypto (USDC)",
    transactionFee: 189,
    disputeReason: "Order cancelled by seller",
    strainName: "OG Kush",
    quantity: "2.5 lbs",
  },
  {
    id: "TRX-12350",
    date: "2023-06-07",
    seller: "Humboldt Harvests",
    buyer: "Mountain High Dispensary",
    amount: 15000,
    description: "Wedding Cake - 6 lbs",
    status: "pending",
    paymentMethod: "Bank Transfer",
    transactionFee: 450,
    strainName: "Wedding Cake",
    quantity: "6 lbs",
  },
]

// Helper function to get status badge
function getStatusBadge(status: TransactionStatus) {
  switch (status) {
    case "pending":
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          <Clock className="mr-1 h-3 w-3" /> Pending
        </Badge>
      )
    case "in_escrow":
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          <Shield className="mr-1 h-3 w-3" /> In Escrow
        </Badge>
      )
    case "completed":
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <CheckCircle2 className="mr-1 h-3 w-3" /> Completed
        </Badge>
      )
    case "disputed":
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          <AlertTriangle className="mr-1 h-3 w-3" /> Disputed
        </Badge>
      )
    case "refunded":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <ArrowRight className="mr-1 h-3 w-3" /> Refunded
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <XCircle className="mr-1 h-3 w-3" /> Cancelled
        </Badge>
      )
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>(sampleTransactions)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  // Filter transactions based on search query and active tab
  const filteredTransactions = transactions.filter((transaction) => {
    // Search filter
    const matchesSearch =
      transaction.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.seller.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.buyer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase())

    // Tab filter
    if (activeTab === "all") return matchesSearch
    return matchesSearch && transaction.status === activeTab
  })

  // Calculate totals
  const totalTransactions = filteredTransactions.length
  const totalValue = filteredTransactions.reduce((sum, transaction) => sum + transaction.amount, 0)
  const pendingValue = filteredTransactions
    .filter((t) => t.status === "pending" || t.status === "in_escrow")
    .reduce((sum, transaction) => sum + transaction.amount, 0)

  const handleExportCSV = () => {
    // Create CSV content
    let csvContent = "ID,Date,Description,Amount,Status\n"

    // Add each transaction as a row
    filteredTransactions.forEach((transaction) => {
      const row = [
        transaction.id,
        new Date(transaction.date).toLocaleDateString(),
        transaction.description.replace(/,/g, ";"), // Replace commas to avoid CSV issues
        transaction.amount,
        transaction.status,
      ].join(",")
      csvContent += row + "\n"
    })

    // Create a Blob with the CSV content
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })

    // Create a download link and trigger it
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transactions-${new Date().toISOString().slice(0, 10)}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Transactions exported to CSV")
  }

  return (
    <Layout>
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h1 className="text-2xl md:text-3xl font-bold">Transactions</h1>
          <Button onClick={handleExportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-3 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalTransactions}</div>
              <p className="text-xs text-gray-500 mt-1">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalValue.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Pending Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${pendingValue.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">In escrow or pending</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>View and manage all your transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex flex-col sm:flex-row gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search transactions..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" className="flex-shrink-0">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>

            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-4 w-full overflow-x-auto flex-nowrap">
                <TabsTrigger value="all" className="flex-1">
                  All
                </TabsTrigger>
                <TabsTrigger value="pending" className="flex-1">
                  Pending
                </TabsTrigger>
                <TabsTrigger value="in_escrow" className="flex-1">
                  In Escrow
                </TabsTrigger>
                <TabsTrigger value="completed" className="flex-1">
                  Completed
                </TabsTrigger>
                <TabsTrigger value="disputed" className="flex-1">
                  Disputed
                </TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-0">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">ID</TableHead>
                        <TableHead>
                          <div className="flex items-center">
                            Date
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </div>
                        </TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTransactions.length > 0 ? (
                        filteredTransactions.map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell className="font-medium">{transaction.id}</TableCell>
                            <TableCell>{new Date(transaction.date).toLocaleDateString()}</TableCell>
                            <TableCell>{transaction.description}</TableCell>
                            <TableCell>${transaction.amount.toLocaleString()}</TableCell>
                            <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm" asChild>
                                <Link href={`/transactions/${transaction.id}`}>
                                  View <ChevronRight className="ml-1 h-4 w-4" />
                                </Link>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="h-24 text-center">
                            No transactions found.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}
