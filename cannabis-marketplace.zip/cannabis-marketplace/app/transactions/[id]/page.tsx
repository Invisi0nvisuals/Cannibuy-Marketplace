"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "sonner"
import {
  ArrowLeft,
  Clock,
  Download,
  Shield,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  FileText,
  MessageSquare,
  Truck,
  Receipt,
  HelpCircle,
} from "lucide-react"
import { DisputeTransactionDialog } from "@/components/dispute-transaction-dialog"
import { ReleaseEscrowDialog } from "@/components/release-escrow-dialog"
import { CancelTransactionDialog } from "@/components/cancel-transaction-dialog"

// Define transaction types and statuses
type TransactionStatus = "pending" | "in_escrow" | "completed" | "disputed" | "refunded" | "cancelled"

interface Transaction {
  id: string
  date: string
  seller: string
  buyer: string
  amount: number
  description: string
  status: TransactionStatus
  escrowReleaseDate?: string
  paymentMethod: string
  transactionFee: number
  disputeReason?: string
  strainName?: string
  quantity?: string
  sellerAddress?: string
  buyerAddress?: string
  deliveryMethod?: string
  estimatedDeliveryDate?: string
  trackingNumber?: string
  notes?: string
}

// Sample transaction data
const sampleTransactions: Record<string, Transaction> = {
  "TRX-12345": {
    id: "TRX-12345",
    date: "2023-06-01",
    seller: "Green Farms LLC",
    buyer: "Mountain High Dispensary",
    amount: 12500,
    description: "Blue Dream - 5 lbs",
    status: "completed",
    escrowReleaseDate: "2023-06-08",
    paymentMethod: "Bank Transfer",
    transactionFee: 375,
    strainName: "Blue Dream",
    quantity: "5 lbs",
    sellerAddress: "123 Farm Rd, Humboldt, CA 95519",
    buyerAddress: "456 High St, Denver, CO 80014",
    deliveryMethod: "Secure Courier",
    estimatedDeliveryDate: "2023-06-07",
    trackingNumber: "TRACK123456",
    notes: "Delivery completed on time. Product quality verified.",
  },
  "TRX-12346": {
    id: "TRX-12346",
    date: "2023-06-03",
    seller: "Emerald Valley Growers",
    buyer: "Mountain High Dispensary",
    amount: 8750,
    description: "Sour Diesel - 3.5 lbs",
    status: "in_escrow",
    escrowReleaseDate: "2023-06-10",
    paymentMethod: "Crypto (USDC)",
    transactionFee: 262.5,
    strainName: "Sour Diesel",
    quantity: "3.5 lbs",
    sellerAddress: "789 Green Valley, Eugene, OR 97401",
    buyerAddress: "456 High St, Denver, CO 80014",
    deliveryMethod: "Secure Courier",
    estimatedDeliveryDate: "2023-06-09",
    trackingNumber: "TRACK654321",
  },
  "TRX-12347": {
    id: "TRX-12347",
    date: "2023-06-05",
    seller: "Green Farms LLC",
    buyer: "Mountain High Dispensary",
    amount: 4200,
    description: "Girl Scout Cookies - 1.5 lbs",
    status: "pending",
    paymentMethod: "Bank Transfer",
    transactionFee: 126,
    strainName: "Girl Scout Cookies",
    quantity: "1.5 lbs",
    sellerAddress: "123 Farm Rd, Humboldt, CA 95519",
    buyerAddress: "456 High St, Denver, CO 80014",
    deliveryMethod: "Secure Courier",
    estimatedDeliveryDate: "2023-06-12",
  },
  "TRX-12348": {
    id: "TRX-12348",
    date: "2023-05-28",
    seller: "Cascade Cannabis Co.",
    buyer: "Mountain High Dispensary",
    amount: 9800,
    description: "Northern Lights - 4 lbs",
    status: "disputed",
    escrowReleaseDate: "2023-06-04",
    paymentMethod: "Bank Transfer",
    transactionFee: 294,
    disputeReason: "Product quality does not match description",
    strainName: "Northern Lights",
    quantity: "4 lbs",
    sellerAddress: "321 Mountain View, Seattle, WA 98101",
    buyerAddress: "456 High St, Denver, CO 80014",
    deliveryMethod: "Secure Courier",
    estimatedDeliveryDate: "2023-06-03",
    trackingNumber: "TRACK789012",
    notes: "Dispute filed on 2023-06-03. Awaiting resolution.",
  },
  "TRX-12349": {
    id: "TRX-12349",
    date: "2023-05-25",
    seller: "Pacific Northwest Growers",
    buyer: "Mountain High Dispensary",
    amount: 6300,
    description: "OG Kush - 2.5 lbs",
    status: "refunded",
    paymentMethod: "Crypto (USDC)",
    transactionFee: 189,
    disputeReason: "Order cancelled by seller",
    strainName: "OG Kush",
    quantity: "2.5 lbs",
    sellerAddress: "567 Pacific Ave, Portland, OR 97205",
    buyerAddress: "456 High St, Denver, CO 80014",
    notes: "Refund processed on 2023-05-26.",
  },
  "TRX-12350": {
    id: "TRX-12350",
    date: "2023-06-07",
    seller: "Humboldt Harvests",
    buyer: "Mountain High Dispensary",
    amount: 15000,
    description: "Wedding Cake - 6 lbs",
    status: "pending",
    paymentMethod: "Bank Transfer",
    transactionFee: 450,
    strainName: "Wedding Cake",
    quantity: "6 lbs",
    sellerAddress: "890 Redwood Hwy, Eureka, CA 95501",
    buyerAddress: "456 High St, Denver, CO 80014",
    deliveryMethod: "Secure Courier",
    estimatedDeliveryDate: "2023-06-14",
  },
}

// Helper function to get status badge
function getStatusBadge(status: TransactionStatus) {
  switch (status) {
    case "pending":
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          <Clock className="mr-1 h-3 w-3" /> Pending
        </Badge>
      )
    case "in_escrow":
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          <Shield className="mr-1 h-3 w-3" /> In Escrow
        </Badge>
      )
    case "completed":
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <CheckCircle2 className="mr-1 h-3 w-3" /> Completed
        </Badge>
      )
    case "disputed":
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          <AlertTriangle className="mr-1 h-3 w-3" /> Disputed
        </Badge>
      )
    case "refunded":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <ArrowRight className="mr-1 h-3 w-3" /> Refunded
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <XCircle className="mr-1 h-3 w-3" /> Cancelled
        </Badge>
      )
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

// Helper function to get available actions based on transaction status
function getAvailableActions(transaction: Transaction, setDialogOpen: any) {
  switch (transaction.status) {
    case "pending":
      return (
        <>
          <Button onClick={() => toast.success("Payment initiated")}>Make Payment</Button>
          <Button variant="outline" onClick={() => setDialogOpen("cancel")}>
            Cancel Transaction
          </Button>
        </>
      )
    case "in_escrow":
      return (
        <>
          <Button onClick={() => setDialogOpen("release")}>Release Escrow</Button>
          <Button variant="outline" onClick={() => setDialogOpen("dispute")}>
            Dispute Transaction
          </Button>
        </>
      )
    case "disputed":
      return <Button onClick={() => toast.success("Support contacted")}>Contact Support</Button>
    case "completed":
      return (
        <Button onClick={() => toast.success("Receipt downloaded")}>
          <Download className="mr-2 h-4 w-4" />
          Download Receipt
        </Button>
      )
    default:
      return null
  }
}

export default function TransactionDetailPage() {
  const params = useParams()
  const router = useRouter()
  const id = params.id as string

  const [transaction, setTransaction] = useState<Transaction | undefined>(sampleTransactions[id])
  const [isDisputeDialogOpen, setIsDisputeDialogOpen] = useState(false)
  const [isReleaseDialogOpen, setIsReleaseDialogOpen] = useState(false)
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)

  const setDialogOpen = (dialog: string) => {
    if (dialog === "dispute") setIsDisputeDialogOpen(true)
    if (dialog === "release") setIsReleaseDialogOpen(true)
    if (dialog === "cancel") setIsCancelDialogOpen(true)
  }

  if (!transaction) {
    return (
      <Layout>
        <div className="flex h-[60vh] items-center justify-center">
          <p>Transaction not found</p>
        </div>
      </Layout>
    )
  }

  const handleDownloadReceipt = () => {
    // Create a simple receipt content
    const receiptContent = `
    RECEIPT
    -----------------------------------------------
    Transaction ID: ${transaction.id}
    Date: ${new Date(transaction.date).toLocaleDateString()}
    
    Seller: ${transaction.seller}
    Buyer: ${transaction.buyer}
    
    Product: ${transaction.description}
    Amount: $${transaction.amount.toLocaleString()}
    Fee: $${transaction.transactionFee.toLocaleString()}
    Total: $${(transaction.amount + transaction.transactionFee).toLocaleString()}
    
    Payment Method: ${transaction.paymentMethod}
    Status: ${transaction.status.replace("_", " ").toUpperCase()}
    
    Thank you for your business!
    -----------------------------------------------
  `

    // Create a Blob with the content
    const blob = new Blob([receiptContent], { type: "text/plain" })

    // Create a download link and trigger it
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `receipt-${transaction.id}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("Receipt downloaded")
  }

  const handleContactSupport = () => {
    // In a real app, this would open a support ticket or chat
    toast.success("Support request submitted", {
      description: "A support agent will contact you shortly",
      action: {
        label: "Dismiss",
        onClick: () => console.log("Dismissed"),
      },
    })
  }

  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <Button variant="ghost" className="mb-4" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Transactions
        </Button>

        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
              Transaction {transaction.id}
              {getStatusBadge(transaction.status)}
            </h1>
            <p className="text-gray-500 mt-1">
              {new Date(transaction.date).toLocaleDateString()} • {transaction.paymentMethod}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownloadReceipt}>
              <Receipt className="mr-2 h-4 w-4" />
              Receipt
            </Button>
            <Button variant="outline" size="sm" onClick={handleContactSupport}>
              <HelpCircle className="mr-2 h-4 w-4" />
              Support
            </Button>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Transaction Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Amount</p>
                    <p className="text-lg font-bold">${transaction.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Fee</p>
                    <p className="text-lg">${transaction.transactionFee.toLocaleString()}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm font-medium text-gray-500">Product</p>
                  <p className="font-medium">{transaction.strainName}</p>
                  <p className="text-sm text-gray-500">Quantity: {transaction.quantity}</p>
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Seller</p>
                    <p className="font-medium">{transaction.seller}</p>
                    {transaction.sellerAddress && <p className="text-sm text-gray-500">{transaction.sellerAddress}</p>}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Buyer</p>
                    <p className="font-medium">{transaction.buyer}</p>
                    {transaction.buyerAddress && <p className="text-sm text-gray-500">{transaction.buyerAddress}</p>}
                  </div>
                </div>

                {transaction.status === "in_escrow" && transaction.escrowReleaseDate && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm font-medium text-gray-500">Escrow Release Date</p>
                      <p className="font-medium">{new Date(transaction.escrowReleaseDate).toLocaleDateString()}</p>
                      <p className="text-sm text-gray-500">
                        Funds will be automatically released if no disputes are filed
                      </p>
                    </div>
                  </>
                )}

                {transaction.status === "disputed" && transaction.disputeReason && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm font-medium text-gray-500">Dispute Reason</p>
                      <p className="font-medium text-red-600">{transaction.disputeReason}</p>
                      <p className="text-sm text-gray-500">Dispute filed on {new Date().toLocaleDateString()}</p>
                    </div>
                  </>
                )}

                {transaction.notes && (
                  <>
                    <Separator />
                    <div>
                      <p className="text-sm font-medium text-gray-500">Notes</p>
                      <p className="text-sm">{transaction.notes}</p>
                    </div>
                  </>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                {getAvailableActions(transaction, setDialogOpen)}
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Shipping & Delivery</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {transaction.deliveryMethod ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-gray-500">Delivery Method</p>
                        <p className="font-medium">{transaction.deliveryMethod}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-500">Estimated Delivery</p>
                        <p className="font-medium">
                          {transaction.estimatedDeliveryDate
                            ? new Date(transaction.estimatedDeliveryDate).toLocaleDateString()
                            : "Not scheduled"}
                        </p>
                      </div>
                    </div>

                    {transaction.trackingNumber && (
                      <>
                        <Separator />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Tracking Number</p>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{transaction.trackingNumber}</p>
                            <Button
                              variant="link"
                              className="h-auto p-0"
                              onClick={() => toast.success("Tracking information opened")}
                            >
                              Track Package
                            </Button>
                          </div>
                        </div>
                      </>
                    )}
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                    <Truck className="h-12 w-12 text-gray-300" />
                    <p className="mt-2 font-medium">No shipping information available</p>
                    <p className="text-sm text-gray-500">
                      Shipping details will appear here once the order is processed
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Payment Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Transaction Created</p>
                      <p className="text-sm text-gray-500">{new Date(transaction.date).toLocaleDateString()}</p>
                    </div>
                  </div>

                  {(transaction.status === "in_escrow" ||
                    transaction.status === "completed" ||
                    transaction.status === "disputed") && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">Payment Received</p>
                        <p className="text-sm text-gray-500">
                          {new Date(new Date(transaction.date).getTime() + 86400000).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}

                  {(transaction.status === "in_escrow" ||
                    transaction.status === "completed" ||
                    transaction.status === "disputed") && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center">
                        <Shield className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">Funds in Escrow</p>
                        <p className="text-sm text-gray-500">
                          {new Date(new Date(transaction.date).getTime() + 86400000).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}

                  {transaction.status === "disputed" && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-red-100 flex items-center justify-center">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      </div>
                      <div>
                        <p className="font-medium">Dispute Filed</p>
                        <p className="text-sm text-gray-500">
                          {new Date(new Date(transaction.date).getTime() + 86400000 * 3).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}

                  {transaction.status === "completed" && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">Funds Released</p>
                        <p className="text-sm text-gray-500">
                          {transaction.escrowReleaseDate
                            ? new Date(transaction.escrowReleaseDate).toLocaleDateString()
                            : "N/A"}
                        </p>
                      </div>
                    </div>
                  )}

                  {transaction.status === "refunded" && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-gray-100 flex items-center justify-center">
                        <ArrowRight className="h-4 w-4 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">Funds Refunded</p>
                        <p className="text-sm text-gray-500">
                          {new Date(new Date(transaction.date).getTime() + 86400000).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}

                  {transaction.status === "cancelled" && (
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 h-6 w-6 rounded-full bg-gray-100 flex items-center justify-center">
                        <XCircle className="h-4 w-4 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">Transaction Cancelled</p>
                        <p className="text-sm text-gray-500">
                          {new Date(new Date(transaction.date).getTime() + 86400000).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      toast.success("Message sent to " + (transaction.status === "pending" ? "seller" : "buyer"), {
                        description: "Your message has been delivered",
                      })
                    }}
                  >
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Message {transaction.status === "pending" ? "Seller" : "Buyer"}
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      // Create a simple contract view
                      toast.success("Contract opened", {
                        description: "Contract details are being loaded",
                        action: {
                          label: "View",
                          onClick: () => window.open(`/contracts/${transaction.id}`, "_blank"),
                        },
                      })
                    }}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    View Contract
                  </Button>
                  {transaction.status === "in_escrow" && (
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => {
                        toast.success("Tracking updated", {
                          description: "Tracking information has been updated",
                        })
                      }}
                    >
                      <Truck className="mr-2 h-4 w-4" />
                      Update Tracking
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <DisputeTransactionDialog
        open={isDisputeDialogOpen}
        onOpenChange={setIsDisputeDialogOpen}
        transactionId={transaction.id}
      />

      <ReleaseEscrowDialog
        open={isReleaseDialogOpen}
        onOpenChange={setIsReleaseDialogOpen}
        transactionId={transaction.id}
        amount={transaction.amount}
      />

      <CancelTransactionDialog
        open={isCancelDialogOpen}
        onOpenChange={setIsCancelDialogOpen}
        transactionId={transaction.id}
      />
    </Layout>
  )
}
