"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { toast } from "sonner"
import { ArrowLeft, MessageCircle, Camera, Share2 } from "lucide-react"
import { InquireModal } from "@/components/inquire-modal"
import { ReserveModal } from "@/components/reserve-modal"

// Sample data - same as in the main page
const strains = [
  {
    id: 1,
    name: "Blue Dream",
    price: 2500,
    quantity: "5 lbs",
    testingPercentage: 24,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A balanced hybrid strain with a sweet berry aroma. Blue Dream delivers swift symptom relief without heavy sedative effects, making it a popular daytime medicine.",
    type: "hybrid",
  },
  {
    id: 2,
    name: "Sour Diesel",
    price: 3000,
    quantity: "3 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "An energizing sativa strain with a pungent diesel aroma. Sour Diesel helps users combat stress, pain, and depression with its high-energy cerebral effects.",
    type: "sativa",
  },
  {
    id: 3,
    name: "Girl Scout Cookies",
    price: 3500,
    quantity: "2 lbs",
    testingPercentage: 25,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A popular hybrid strain with sweet and earthy flavors. Girl Scout Cookies provides a euphoric high with full-body relaxation, making it ideal for pain relief.",
    type: "hybrid",
  },
]

export default function ListingDetailPage() {
  const params = useParams()
  const router = useRouter()
  const id = Number(params.id)

  const [strain, setStrain] = useState<any>(null)
  const [isInquireModalOpen, setIsInquireModalOpen] = useState(false)
  const [isReserveModalOpen, setIsReserveModalOpen] = useState(false)
  const [imgError, setImgError] = useState(false)

  useEffect(() => {
    // Find the strain with the matching ID
    const foundStrain = strains.find((item) => item.id === id)

    if (foundStrain) {
      setStrain(foundStrain)
    } else {
      // If no strain is found, redirect to home page
      toast.error("Listing not found")
      router.push("/")
    }
  }, [id, router])

  const handleRequestVideo = () => {
    toast.success("Video request sent to seller")
  }

  const handleShare = () => {
    toast.success("Listing link copied to clipboard")
  }

  const handleImageError = () => {
    setImgError(true)
  }

  if (!strain) {
    return (
      <Layout>
        <div className="flex h-[60vh] items-center justify-center">
          <p>Loading listing...</p>
        </div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="mx-auto max-w-5xl">
        <Button variant="ghost" className="mb-4" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="relative aspect-square overflow-hidden rounded-lg">
            <img
              src={imgError ? "/images/cannabis_market_thumbnail.png" : strain.imageUrl}
              alt={strain.name}
              className="h-full w-full object-cover"
              onError={handleImageError}
            />
            {strain.type && (
              <div className="absolute left-4 top-4 rounded-full bg-black/60 px-3 py-1 text-sm font-medium text-white">
                {strain.type.charAt(0).toUpperCase() + strain.type.slice(1)}
              </div>
            )}
          </div>

          <div className="space-y-4 md:space-y-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-green-700">{strain.name}</h1>
              <p className="mt-2 text-xl font-semibold">${strain.price.toLocaleString()}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="font-medium text-green-700">Quantity</p>
                <p className="text-gray-600">{strain.quantity}</p>
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="font-medium text-green-700">Testing</p>
                <p className="text-gray-600">{strain.testingPercentage}%</p>
              </div>
            </div>

            <div>
              <h2 className="text-lg font-semibold">Description</h2>
              <p className="mt-2 text-gray-600">{strain.description}</p>
            </div>

            <div className="rounded-lg bg-gray-50 p-4">
              <h2 className="text-lg font-semibold">Seller Information</h2>
              <div className="mt-2 flex items-center gap-3">
                <div className="h-10 w-10 overflow-hidden rounded-full bg-gray-200">
                  <img src="/placeholder.svg?height=40&width=40" alt="Seller" className="h-full w-full object-cover" />
                </div>
                <div>
                  <p className="font-medium">Green Farms LLC</p>
                  <p className="text-sm text-gray-500">Verified Seller • 4.8 ★ (42 reviews)</p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button className="flex-1" onClick={() => setIsReserveModalOpen(true)}>
                Reserve
              </Button>
              <Button variant="outline" className="flex-1" onClick={() => setIsInquireModalOpen(true)}>
                <MessageCircle className="mr-2 h-4 w-4" />
                Inquire
              </Button>
              <Button variant="outline" onClick={handleRequestVideo}>
                <Camera className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={handleShare}>
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <Card className="mt-6 md:mt-8">
          <CardContent className="p-4 md:p-6">
            <h2 className="mb-4 text-xl font-semibold">Additional Information</h2>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="font-medium text-green-700">Growing Information</h3>
                <ul className="mt-2 space-y-1 text-gray-600">
                  <li>Flowering Time: 8-9 weeks</li>
                  <li>Yield: High</li>
                  <li>Growing Difficulty: Moderate</li>
                  <li>Growing Environment: Indoor/Outdoor</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium text-green-700">Effects & Flavors</h3>
                <ul className="mt-2 space-y-1 text-gray-600">
                  <li>Effects: Relaxed, Happy, Euphoric</li>
                  <li>Medical: Stress, Pain, Depression</li>
                  <li>Flavors: Berry, Sweet, Earthy</li>
                  <li>Terpenes: Myrcene, Pinene, Caryophyllene</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {strain && (
        <InquireModal
          isOpen={isInquireModalOpen}
          onClose={() => setIsInquireModalOpen(false)}
          strain={{
            name: strain.name,
            price: strain.price,
          }}
        />
      )}

      {strain && (
        <ReserveModal
          isOpen={isReserveModalOpen}
          onClose={() => setIsReserveModalOpen(false)}
          strain={{
            name: strain.name,
            price: strain.price,
            quantity: strain.quantity,
          }}
        />
      )}
    </Layout>
  )
}
