"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useSearchParams } from "next/navigation"
import { Layout } from "@/components/layout"
import { StrainCard } from "@/components/strain-card"
import { toast } from "sonner"
import { SlidersHorizontal, X, Save, RotateCcw } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet"

// Sample data - same as in the main page
const allStrains = [
  {
    id: 1,
    name: "Blue Dream",
    price: 2500,
    quantity: "5 lbs",
    testingPercentage: 24,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A balanced hybrid strain with a sweet berry aroma. Blue Dream delivers swift symptom relief without heavy sedative effects, making it a popular daytime medicine.",
    type: "hybrid",
    thcContent: 24,
    cbdContent: 0.1,
    growMethod: "indoor",
    harvestDate: "2023-04-15",
    seller: {
      name: "Green Farms LLC",
      rating: 4.8,
      isVerified: true,
    },
    effects: ["Relaxed", "Happy", "Euphoric", "Creative"],
    flavors: ["Berry", "Sweet", "Herbal"],
  },
  {
    id: 2,
    name: "Sour Diesel",
    price: 3000,
    quantity: "3 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "An energizing sativa strain with a pungent diesel aroma. Sour Diesel helps users combat stress, pain, and depression with its high-energy cerebral effects.",
    type: "sativa",
    thcContent: 22,
    cbdContent: 0.2,
    growMethod: "indoor",
    harvestDate: "2023-03-20",
    seller: {
      name: "Herbal Solutions",
      rating: 4.5,
      isVerified: true,
    },
    effects: ["Energetic", "Happy", "Uplifted", "Focused"],
    flavors: ["Diesel", "Citrus", "Pungent"],
  },
  {
    id: 3,
    name: "Girl Scout Cookies",
    price: 3500,
    quantity: "2 lbs",
    testingPercentage: 25,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A popular hybrid strain with sweet and earthy flavors. Girl Scout Cookies provides a euphoric high with full-body relaxation, making it ideal for pain relief.",
    type: "hybrid",
    thcContent: 25,
    cbdContent: 0.7,
    growMethod: "greenhouse",
    harvestDate: "2023-05-01",
    seller: {
      name: "Premium Buds Co.",
      rating: 4.9,
      isVerified: true,
    },
    effects: ["Relaxed", "Euphoric", "Happy", "Hungry"],
    flavors: ["Sweet", "Earthy", "Mint"],
  },
  {
    id: 4,
    name: "Purple Kush",
    price: 2800,
    quantity: "4 lbs",
    testingPercentage: 21,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A pure indica strain with relaxing effects. Purple Kush delivers a blissful, long-lasting euphoria with strong sedative effects, making it perfect for nighttime use.",
    type: "indica",
    thcContent: 21,
    cbdContent: 0.4,
    growMethod: "indoor",
    harvestDate: "2023-02-28",
    seller: {
      name: "Mountain Growers",
      rating: 4.6,
      isVerified: false,
    },
    effects: ["Relaxed", "Sleepy", "Happy", "Hungry"],
    flavors: ["Grape", "Earthy", "Sweet"],
  },
  {
    id: 5,
    name: "OG Kush",
    price: 3200,
    quantity: "3 lbs",
    testingPercentage: 23,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A legendary strain with a complex aroma of fuel, skunk, and spice. OG Kush delivers a stress-crushing euphoria that quickly settles into the body.",
    type: "hybrid",
    thcContent: 23,
    cbdContent: 0.3,
    growMethod: "outdoor",
    harvestDate: "2023-04-10",
    seller: {
      name: "West Coast Cultivators",
      rating: 4.7,
      isVerified: true,
    },
    effects: ["Relaxed", "Happy", "Euphoric", "Uplifted"],
    flavors: ["Earthy", "Pine", "Woody"],
  },
  {
    id: 6,
    name: "Northern Lights",
    price: 2700,
    quantity: "5 lbs",
    testingPercentage: 20,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A classic indica strain with resinous buds and a sweet, spicy aroma. Northern Lights relaxes the muscles and pacifies the mind in dreamy euphoria.",
    type: "indica",
    thcContent: 20,
    cbdContent: 0.1,
    growMethod: "indoor",
    harvestDate: "2023-03-15",
    seller: {
      name: "Classic Strains Inc.",
      rating: 4.4,
      isVerified: true,
    },
    effects: ["Relaxed", "Sleepy", "Happy", "Hungry"],
    flavors: ["Sweet", "Spicy", "Pine"],
  },
  {
    id: 7,
    name: "Jack Herer",
    price: 3100,
    quantity: "2 lbs",
    testingPercentage: 22,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A sativa-dominant strain that creates a clear-headed, creative buzz. Jack Herer is perfect for daytime use with its blissful, cerebral effects.",
    type: "sativa",
    thcContent: 22,
    cbdContent: 0.2,
    growMethod: "greenhouse",
    harvestDate: "2023-05-05",
    seller: {
      name: "Sativa Specialists",
      rating: 4.8,
      isVerified: true,
    },
    effects: ["Creative", "Energetic", "Happy", "Uplifted"],
    flavors: ["Earthy", "Pine", "Woody"],
  },
  {
    id: 8,
    name: "Granddaddy Purple",
    price: 2900,
    quantity: "3 lbs",
    testingPercentage: 21,
    imageUrl: "/images/cannabis_market_thumbnail.png",
    description:
      "A famous indica strain with deep purple buds and a grape-like aroma. Granddaddy Purple delivers a powerful combination of cerebral euphoria and physical relaxation.",
    type: "indica",
    thcContent: 21,
    cbdContent: 0.1,
    growMethod: "indoor",
    harvestDate: "2023-04-20",
    seller: {
      name: "Purple Genetics",
      rating: 4.7,
      isVerified: false,
    },
    effects: ["Relaxed", "Sleepy", "Happy", "Hungry"],
    flavors: ["Grape", "Berry", "Sweet"],
  },
]

// Define filter types
interface Filters {
  priceRange: [number, number]
  thcRange: [number, number]
  cbdRange: [number, number]
  types: string[]
  growMethods: string[]
  effects: string[]
  flavors: string[]
  verifiedSellersOnly: boolean
  minRating: number
  sortBy: string
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""

  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [filteredStrains, setFilteredStrains] = useState(allStrains)

  // Initialize filters with default values
  const [filters, setFilters] = useState<Filters>({
    priceRange: [0, 5000],
    thcRange: [0, 30],
    cbdRange: [0, 5],
    types: [],
    growMethods: [],
    effects: [],
    flavors: [],
    verifiedSellersOnly: false,
    minRating: 0,
    sortBy: "relevance",
  })

  // All possible filter options
  const allEffects = [
    "Relaxed",
    "Happy",
    "Euphoric",
    "Creative",
    "Energetic",
    "Focused",
    "Sleepy",
    "Hungry",
    "Uplifted",
  ]
  const allFlavors = [
    "Berry",
    "Sweet",
    "Herbal",
    "Citrus",
    "Diesel",
    "Earthy",
    "Mint",
    "Grape",
    "Pine",
    "Woody",
    "Spicy",
    "Pungent",
  ]

  // Apply filters to strains
  useEffect(() => {
    // Start with query filter
    let result = allStrains
    if (query) {
      result = result.filter(
        (strain) =>
          strain.name.toLowerCase().includes(query.toLowerCase()) ||
          strain.description.toLowerCase().includes(query.toLowerCase()) ||
          strain.type?.toLowerCase().includes(query.toLowerCase()),
      )
    }

    // Apply all other filters
    result = result.filter((strain) => {
      // Price filter
      if (strain.price < filters.priceRange[0] || strain.price > filters.priceRange[1]) {
        return false
      }

      // THC filter
      if (strain.thcContent < filters.thcRange[0] || strain.thcContent > filters.thcRange[1]) {
        return false
      }

      // CBD filter
      if (strain.cbdContent < filters.cbdRange[0] || strain.cbdContent > filters.cbdRange[1]) {
        return false
      }

      // Type filter
      if (filters.types.length > 0 && !filters.types.includes(strain.type)) {
        return false
      }

      // Grow method filter
      if (filters.growMethods.length > 0 && !filters.growMethods.includes(strain.growMethod)) {
        return false
      }

      // Effects filter
      if (filters.effects.length > 0 && !filters.effects.some((effect) => strain.effects.includes(effect))) {
        return false
      }

      // Flavors filter
      if (filters.flavors.length > 0 && !filters.flavors.some((flavor) => strain.flavors.includes(flavor))) {
        return false
      }

      // Verified sellers filter
      if (filters.verifiedSellersOnly && !strain.seller.isVerified) {
        return false
      }

      // Rating filter
      if (strain.seller.rating < filters.minRating) {
        return false
      }

      return true
    })

    // Apply sorting
    if (filters.sortBy === "price-low") {
      result.sort((a, b) => a.price - b.price)
    } else if (filters.sortBy === "price-high") {
      result.sort((a, b) => b.price - a.price)
    } else if (filters.sortBy === "thc-high") {
      result.sort((a, b) => b.thcContent - a.thcContent)
    } else if (filters.sortBy === "rating") {
      result.sort((a, b) => b.seller.rating - a.seller.rating)
    }

    setFilteredStrains(result)

    // Update active filters count
    const active = []
    if (filters.priceRange[0] > 0 || filters.priceRange[1] < 5000) active.push("Price")
    if (filters.thcRange[0] > 0 || filters.thcRange[1] < 30) active.push("THC")
    if (filters.cbdRange[0] > 0 || filters.cbdRange[1] < 5) active.push("CBD")
    if (filters.types.length > 0) active.push("Type")
    if (filters.growMethods.length > 0) active.push("Grow Method")
    if (filters.effects.length > 0) active.push("Effects")
    if (filters.flavors.length > 0) active.push("Flavors")
    if (filters.verifiedSellersOnly) active.push("Verified Sellers")
    if (filters.minRating > 0) active.push("Rating")
    if (filters.sortBy !== "relevance") active.push("Sort")

    setActiveFilters(active)
  }, [query, filters])

  const toggleFilter = (filterType: keyof Filters, value: string) => {
    setFilters((prev) => {
      const current = [...(prev[filterType] as string[])]
      const index = current.indexOf(value)

      if (index === -1) {
        current.push(value)
      } else {
        current.splice(index, 1)
      }

      return {
        ...prev,
        [filterType]: current,
      }
    })
  }

  const resetFilters = () => {
    setFilters({
      priceRange: [0, 5000],
      thcRange: [0, 30],
      cbdRange: [0, 5],
      types: [],
      growMethods: [],
      effects: [],
      flavors: [],
      verifiedSellersOnly: false,
      minRating: 0,
      sortBy: "relevance",
    })
    toast.success("Filters reset")
  }

  const saveSearch = () => {
    // In a real app, this would save to user's account
    toast.success("Search saved to your account")
  }

  const simulateMessage = (message: string) => {
    toast(message)
  }

  return (
    <Layout>
      <div className="mb-4 md:mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Search Results: "{query}"</h1>
            <p className="mt-2 text-gray-600">Found {filteredStrains.length} strains matching your search</p>
          </div>

          <div className="flex items-center gap-2">
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                  {activeFilters.length > 0 && (
                    <Badge variant="secondary" className="ml-1 h-5 px-1">
                      {activeFilters.length}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[300px] sm:w-[450px] overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>Search Filters</SheetTitle>
                  <SheetDescription>Refine your search results with these filters</SheetDescription>
                </SheetHeader>

                <div className="py-4 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">Sort By</h3>
                    <select
                      className="rounded-md border border-input bg-background px-3 py-1 text-sm"
                      value={filters.sortBy}
                      onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
                    >
                      <option value="relevance">Relevance</option>
                      <option value="price-low">Price: Low to High</option>
                      <option value="price-high">Price: High to Low</option>
                      <option value="thc-high">THC: Highest</option>
                      <option value="rating">Seller Rating</option>
                    </select>
                  </div>

                  <Accordion type="multiple" className="w-full">
                    <AccordionItem value="price">
                      <AccordionTrigger>Price Range</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="pt-4">
                            <Slider
                              value={filters.priceRange}
                              min={0}
                              max={5000}
                              step={100}
                              onValueChange={(value) =>
                                setFilters({ ...filters, priceRange: value as [number, number] })
                              }
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="rounded-md border border-input px-3 py-1">${filters.priceRange[0]}</div>
                            <div className="rounded-md border border-input px-3 py-1">${filters.priceRange[1]}</div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="thc">
                      <AccordionTrigger>THC Content</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="pt-4">
                            <Slider
                              value={filters.thcRange}
                              min={0}
                              max={30}
                              step={1}
                              onValueChange={(value) => setFilters({ ...filters, thcRange: value as [number, number] })}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="rounded-md border border-input px-3 py-1">{filters.thcRange[0]}%</div>
                            <div className="rounded-md border border-input px-3 py-1">{filters.thcRange[1]}%</div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="cbd">
                      <AccordionTrigger>CBD Content</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="pt-4">
                            <Slider
                              value={filters.cbdRange}
                              min={0}
                              max={5}
                              step={0.1}
                              onValueChange={(value) => setFilters({ ...filters, cbdRange: value as [number, number] })}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="rounded-md border border-input px-3 py-1">{filters.cbdRange[0]}%</div>
                            <div className="rounded-md border border-input px-3 py-1">{filters.cbdRange[1]}%</div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="type">
                      <AccordionTrigger>Strain Type</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {["indica", "sativa", "hybrid"].map((type) => (
                            <div key={type} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`type-${type}`}
                                checked={filters.types.includes(type)}
                                onChange={() => toggleFilter("types", type)}
                                className="h-4 w-4 rounded border-gray-300"
                              />
                              <Label htmlFor={`type-${type}`} className="capitalize">
                                {type}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="grow">
                      <AccordionTrigger>Grow Method</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {["indoor", "outdoor", "greenhouse"].map((method) => (
                            <div key={method} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`grow-${method}`}
                                checked={filters.growMethods.includes(method)}
                                onChange={() => toggleFilter("growMethods", method)}
                                className="h-4 w-4 rounded border-gray-300"
                              />
                              <Label htmlFor={`grow-${method}`} className="capitalize">
                                {method}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="effects">
                      <AccordionTrigger>Effects</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-2 gap-2">
                          {allEffects.map((effect) => (
                            <div key={effect} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`effect-${effect}`}
                                checked={filters.effects.includes(effect)}
                                onChange={() => toggleFilter("effects", effect)}
                                className="h-4 w-4 rounded border-gray-300"
                              />
                              <Label htmlFor={`effect-${effect}`}>{effect}</Label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="flavors">
                      <AccordionTrigger>Flavors</AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-2 gap-2">
                          {allFlavors.map((flavor) => (
                            <div key={flavor} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`flavor-${flavor}`}
                                checked={filters.flavors.includes(flavor)}
                                onChange={() => toggleFilter("flavors", flavor)}
                                className="h-4 w-4 rounded border-gray-300"
                              />
                              <Label htmlFor={`flavor-${flavor}`}>{flavor}</Label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="seller">
                      <AccordionTrigger>Seller</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="flex items-center space-x-2">
                            <Switch
                              id="verified-sellers"
                              checked={filters.verifiedSellersOnly}
                              onCheckedChange={(checked) => setFilters({ ...filters, verifiedSellersOnly: checked })}
                            />
                            <Label htmlFor="verified-sellers">Verified sellers only</Label>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="min-rating">Minimum Seller Rating</Label>
                            <select
                              id="min-rating"
                              className="w-full rounded-md border border-input bg-background px-3 py-1"
                              value={filters.minRating}
                              onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
                            >
                              <option value="0">Any Rating</option>
                              <option value="3">3+ Stars</option>
                              <option value="4">4+ Stars</option>
                              <option value="4.5">4.5+ Stars</option>
                            </select>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>

                <SheetFooter className="flex-row justify-between gap-2 sm:justify-between">
                  <Button variant="outline" onClick={resetFilters} className="flex-1">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button onClick={saveSearch} className="flex-1">
                    <Save className="mr-2 h-4 w-4" />
                    Save Search
                  </Button>
                </SheetFooter>
              </SheetContent>
            </Sheet>

            <select
              className="rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={filters.sortBy}
              onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="thc-high">THC: Highest</option>
              <option value="rating">Seller Rating</option>
            </select>
          </div>
        </div>

        {activeFilters.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {activeFilters.map((filter) => (
              <Badge key={filter} variant="secondary" className="flex items-center gap-1">
                {filter}
                <X
                  className="h-3 w-3 cursor-pointer"
                  onClick={() => {
                    // Remove this filter
                    if (filter === "Price") setFilters({ ...filters, priceRange: [0, 5000] })
                    if (filter === "THC") setFilters({ ...filters, thcRange: [0, 30] })
                    if (filter === "CBD") setFilters({ ...filters, cbdRange: [0, 5] })
                    if (filter === "Type") setFilters({ ...filters, types: [] })
                    if (filter === "Grow Method") setFilters({ ...filters, growMethods: [] })
                    if (filter === "Effects") setFilters({ ...filters, effects: [] })
                    if (filter === "Flavors") setFilters({ ...filters, flavors: [] })
                    if (filter === "Verified Sellers") setFilters({ ...filters, verifiedSellersOnly: false })
                    if (filter === "Rating") setFilters({ ...filters, minRating: 0 })
                    if (filter === "Sort") setFilters({ ...filters, sortBy: "relevance" })
                  }}
                />
              </Badge>
            ))}
            <Button variant="ghost" size="sm" onClick={resetFilters} className="h-6 px-2 text-xs">
              Clear All
            </Button>
          </div>
        )}
      </div>

      {filteredStrains.length > 0 ? (
        <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredStrains.map((strain) => (
            <StrainCard
              key={strain.id}
              {...strain}
              onInquire={() => {
                simulateMessage(`New inquiry for ${strain.name}`)
              }}
              onReserve={() => {
                simulateMessage(`${strain.name} has been reserved`)
                setTimeout(() => {
                  simulateMessage("Seller has been notified")
                }, 2000)
              }}
            />
          ))}
        </div>
      ) : (
        <div className="flex h-60 flex-col items-center justify-center rounded-lg border border-dashed">
          <p className="text-lg text-gray-500 text-center px-4">No strains found matching your criteria</p>
          <p className="mt-2 text-gray-400 text-center px-4">Try adjusting your filters or search term</p>
          <Button variant="outline" className="mt-4" onClick={resetFilters}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Filters
          </Button>
        </div>
      )}
    </Layout>
  )
}
